plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.swamitech.phoenix"
    compileSdk = 35
    buildToolsVersion = "35.0.0"

    defaultConfig {
        applicationId = "com.swamitech.phoenix2"
        minSdk = 26
        targetSdk = 35
        versionCode = 177
        versionName = "1.2.57"
        // 1.2.56: 64-bit ARM phones only. The APK carried four copies of ONNX Runtime and the native lib (arm64, armv7,
        // x86, x86_64); three were never used on a phone, and the 92 MB download kept breaking off half way - a cut-off
        // APK is what the phone calls "package appears to be invalid".
        ndk { abiFilters += listOf("arm64-v8a") }
    }


    val releaseStoreFile = System.getenv("PHOENIX_KEYSTORE_FILE")
    val releaseStorePassword = System.getenv("PHOENIX_STORE_PASSWORD")
    val releaseKeyAlias = System.getenv("PHOENIX_KEY_ALIAS")
    val releaseKeyPassword = System.getenv("PHOENIX_KEY_PASSWORD")

    signingConfigs {
        create("stable") {
            storeFile = rootProject.file("phoenix-debug.keystore")
            storePassword = "phoenixdebug"
            keyAlias = "phoenix"
            keyPassword = "phoenixdebug"
            enableV1Signing = true
            enableV2Signing = true
            enableV3Signing = true
        }
        if (!releaseStoreFile.isNullOrBlank() && !releaseStorePassword.isNullOrBlank() &&
            !releaseKeyAlias.isNullOrBlank() && !releaseKeyPassword.isNullOrBlank()) {
            create("production") {
                storeFile = file(releaseStoreFile)
                storePassword = releaseStorePassword
                keyAlias = releaseKeyAlias
                keyPassword = releaseKeyPassword
            }
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("stable")
        }
        getByName("release") {
            val hasSigning = !releaseStoreFile.isNullOrBlank() && !releaseStorePassword.isNullOrBlank() &&
                !releaseKeyAlias.isNullOrBlank() && !releaseKeyPassword.isNullOrBlank()
            if (hasSigning) signingConfig = signingConfigs.getByName("production")
            isMinifyEnabled = false
            isShrinkResources = false
        }
    }

    // Keep Java and Kotlin bytecode targets aligned for AGP/Kotlin 2.x.
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures { compose = true }

    externalNativeBuild {
        cmake { path = file("src/main/cpp/CMakeLists.txt"); version = "3.22.1" }
    }

    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
        // 1.2.56: store the native libraries compressed (unpacked once at install): a much smaller download
        jniLibs { useLegacyPackaging = true }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-compose:1.10.1")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.compose.ui:ui:1.7.8")
    implementation("androidx.compose.material3:material3:1.3.1")
    implementation("androidx.compose.ui:ui-tooling-preview:1.7.8")
    implementation("androidx.datastore:datastore-preferences:1.1.1")
    implementation("androidx.security:security-crypto:1.1.0-alpha06")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("com.squareup.okhttp3:okhttp-dnsoverhttps:4.12.0")
    implementation("com.microsoft.onnxruntime:onnxruntime-android:1.23.2")
}
