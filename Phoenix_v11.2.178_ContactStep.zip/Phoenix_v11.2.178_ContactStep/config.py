"""Swamitech Phoenix v11.2.71 — Detect-frame identity, gender does not drop a face."""
from __future__ import annotations
import os
from dataclasses import dataclass
from typing import Dict, Tuple

ENV_DEFAULTS = {
    "GRADIO_ANALYTICS_ENABLED": "False",
    "HF_HUB_DISABLE_TELEMETRY": "1",
    "HF_HUB_DISABLE_IMPLICIT_TOKEN": "1",
    "DISABLE_TELEMETRY": "1",
    "DO_NOT_TRACK": "1",
    # Must stay /tmp/gradio. The Android client uploads phoenix_trim_*.mp4 and
    # Gradio returns a path under this folder. Pointing GRADIO_TEMP_DIR at
    # /data/gradio_tmp made preprocess reject those files:
    # "not in the upload folder and cannot be accessed."
    "GRADIO_TEMP_DIR": "/tmp/gradio",
}
for _k, _v in ENV_DEFAULTS.items():
    os.environ.setdefault(_k, _v)

ALLOWED_PATHS = [
    "/tmp/gradio",
    "/tmp/phoenix_uploads",
    "/tmp/phoenix_detect",
    "/data/gradio_tmp",
    "/data/phoenix_uploads",
    "/data/phoenix_outputs",
    "/data/phoenix_jobs",
    "/data",
]

def ensure_runtime_dirs() -> None:
    """Create Gradio's real upload folder. Never move GRADIO_TEMP_DIR to /data."""
    os.environ["GRADIO_TEMP_DIR"] = "/tmp/gradio"
    for d in (
        "/tmp/gradio",
        "/tmp/phoenix_uploads",
        "/data/gradio_tmp" if os.path.isdir("/data") else "",
        "/data/phoenix_uploads" if os.path.isdir("/data") else "",
    ):
        if not d:
            continue
        try:
            os.makedirs(d, exist_ok=True)
        except Exception:
            pass

ensure_runtime_dirs()

DET_MAX_W = 720
DET_SIZE = (640, 640)
# CPU-only speed tiers: smaller detector input for the common single-face path.
DET_SIZE_BALANCED = (512, 512)
DET_SIZE_BEST = (640, 640)
FACE_MODEL_NAME = os.environ.get("PHOENIX_FACE_MODEL", "buffalo_l").strip() or "buffalo_l"
ENABLE_HI_DET_PROBE = os.environ.get("PHOENIX_HI_DET_PROBE", "0").strip().lower() in ("1", "true", "yes", "on")

# Detector acceptance threshold. InsightFace defaults to 0.5; profile and
# distant faces routinely score 0.3-0.5 and are therefore never returned at the
# default. A missed detection used to trigger a revert to the original face,
# which is far more visible than a weak detection the tracker then rejects.
DET_THRESH = 0.28

# Lazy recognition (v11.2.73). The ArcFace recogniser (w600k_r50) costs ~85 ms
# PER FACE on 2 CPU threads - 93% of a detector call with 6 faces in frame -
# and FaceAnalysis.get() runs it on every detection, including the ones this
# pipeline immediately discards in its merge/dedupe/reliability gates and the
# ones found by the second blacked-out pass. Deferring it to the surviving set
# produces BIT-IDENTICAL embeddings (verified: max abs difference 0.000e+00)
# for a measured 3.7x speedup on a two-pass frame.
# Set False to go back to running recognition on every detection immediately.
DET_DEFER_EMBEDDING = os.environ.get("PHOENIX_DEFER_EMB", "1").strip().lower() \
    not in ("0", "false", "no", "off")

# ---------------------------------------------------------------------------
# Shot-cut barrier (v11.2.74). Nothing used to know what a scene change was,
# so at a hard cut the tracker carried the old shot's head, the cached aligned
# crop was re-pasted onto the new shot, and the geometry timeline interpolated
# ACROSS the cut - sliding the face from the old position to the new one over
# about half a second. That is the "lag / pasting confusion / the pasted face
# holds on frame changes" report.
#
# Precision is deliberately favoured over recall: a missed cut is the old
# behaviour, a FALSE cut resets live tracks and risks the original face
# showing. Two independent signals must agree. Calibrated to fire on none of
# a static shot, a fast pan, a whip pan, a zoom, a flash or a slow dissolve.
# Raise CUT_MAD_MIN or CUT_HIST_CORR_MAX to make it even more reluctant;
# set CUT_DETECT False to restore the old behaviour exactly.
CUT_DETECT = os.environ.get("PHOENIX_CUT_DETECT", "1").strip().lower() \
    not in ("0", "false", "no", "off")
CUT_MAD_MIN = float(os.environ.get("PHOENIX_CUT_MAD", "1.00"))
CUT_HIST_CORR_MAX = float(os.environ.get("PHOENIX_CUT_CORR", "0.70"))

# Hard ceiling on how old a cached aligned crop may be when it is re-pasted.
# _nearest_aligned had NO bound: it returned the temporally nearest crop in
# the slot's history however far away that was, so after a long detector gap
# (or across a chunk boundary, where the history is trimmed to a single entry)
# one crop could be stamped onto a second or more of output. 48 frames is
# ~1.6 s at 30fps - generous enough never to touch normal cadence, tight
# enough that a stale face cannot ride through a shot.
ALIGNED_MAX_AGE_FRAMES = int(os.environ.get("PHOENIX_ALIGNED_MAX_AGE", "48"))

# ========================= CPU EFFICIENCY TUNING ===========================
#
# These settings are deliberately conservative. Speed depends on the selected
# output resolution, source FPS, model provider and enhancer; benchmark before
# changing them for a particular Space.
#
# INPUT_MAX_W: historical decode cap. v11.0.2 reader resizes once to the
# chosen output size (ow×oh) — an extra pre-downscale to this width caused
# crush→upscale on 720p+ outputs. Kept for docs/compat; pipeline no longer
# applies it as an intermediate scale.
INPUT_MAX_W = 720

# Maximum concurrent Python frame workers. Keep at 1 on HF CPU so ORT/OpenCV/
# x264 native threads are not thrashing. Override with PHOENIX_VIDEO_WORKERS≤2.
VIDEO_WORKERS = 1

# NOTE (v11.1.0): swap_n / SKIP_N no longer decide how many frames get a face.
# EVERY output frame is composited; these now only decide how often the swap
# NETWORK runs. Between network runs the cached aligned result is re-projected
# onto the current frame with the current frame's own geometry, mask,
# background and lighting, so raising the skip interval costs expression
# freshness, not face presence or placement.
#
# DET_SKIP_INTERVAL: default detector cadence ONLY when det_n/det_int is Auto.
# Do NOT use this as a hard floor over explicit preset/user values (that bug
# forced re-detect every ≥3 keyframes even when Stable set det_n=1 → flicker).
# Set to 1 = detect every keyframe when Auto (least flicker, more CPU).
# Higher values (e.g. 3) are a speed default for Auto on constrained CPU.
DET_SKIP_INTERVAL = 1

# How long a tracked identity may be held/faded once real detection stops
# (occlusion, a fast pan, a genuine multi-frame detector miss) before the
# render loop gives up and shows the original frame instead. Longer trades
# more exposure to a stale/drifting held position if the subject genuinely
# left (the frame-edge/containment checks in _run_job_body still catch that
# case regardless of this value, and a sustained content-visibility failure
# like occlusion is separately routed back to the short floor - see
# _ACTIVE_REJECT_STREAK in core_pipeline.py) for far fewer needless reverts
# during ordinary, brief tracking gaps that HoldThrough's bbox-overlap
# rescues cannot help with (those need SOME detected box to compare
# against; a genuine multi-frame miss has none).
# v11.2.7: 3.0 -> 1.0. Three seconds was set in v11.2.5 to stop needless
# reverts, on the reasoning that a revert is the worse artifact. That was
# measured against reverts and never against the opposite failure, and the
# opposite failure is what got reported: at 3.0s a subject who turns away
# keeps a held face painted over the back of their head for practically the
# whole turn - measured on t_extended_lookaway, 106 of a 120-frame turn-away
# were still being painted.
#
# Two things make the shorter window safe now in a way it was not in v11.2.5.
# Suppression FADES rather than cuts (PASTE_FADE_SEC below), so reaching the
# end of the window costs a soft fade, not the hard flash of the real face
# that the long window was reacting to. And an empty detector return is no
# longer conflated with positive evidence of absence (see _vis_marks in
# core_pipeline), so this window is now only ever spent on genuine "we cannot
# see anything" gaps rather than on frames the content gate already judged.
#
# 2.0s is now only the FADE LENGTH for a gap, not the whole hold budget: a
# run of empty detector returns longer than BLIND_AFTER_SEC below opens a
# blind span and drops to the short cadence taper regardless of this value.
# So this can be generous, and being generous is what keeps a brief gap from
# dimming - at 2.0s an 18-frame motion-blur dropout sits at 91% opacity
# instead of 64%, and the fade's per-frame slope (2/taper, which is what
# frame-to-frame area change tracks) is halved.
REACQUIRE_GRACE_SEC = 2.0

# How long the composited face takes to fade out when a suppression path
# fires, instead of cutting to the untouched original in a single frame.
#
# This is the fix for the flicker/revert family at its shared root. The
# pipeline already had two smooth fades (TrackState.smooth_alpha's EMA and
# _geom_for_frame's taper), but EVERY path that decides "do not paint this
# frame" bypassed both and emitted the pristine original immediately - so a
# gate flipping for one or two frames showed as a hard flash of the real
# face (flicker), and the same flip sustained showed as a revert. Fading
# instead of cutting makes a brief flip cost a few percent of opacity rather
# than a full-strength flash, while a sustained one still ends up fully
# reverted, just smoothly.
#
# Only the DOWNWARD direction is slewed. Coming back up stays instant, which
# preserves v11.2.1 SolidFace's "when the gates say yes, sit at full
# strength" behaviour - a face appearing is never itself a flash of the
# original, so it needs no ramp.
# How long a run of "the detector returned nothing" may last before it stops
# being treated as a gap to ride through and starts being treated as evidence
# that the face is gone.
#
# This is the one number separating two cases that look identical from the
# detector's side: a face hidden by motion blur for a few frames, which must
# be ridden through or it flickers, and a subject who has turned away or left,
# which must be dropped or their real face gets a swap pasted over it. Only
# duration tells them apart. 0.75s clears the longest dropout in this repo's
# fixtures (t_modes' 18 frames, 0.6s) and bounds a genuine absence well inside
# a second.
#
# Set deliberately SHORTER than REACQUIRE_GRACE_SEC: that one is now the fade
# length for gaps this one has not yet declared blind.
BLIND_AFTER_SEC = 0.75

# How long a run of "the detector found a face but every candidate was
# rejected" must last before it collapses the re-acquire grace window.
#
# This used to be a count of 2 DETECTOR CALLS - as little as 2 output frames
# at det_n=1 - while an EMPTY detector return needed a full BLIND_AFTER_SEC.
# That is backwards: a rejected candidate is positive evidence the face is
# present and merely unconfirmed, while an empty return is the one that hints
# at absence. The inverted weighting meant a couple of hard frames dropped the
# grace window from 2.0 s to a third of a second, the held face faded, and the
# original showed through until the next accepted detection - the intermittent
# revert, with the fading extrapolated face as the ghost.
# Raise it to ride through longer rejection runs; lower it to drop a face that
# can never be confirmed more quickly.
REJECT_BLIND_SEC = 0.75

PASTE_FADE_SEC = 0.5
FACE_ROI_PAD = 0.22
FACE_EMA_ALPHA = 0.40
COLOR_MATCH_SCALE = 0.25
# Reference cadence table (Auto swap_n). Ultra stays at 1 (talking-head).
# Best is 2: same tracking density, half the ONNX swaps. Optimized/Fast are
# throughput tiers. Detector should never be sparser than the swap network.
SKIP_N = {"Fast": 6, "Balanced": 4, "Optimized": 5, "Best": 2, "Ultra": 1}

RES: Dict[str, Tuple[int, int]] = {
    "540p (Fastest)": (960, 540),
    "640p (Fast)": (1136, 640),
    "680p": (1208, 680),
    "720p (HD)": (1280, 720),
    "900p (HD+)": (1600, 900),
    "1080p (Full HD)": (1920, 1080),
}

# A finished result waits on the server for the phone to come back and fetch it.
# 3 hours was shorter than a night: start a long split, minimise the app, sleep,
# and the first part had already been deleted by the time it was opened. 12 h.
# RETAIN_SEC (history file) and SERVER_OUTPUT_TTL_SEC (server copy + the
# expires_at the app is shown) must stay equal.
RETAIN_SEC = 43200  # completed server outputs retained for 12 hours
ORPHAN_SEC = 86400
SESSION_TTL_SEC = 86400
SESSION_DIR = "/tmp/swamitech_session"
SESSION_JSON = "/tmp/swamitech_session.json"

AUTO_SAVE_ENABLED = True
AUTO_SAVE_DIR = "/tmp/.swamitech_autosave"
AUTO_SAVE_RETAIN_SEC = 10800
HF_OUTPUT_REPO = os.environ.get("SWAMITECH_HF_OUTPUT_REPO", "").strip()
HF_UPLOAD_ENABLED = bool(os.environ.get("HF_TOKEN")) and bool(HF_OUTPUT_REPO)

# Authoritative server-side result storage. Attach an HF Storage Bucket to /data
# for persistence across Space restarts; the app writes completed outputs to
# this directory before marking a job done. Override with an environment variable
# when using a different mounted persistent volume.
PERSISTENT_OUTPUT_DIR = os.environ.get("PHOENIX_PERSISTENT_OUTPUT_DIR", "/data/phoenix_outputs").strip() or "/data/phoenix_outputs"
PERSISTENT_JOB_STATE_DIR = os.environ.get("PHOENIX_PERSISTENT_JOB_STATE_DIR", "/data/phoenix_jobs").strip() or "/data/phoenix_jobs"
SERVER_OUTPUT_TTL_SEC = 43200  # exactly 12 hours after successful completion

# Resumable transport (v11.2.80) - see phoenix_api_adapter.install_http_routes.
# Uploads arrive as chunks at an explicit offset, so a phone that is minimised
# mid-upload continues from the last byte the server holds instead of starting
# again (or giving up). Downloads honour Range for the same reason.
RESUMABLE_ENABLED = True
RESUMABLE_CHUNK_BYTES = 4 * 1024 * 1024         # advised to the client
RESUMABLE_MAX_CHUNK_BYTES = 32 * 1024 * 1024    # hard cap per PUT
RESUMABLE_MAX_FILE_BYTES = 2 * 1024 ** 3        # largest single upload
RESUMABLE_MAX_ACTIVE = 16                       # unfinished uploads at once
RESUMABLE_PARTIAL_TTL_SEC = 6 * 3600            # an untouched upload is dropped after this
RESUMABLE_EVICT_IDLE_SEC = 900                  # when the table is full, unfinished uploads idle this long make room
# settings.split_seconds cuts a clip into server-side parts; this caps the count
# (the output name Phoenix_<job>-<n>.mp4 only has room for 10).
SPLIT_MAX_PARTS = 10

DUR = [10, 20, 30, 60, 90, 120, 150, 180, 240, 300, 360]
FPS = [15, 24, 30, 40, 50, 60]

VERSION = "v11.2.178"
BUILD = "ContactStep · the 11.2.92 face swap; in a kiss or hug each face is kept (where it touches its partner, by elimination of 2 people, moving with the partner when missed); a fast step keeps the face; only a painted mark is removed, with its Preview"
VERSION_FULL = f"{VERSION} ({BUILD})"

@dataclass
class Settings:
    det_max_w: int = DET_MAX_W
    det_size: Tuple[int, int] = DET_SIZE
    version: str = VERSION_FULL

SETTINGS = Settings()


# ---------------------------------------------------------------------------
# v11 engine tunables (swap_engine.AlignedCompositor / MultiFaceTracker).
# These are the dials worth touching if output needs adjusting; everything is
# applied at import time via swap_engine.configure(**ENGINE_TUNABLES).
# ---------------------------------------------------------------------------
ENGINE_TUNABLES = {
    # --- mask shape, defined in the pose-normalised aligned crop -----------
    # Because the crop is pose-normalised, one shape fits every head angle.
    # That is what makes it flicker-free: nothing about it varies per frame.
    "mask_rx":          0.435,   # half-width  (fraction of crop). Larger = more coverage
    "mask_ry":          0.495,   # half-height. Raise if the chin/forehead is clipped
    "mask_feather":     0.16,    # edge softness. Raise if you can see the seam
    "hull_dilate":      0.085,   # landmark-hull dilation
    "hull_floor":       0.30,    # hull can never remove more than 70% of the template
    "mask_ema":         0.36,    # SoftStable: keep 0.36 (do not raise like ProStable 0.40)

    # --- colour transfer ---------------------------------------------------
    # cm_std_lo is the important one. The v10.9.3 bug was effectively a hard
    # 0.20 contrast ratio, which flattened the face into the brown patch.
    # Never set cm_std_lo below ~0.65.
    # SoftStable: gentler luma / tighter shift / delta clamp — brightness only.
    "cm_strength_ab":   0.85,    # chroma follows the scene strongly
    "cm_strength_l":    0.42,    # CinemaQA: steadier than SoftStable 0.45
    "cm_std_lo":        0.72,    # floor on the contrast ratio
    "cm_std_hi":        1.45,
    "cm_ema":           0.15,    # CinemaQA: steadier than SoftStable 0.18
    "cm_max_shift":     20.0,    # SoftStable: was 26 — tighter LAB mean cap
    "cm_delta_clamp":   4.0,     # CinemaQA: tighter than SoftStable 5.0

    # --- occlusion guard (hug / kiss / hand across the face) ---------------
    "occl_min_keep":    0.45,    # SolidFace: center stays opaque under marginal occl
    # The guard is a CONTINUOUS weight, not an on/off flag. A flag changed the
    # mask silhouette - and so the colour statistics weighted by that mask - in
    # a single frame every time it flipped, moving outline and brightness at
    # once. occl_ramp is how fast it may slew per frame; lower = smoother.
    "occl_ramp":        0.25,
    # Two faces in contact have essentially identical chroma, so the skin
    # confidence term cannot see the other person's cheek inside this face's
    # aligned crop. Their own landmark hull can be projected in and subtracted.
    # rival_cut 0 disables it; raise toward 1.0 to trim contact harder.
    "rival_cut":        0.85,
    "rival_feather":    0.09,

    # --- relative identity admission (v11.2.79) ---------------------------
    # A slot that had locked onto a person accepted a later detection only if
    # it matched that ONE stored frame at >= 0.38 (>= 0.40 after a gap), and a
    # second absolute floor of 0.32 sat after pairing. Measured on the real
    # tracker: a returning person re-binds ~100% of the time at similarity 0.45,
    # 90% at 0.37, and 0% at 0.33 and below - for any gap length, permanently,
    # because the lock is only refreshed by faces that clear the wall.
    # With two or more identified people the better question is "which person
    # is this, relative to the others?", which is easy: different people sit
    # near 0 against each other's locks.
    #
    # These three numbers set how readily a face below the old wall is admitted.
    # Defaults recover a person down to similarity ~0.26 with bystander false
    # binds at baseline for ordinary recognition noise. If a LOOK-ALIKE
    # bystander (similar enough to be mistaken for a target) is being swapped,
    # tighten to floor 0.30 / margin 0.18 / confirm 3: that gives up recovery
    # below ~0.32 and cuts the sustained look-alike case from 43% to 4%.
    "trk_rel_floor":    0.25,   # never admit below this similarity
    "trk_rel_margin":   0.15,   # must beat EVERY other identified person by this
    "trk_rel_confirm":  2,      # consecutive consistent detections for a NEW acquisition

    # --- occluder rejection (v11.2.75) ------------------------------------
    # The previous occluder gate could not fire at all: it searched 2.24% of
    # the crop and then demanded a connected blob of at least 4% of the crop,
    # so the minimum area was larger than the whole search window and it
    # returned "nothing is occluded" on every frame of every job. Measured
    # against ice cream, a spoon and a hand: 0.00% removed in all cases.
    #
    # The replacement needs four things to agree before it cuts: the pixel is
    # off this face's own skin colour, it is off this face's own LEARNED
    # appearance at that spot (so a beard, glasses or a birthmark are kept),
    # the blob reaches the edge of the face or is large (so lips and an open
    # mouth are kept), and it is big enough to matter.
    #
    # Thresholds are in units of the face's own chroma/luma spread, so they
    # mean the same thing on any skin tone under any light. LOWER occ_chroma /
    # occ_luma to catch more (e.g. a pale pink lolly or a low-contrast metal
    # spoon); raise them if anything is being cut that should not be.
    "occ_chroma":       2.6,
    "occ_luma":         2.6,
    "occ_ref_chroma":   2.6,
    "occ_ref_luma":     2.6,
    "occ_min_frac":     0.010,
    "occ_big_frac":     0.045,
    "occ_rim":          0.055,
    "occ_rim_frac":     0.02,
    "occ_out_frac":     0.08,
    "occ_ref_ema":      0.10,
    "occ_ref_warm":     12,     # frames before the model may veto anything
    "occ_work":         192,    # working resolution; cost and memory are fixed by this
    "occ_open":         0.45,   # how fast a hole OPENS (was effectively 0.10 - too slow to matter)
    "occ_close":        0.22,

    # --- plate matching: grain and motion blur (v11.2.72) -----------------
    # A restored face is denoised and sharp; the footage around it is neither.
    # That spatial-frequency mismatch is the single most reliable "this is
    # CGI" cue, and no amount of colour matching hides it - colour matching
    # works on tone, this is texture. Both passes MEASURE the plate and match
    # it, so on clean, static footage they do nothing at all.
    # Set grain_strength or mblur_strength to 0.0 to disable either outright.
    # The restored crop is kept at the resolution the face's on-screen size
    # justifies instead of being crushed back to the swapper's 128 (which
    # destroyed ~85% of the restoration and then up-sampled the remains).
    # This is the ceiling on that. 512 = full quality; 256 = most of the
    # visible gain at about a third of the extra cost; 128 = old behaviour.
    "restore_crop_max": 512,
    "grain_strength":   0.90,    # fraction of the measured grain deficit restored
    "grain_max":        9.0,     # hard cap on added sigma, 8-bit levels
    "grain_chroma":     0.35,    # chroma grain relative to luma; 0 = luma only
    "grain_ema":        0.25,    # temporal smoothing of the grain estimate
    "mblur_strength":   0.85,    # fraction of the measured sharpness excess removed
    "mblur_max":        0.055,   # blur length cap, fraction of the crop
    "mblur_ema":        0.30,
    # v11.2.90 (SDOS-090). adaptive_key = 0 restores v11.2.89 exactly.
    "adaptive_key":     1,      # extra key frames (detection + swap network) while a face moves or changes fast; Best/Balanced/Fast only
    "adaptive_key_move": 0.08,  # an extra swap once the face has travelled this many face widths since the last swap (0.08 = 30 px of a 370-px face)
    "adaptive_key_change": 0.20,  # ...or its look has changed this much (summed per frame since the last swap; 0.002 = noise, 0.03 = talking, 0.3 = a fast turn)
    "adaptive_key_min_gap": 1,  # frames between two key frames, at least
    "adaptive_key_max_frac": 0.60,  # extra key frames never exceed this share of all frames (bounds the extra run time)
    # v11.2.91 (SDOS-091) occlusion net. occ_net = 0 restores v11.2.90 exactly.
    "occ_net":          1,      # a trained occlusion model (FaceFusion's XSeg) cuts what is in front of the mouth/chin: food, a cup, a hand
    "occ_net_blur":     3.0,
    "occ_net_hull_erode": 0.08, # only inside the face's own outline, this far in: the edge of the swap is not touched
    "occ_net_core_y":   0.58,   # a cut must reach the mouth/chin zone (below this row of the face crop...)
    "occ_net_core_x":   0.17,   # ...within this distance of the centre line)
    "occ_net_core_min": 0.002,  # ...by at least this share of the crop; hair over the cheeks, beards and shadows are left alone
    "mblur_k":          6.0,     # anisotropy deficit -> kernel length; see swap_engine

    # The 106-point hull is the only pose-DEPENDENT term in an otherwise
    # pose-normalised mask, so it is what makes the silhouette breathe on a yaw
    # turn. Lower = steadier outline on profile turns, slower to follow a real
    # change in face shape.
    "hull_ema":         0.22,

    # --- multi-face association -------------------------------------------
    "trk_gate_new":     0.12,    # virgin slots bind on spatial; identity locks after
    "trk_gate_hold":    0.10,    # ...and to KEEP an established one (deliberately low)
    "trk_lock_hits":    4,       # frames before a track counts as established
    "trk_cross_iou":    0.12,    # tracks this close are "crossing" -> embeddings frozen
    "trk_flip_margin":  0.14,    # identity margin needed to justify a label flip
    "trk_flip_frames":  5,       # ...sustained for this many consecutive frames
    "trk_max_missed":   24,      # carry-through budget before the track gives up
    "trk_alpha":        0.42,    # bbox smoothing on update
    # One-Euro landmark smoothing (keys must exist in swap_engine._P to apply)
    "kps_min_cutoff":   0.08,
    "kps_beta":         0.040,
}

# Occlusion net for v11.2.91 (SDOS-091): FaceFusion's XSeg face occluder, downloaded once at model load.
# Licence: the XSeg lineage comes from DeepFaceLab (GPL-3.0); FaceFusion publishes the ONNX export.
OCC_NET_URL = os.environ.get("PHOENIX_OCC_NET_URL",
                             "https://github.com/facefusion/facefusion-assets/releases/download/models-3.1.0/xseg_2.onnx")
OCC_NET_SHA256 = "cd9a0879eaf43841d765472cf1f8c330dbf9dcb03da0eace93e95f3bcc399042"
OCC_NET_BYTES = 70324286

# "Cinematic (clarity + smooth)" enhancer since v11.2.91 (SDOS-091): subtle glow on lit skin, gentle HDR, vibrance.
# Each 0 = that touch off. glow 0.18 = up to 18 % of a screen blend on the brightest skin; hdr 0.12 = 12 % compression
# of large-scale light and 12 % lift of fine detail; vibrance 0.12 = muted colours up to +12 %, strong colours unchanged.
ENHANCE_CINEMATIC = {"glow": 0.18, "hdr": 0.12, "vibrance": 0.12}

# "GPEN (fast restore)" face restorer since v11.2.92 (SDOS-092): GPEN-BFR-256 (FaceFusion's ONNX export), downloaded at
# the first job that asks for it. About 0.2 s per swapped face on 2 CPUs (GFPGAN: about 3 s). "CodeFormer" runs it too.
# Licence: GPEN is published for academic / non-commercial use.
GPEN_URL = os.environ.get("PHOENIX_GPEN_URL",
                          "https://github.com/facefusion/facefusion-assets/releases/download/models-3.0.0/gpen_bfr_256.onnx")
GPEN_SHA256 = "bad8bf0426873828df2dbf4e3b3d9ababba9da7965b8b72426569486f7ae5c25"
GPEN_BYTES = 75792988
# blend: share of the restored face mixed over the plain upscale (1 = restorer only, 0 = off).
# sharp_cap: the face's fine detail may reach this many times the footage's own (soft shots get less restoration).
# steady: share of the previous swap's restored detail kept (0 = new detail on every swap, more shimmer).
ENHANCE_GPEN = {"blend": 0.6, "sharp_cap": 1.25, "steady": 0.5}
