"""
Swamitech v11 "Aequus" — aligned-space swap engine.

WHY THIS MODULE EXISTS
======================
Every visual defect Swamitech has fought for months (flicker on profile turns,
the brown patch, waxy/flat skin, face-1/face-2 mix-ups during a hug) traces back
to two structural decisions in the older pipeline:

  1. Masking and colour matching were done in IMAGE SPACE using the detector's
     axis-aligned bounding box. A bbox is pose-dependent: it balloons when the
     head rolls, and it contains hair / neck / background / the *other* person.
     Statistics computed over it are contaminated, and a mask derived from it
     changes shape every frame -> visible flicker and colour casts.

  2. Whenever anything was uncertain (detector skipped, low confidence, faces
     overlapping) the pipeline fell back to the ORIGINAL frame. A single
     original frame between swapped frames is the most visible artefact a face
     swap can produce. Reverting is *worse* than a slightly imperfect swap.

This module fixes both. All compositing happens in the 128x128 ArcFace-aligned
crop that inswapper already produces internally. That crop is pose-normalised by
construction, so:

  * a mask defined there has stable geometry regardless of yaw/roll;
  * an EMA over that mask is meaningful (you are averaging the same anatomy);
  * colour statistics gathered there, inside the mask, never see background.

The module depends only on numpy + cv2 so it can be unit-tested without
insightface, onnxruntime or gradio present.

Public API
----------
    AlignedCompositor          - the swap+blend core
    TrackState                 - per-identity temporal memory
    MultiFaceTracker           - occlusion-aware slot assignment
    PredictedFace              - lightweight face stand-in for skipped frames
    swap_and_composite(...)    - convenience wrapper used by core_pipeline
"""

from __future__ import annotations

import logging
import os
import threading
import math
from itertools import permutations

import cv2
import time
import numpy as np

__all__ = [
    "AlignedCompositor",
    "estimate_norm",
    "landmark_fit_error",
    "ARCFACE_DST",
    "TrackState",
    "MultiFaceTracker",
    "PredictedFace",
    "swap_and_composite",
    "ENGINE_VERSION",
]

ENGINE_VERSION = "aequus-1.2.208-reffallback"

log = logging.getLogger("swamitech.engine")


def _fnum_local(x, default=0.5):
    if x is None:
        return float(default)
    try:
        if isinstance(x, np.ndarray):
            if x.size == 0:
                return float(default)
            x = x.reshape(-1)[0]
        return float(x)
    except Exception:
        return float(default)


# --------------------------------------------------------------------------
# Tunables. Overridable from config.py via configure().
# --------------------------------------------------------------------------
_P = {
    # canonical mask shape (fractions of the aligned crop)
    "mask_cx": 0.500,
    "mask_cy": 0.545,
    "mask_rx": 0.435,
    "mask_ry": 0.495,
    "mask_power": 2.55,      # superellipse exponent; >2 = squarer, <2 = pointier
    "mask_feather": 0.16,    # gaussian sigma as fraction of crop size
    # Force the template to zero at the crop border. The superellipse is
    # centred at cy=0.545 with ry=0.495, so it reaches 1.04 - it runs off the
    # bottom of the crop and was 0.881 there (top 0.250, sides 0.111). That is
    # a HARD EDGE in the composite, not a feathered one. It normally hides
    # because the chin edge lands on a neck, but it is what turns any
    # mis-placed paste into a visible straight-edged rectangle. The chin sits
    # at about y=0.875 in ArcFace-128 space, so an 0.08 rolloff clears it.
    "mask_border": 0.08,
    # landmark-hull refinement
    "hull_dilate": 0.085,    # dilate hull by this fraction of crop size
    "hull_floor": 0.30,      # hull never removes more than (1-floor) of template
    "mask_ema": 0.36,        # SoftStable: match config (0.36)
    # colour transfer (SoftStable brightness-only)
    "cm_strength_ab": 0.85,  # chroma follows the target scene strongly
    "cm_strength_l": 0.42,   # CinemaQA: steadier than SoftStable 0.45
    "cm_std_lo": 0.72,       # contrast ratio clamp - never crush face contrast
    "cm_std_hi": 1.45,
    "cm_ema": 0.15,          # CinemaQA: steadier than SoftStable 0.18
    "cm_max_shift": 20.0,    # SoftStable: was 26
    "cm_delta_clamp": 4.0,   # CinemaQA: tighter than SoftStable 5.0
    # occlusion guard (off by default)
    "occl_min_keep": 0.45,  # SolidFace: keep center opaque under marginal occl_guard
    # Occlusion strength is a CONTINUOUS weight in [0,1], not a boolean.
    # A binary guard changed the mask area by several percent from one frame
    # to the next every time it toggled, and the mask is what the colour
    # statistics are weighted by - so a toggle moved both the silhouette and
    # the brightness at once. The guard now ramps over occl_ramp frames.
    "occl_ramp": 0.25,
    # Rival-face subtraction. During a kiss/hug the other person's cheek lands
    # inside this face's aligned crop with near-identical chroma, so
    # skin_confidence() cannot see it. Their landmark hull can be projected in
    # geometrically, which can.
    "rival_cut": 0.85,       # how hard a rival hull is removed (0 = off)
    # --- plate matching (SDOS-071 F2/F3) ---------------------------------
    # A restored face is DENOISED and SHARP. The plate it is pasted into is
    # neither: it carries sensor grain, and during movement it carries motion
    # blur. A clean, sharp face inside a grainy, blurred frame is the single
    # most reliable "that is CGI" tell there is, and no amount of colour
    # matching hides it because it is a spatial-frequency mismatch, not a
    # tonal one. These two passes measure the plate and match it.
    # Hard ceiling on the retained restored crop. The adaptive chooser will
    # never go above the face's on-screen span anyway, but a 2-vCPU box
    # rendering close-ups pays about +30 ms per output frame at 512 and this
    # is the dial that buys that back. 128 reproduces the old behaviour
    # exactly; 256 keeps most of the visible gain for a third of the cost.
    "restore_crop_max": 512,
    # --- occluder rejection (SDOS-074) -----------------------------------
    # Thresholds are in units of the FACE'S OWN chroma/luma spread, so they
    # mean the same thing on any skin tone under any light. See occluder_keep.
    "occ_chroma": 2.6,       # how far off this face's skin colour counts as foreign
    "occ_luma": 2.6,         # ...or off its brightness
    "occ_ref_chroma": 2.6,   # how far off its OWN learned appearance here
    "occ_ref_luma": 2.6,
    "occ_min_frac": 0.010,   # smallest occluder, as a fraction of the face area
    "occ_out_frac": 0.08,    # how much of the blob must lie outside the face
    # Working resolution for occlusion. The decision is Gaussian-blurred to a
    # twentieth of the crop before use, so computing it at full 512 bought
    # nothing and cost 36.7 ms/frame (and 3.15 MB of appearance model per
    # track). Fixed at 192 it is 4.6 ms and 0.44 MB, independent of crop size
    # - which also means the model stays valid when the adaptive crop size
    # changes as the face moves toward or away from the camera.
    "occ_work": 192,
    "occ_rim": 0.055,        # width of the face-edge band, as a fraction of the crop
    "occ_rim_frac": 0.02,    # how much of the blob must reach that band
    # A blob this large (as a fraction of the face) that is both off this
    # face's skin AND off its own learned appearance is taken as an occluder
    # even if it never reaches the face edge - which is the case for food held
    # right at the lips. Safe only because the appearance model already vouches
    # for the lips and the mouth cavity, so they are not novel and cannot
    # reach this test; it is therefore gated on the model being well warmed.
    "occ_big_frac": 0.045,
    "occ_ref_ema": 0.10,     # learning rate of the per-pixel appearance model
    "occ_ref_warm": 12,      # frames before the model is trusted to veto
    "occ_open": 0.45,        # how fast a hole OPENS (was effectively 0.10)
    "occ_close": 0.22,       # ...and closes
    "grain_strength": 0.90,  # fraction of the measured grain deficit restored
    "grain_max": 9.0,        # hard cap on added sigma (8-bit levels)
    "grain_chroma": 0.35,    # chroma grain relative to luma grain
    "grain_ema": 0.25,       # temporal smoothing of the sigma estimate
    "mblur_strength": 0.85,  # fraction of the measured sharpness excess removed
    "mblur_max": 0.055,      # blur length cap as a fraction of crop size
    "mblur_ema": 0.30,
    # SDOS-090 face-motion key frames (see core_pipeline._FaceMotionKeys). adaptive_key = 0 restores v11.2.89 exactly.
    "adaptive_key": 1.0,            # 1 = extra key frames (detect + swap) while a face moves or changes fast
    "adaptive_key_move": 0.08,      # travel since the last swap, in face widths, that makes an extra one
    "adaptive_key_change": 0.20,    # accumulated change of look since the last swap that makes an extra one
    "adaptive_key_min_gap": 1,      # frames; never closer than this
    "adaptive_key_max_frac": 0.60,  # extra key frames never exceed this share of all frames (runtime cap)
    # SDOS-091 occlusion net (FaceFusion's XSeg face occluder). occ_net = 0 restores v11.2.90 exactly.
    "occ_net": 1.0,                 # 1 = a trained occlusion model cuts what is in front of the mouth and chin (food, a cup, a hand)
    "occ_net_blur": 3.0,            # smoothing of the model's answer (pixels of its 256-px input)
    "occ_net_hull_erode": 0.08,     # only inside the face's own landmark outline, this far in (fraction of the crop): the outline of the swap is not touched
    "occ_net_core_y": 0.58,         # a cut piece must reach the mouth/chin zone: below this row...
    "occ_net_core_x": 0.17,         # ...and within this distance of the centre line (fraction of the crop)...
    "occ_net_core_min": 0.002,
    # v11.2.206 (SDOS-206) occlusion smoothness. Each 0 restores v11.2.205 exactly.
    # v11.2.207 (SDOS-207): a person whose Detect picture matches no face for this many detector calls in a row (while a face
    # nobody else has is there) is found by elimination instead (0 = 11.2.206: the picture alone, for as long as it takes)
    "trk_ref_stale_calls": 45,
    "trk_ref_stale_other": 0.30,     # ...but never a face that another person's picture matches this well
    "occ_flow": 1.0,                # last frame's cut moves with the object (optical flow inside the face crop) before smoothing
    "occ_instant": 1.0,             # a cut opens at once where the colour test AND the occlusion model both see the object
    "occ_snap": 1.0,                # the cut's edge follows the picture's own edges (guided filter in the face crop)
    "occ_snap_eps": 0.03,           # ...its smoothness (grey levels 0-1)
    "occ_net_wide": 1.0,            # the model's cut away from the mouth too (a hand over an eye or a cheek), for big pieces...
    "occ_net_wide_min": 0.010,      # ...of at least this share of the face crop...
    "occ_net_wide_inner": 0.25,     # ...with at least this share over the inner face (hair along the face's edge is not cut)
    "occ_net_wide_erode": 0.10,     # the inner face: the outline taken this far in (fraction of the crop)
    "occ_net_wide_hold": 0.30,      # a piece that overlaps last frame's cut this much stays cut while the object leaves
    "occ_net_wide_edge": 0.04,      # (the first frames of a face, before it has a memory: the outline plus this much)
    "occ_net_wide_zone_erode": 0.03,  # big pieces are looked for this close to the face's outline (the mouth rule: 0.08)
    "occ_net_wide_lips": 0.04,      # the lips and this margin stay under the mouth rule (a smile is not an object)
    "occ_net_wide_face": 0.4,
    "occ_net_back": 0.9,
    "occ_net_wide_yaw": 0.34,       # not on a face turned more than ~35 deg (the side-view offset), nor two faces in contact            # where the model is this sure it sees face, a cut gives the face back at once       # an accepted piece is followed only where the model saw face on the last frames
    # v11.2.92 (SDOS-092) extreme side views: there the 5-point alignment puts the fixed oval half in front of the
    # face (air, background) and leaves the back cheek out. From profile_lo to profile_hi (nose offset from the eye
    # midpoint, in eye distances: 0.25 at 18 deg of yaw, 0.45 at 45 deg, 0.76+ from 55 deg on the AFLW2000 photos)
    # the mask moves over to the visible face's own outline (occlusion net's face map x landmark outline).
    "profile_mask": 1.0,
    "profile_lo": 0.45,
    "profile_hi": 0.70,
    "profile_feather": 0.025,
    # v11.2.92 (SDOS-092) one mouth while eating: when the occlusion net cuts something at the mouth that reaches
    # OUTSIDE the lips (food, a spoon, a cup; an open mouth, teeth or a tongue stay inside them), the footage's own
    # lips are shown with the object, so there is one set of lips around it instead of the swapped lips next to the
    # real ones. eat_lo/eat_hi: share of the crop cut outside the lips for the rule to start / be complete.
    "eat_mouth": 1.0,
    "eat_lo": 0.002,
    "eat_hi": 0.008,
    "eat_attack": 0.6,
    "eat_release": 0.12,
    "eat_lip_pad": 0.035,      # ...by at least this share of the crop. Hair over the cheeks, beards and shadows are left alone.
    # How an ANISOTROPY deficit converts to kernel length. Measured on
    # line-blurred plates (perp/along Sobel energy under the face mask):
    # L=3 -> 1.42, L=5 -> 1.92, L=7 -> 2.38, L=11 -> 3.06, L=21 -> 4.18, i.e.
    # about 0.14 of anisotropy per pixel of kernel. 6.0 is the inverse of that
    # rounded DOWN on purpose: this pass should under-blur rather than over-,
    # because a face softer than its plate reads as out of focus while one
    # slightly sharper just reads as a good restoration.
    "mblur_k": 6.0,
    "rival_feather": 0.09,   # softness of that cut, fraction of crop size
    # Hull temporal stability. The 106-point hull is the only pose-DEPENDENT
    # term in an otherwise pose-normalised mask, so it is what makes the
    # silhouette breathe on a yaw turn. Smooth it on its own, slower clock.
    "hull_ema": 0.22,
    # tracker
    "trk_w_id": 0.52,
    "trk_w_iou": 0.33,
    "trk_w_dist": 0.15,
    "trk_gate_new": 0.12,    # virgin slots bind on spatial; identity locks after
    "trk_gate_hold": 0.10,   # identity sim needed to KEEP an established one
    "trk_lock_hits": 4,      # frames before a track is "established"
    "trk_cross_iou": 0.12,   # tracks this close are considered "crossing"
    "trk_flip_margin": 0.14, # identity margin needed to justify a label flip
    "trk_flip_frames": 5,    # ...sustained for this many frames
    "trk_max_missed": 24,
    # v11.2.176 (SDOS-176): two people in contact (a kiss, a hug). 0 = the v11.2.92 behaviour exactly.
    "contact_follow": 1,     # a face in contact is kept by where it touches its partner, and moves with the partner when missed
    "contact_carry_max": 240,  # ...and is carried while its partner is seen, up to this many frames (8 s at 30 fps; v11.2.92: 24)
    "two_elim": 1,
    "smart_keys": 1,         # v11.2.204: Optimized - every frame swapped in contact or a side pose over ~40 deg
    "side_key_h": 0.40,      # v11.2.204: side pose = nose offset >= 0.40 eye distances (about 40 deg, AFLW2000-calibrated)
    "arc_skip": 1,           # v11.2.203: two people far apart and clearly tracked - reuse each one's identity, ArcFace every 3rd call
    "fast_snap": 1,          # v11.2.176: a face moving fast (4-10 % of its width a frame and more) is followed without smoothing lag           # 2 people, 2 faces found: one clearly person X, the other is person Y (if it is where Y was, not a sliver)  # aligned with config ENGINE_TUNABLES / predicted hold budget
    # Relative identity admission (SDOS-078). A slot that has locked onto a
    # person used to accept a later detection only if it matched that one stored
    # frame at >= 0.38 (>= 0.40 after a gap) - an absolute wall. Measured on the
    # real assign(): a returning person is re-bound ~100% of the time at 0.45,
    # ~30% at 0.40, and 0% at 0.37 or below, for ANY gap length, forever - the
    # lock is only refreshed by faces that clear 0.38, so it can never move
    # toward the appearance that is failing. With two or more identified people
    # the right question is not "is this above an absolute number" but "which
    # person is this, relative to the others", which is easy: different people
    # sit near 0 against each other's locks.
    "trk_rel_floor": 0.25,    # never admit below this, however clear the margin
    "trk_rel_margin": 0.15,   # must beat EVERY other identified slot by this much
    "trk_rel_confirm": 2,     # consecutive, spatially consistent detections required
    "trk_alpha": 0.42,       # bbox smoothing when updating from a detection
    # Landmark (kps) smoothing: One Euro filter, adaptive to motion speed.
    # The existing trk_alpha above is a FIXED-rate EMA - same smoothing
    # strength whether the face is still or moving fast. That is the known
    # limitation the One Euro filter (Casiez/Roussel/Vogel 2012) exists to
    # fix, and it is what MediaPipe's own production face landmarker uses
    # internally for exactly this reason.
    #
    # Values below were swept empirically (test_smoothing.py), not just
    # solved theoretically: 0.1153 is the min_cutoff that reproduces
    # trk_alpha's exact behaviour at rest, but 0.06 measured BETTER on both
    # axes at once - still-phase jitter slightly below the old fixed EMA
    # (not just similar), while fast-motion lag dropped 78.7% (33px -> 7px
    # in the simulated head-turn). kps_beta controls how fast smoothing
    # relaxes as measured per-frame speed increases - this is what targets
    # flicker specifically during fast movement without under-smoothing a
    # still or slow-moving face.
    "kps_min_cutoff": 0.06,
    "kps_beta": 0.015,
    # --- alpha-beta motion filter (bbox + kps velocity) --------------------
    # Replaces the flat EMA over MEASURED velocity that this class used up to
    # v11.2.5. That EMA had no notion of acceleration or of its own prediction
    # being wrong: it averaged raw consecutive-detection deltas, so on a fast
    # head turn (accelerate - travel - decelerate) the velocity it handed to
    # predict() was always about one EMA time-constant stale, and on a
    # direction reversal it kept pointing the old way until enough new
    # measurements outvoted the old ones. With a sparse detector cadence
    # "enough measurements" is a large fraction of a second, which is exactly
    # the interval over which the carried face ends up pasted far from the
    # real one.
    #
    # An alpha-beta filter (Kalman with fixed gains; no covariance to carry,
    # so it costs nothing per frame) closes that loop: it PREDICTS where the
    # face should be, then splits the prediction error between a position and
    # a velocity correction. A prediction that comes back right leaves the
    # velocity alone - which is the correct response to constant motion, and
    # the thing the old EMA got wrong in the other direction (see the note at
    # the update site about never feeding a residual back AS velocity).
    #
    # ab_beta is set from ab_alpha by the Benedict-Bordner critically-damped
    # relation beta = a^2/(2-a) when left at 0 (the default), which is the
    # standard choice and keeps the filter from ringing after a turn.
    # ab_alpha 0.85 converges to a true constant velocity within two
    # detections; the old EMA needed four to get within 10%.
    "ab_alpha": 0.85,
    "ab_beta": 0.0,          # 0 = derive from ab_alpha (critically damped)
}


# How fast the landmark-size EMA follows a real change in apparent face size.
# Per DETECTION, not per frame, so the time constant does not move with the
# detector cadence. 0.20 is about a five-detection response - fast enough to
# follow a subject walking toward the camera, slow enough that a detector box
# wobbling frame to frame does not reach the paste.
_KPS_SCALE_EMA = 0.20


def _ab_beta() -> float:
    """Velocity gain for the alpha-beta filter, derived if not set."""
    b = float(_P.get("ab_beta", 0.0) or 0.0)
    if b > 0.0:
        return b
    a = float(_P.get("ab_alpha", 0.85) or 0.85)
    a = min(0.999, max(0.001, a))
    return (a * a) / (2.0 - a)


def configure(**kw):
    """Override tunables (called once from core_pipeline with config values)."""
    for k, v in kw.items():
        if k in _P and v is not None:
            _P[k] = v


# --------------------------------------------------------------------------
# Canonical mask construction (cached — shape depends only on crop size)
# --------------------------------------------------------------------------
_TEMPLATE_CACHE: dict[int, np.ndarray] = {}


def canonical_template(size: int) -> np.ndarray:
    """Soft superelliptical face template in aligned space, float32 in [0,1].

    The ArcFace 5-point similarity transform puts eyes/nose/mouth at fixed
    canonical positions, so this one shape fits every pose. That is precisely
    what makes it flicker-free: nothing about it varies frame to frame.
    """
    cached = _TEMPLATE_CACHE.get(size)
    if cached is not None:
        return cached

    ys, xs = np.mgrid[0:size, 0:size].astype(np.float32)
    xs = (xs + 0.5) / size
    ys = (ys + 0.5) / size
    dx = np.abs(xs - _P["mask_cx"]) / _P["mask_rx"]
    dy = np.abs(ys - _P["mask_cy"]) / _P["mask_ry"]
    n = float(_P["mask_power"])
    r = np.power(np.power(dx, n) + np.power(dy, n), 1.0 / n)

    # soft rolloff: 1 inside, 0 outside, smooth band in between
    mask = np.clip((1.12 - r) / 0.28, 0.0, 1.0).astype(np.float32)

    # ...and a second rolloff that guarantees the template reaches zero at the
    # crop border, so the paste never has a hard edge to give itself away.
    b = float(_P.get("mask_border", 0.08) or 0.0)
    edge_roll = None
    if b > 0.0:
        edge = np.minimum(np.minimum(xs, 1.0 - xs), np.minimum(ys, 1.0 - ys))
        edge_roll = np.clip(edge / b, 0.0, 1.0).astype(np.float32)
        mask *= edge_roll

    k = int(max(3, round(size * _P["mask_feather"]))) | 1
    mask = cv2.GaussianBlur(mask, (k, k), 0)
    if edge_roll is not None:
        # Applied again AFTER the feather: the Gaussian has a ~21 px kernel and
        # smears interior weight back out to the border, which left 0.296 there
        # on the first pass. Re-applying pins the border to exactly zero.
        mask *= edge_roll
    mask = np.clip(mask, 0.0, 1.0).astype(np.float32)
    _TEMPLATE_CACHE[size] = mask
    return mask


# --------------------------------------------------------------------------
# ArcFace 5-point alignment.
#
# inswapper builds its own 128x128 aligned crop from the 5 keypoints and hands
# back the affine it used. That affine is only available on frames where the
# ONNX forward pass actually ran. To composite a CACHED aligned result onto a
# LATER frame - which is what makes every output frame a real composite rather
# than a stale ROI pasted from another moment in time - the same affine has to
# be derivable from keypoints alone. This is that derivation: the canonical
# ArcFace destination points plus a Umeyama similarity fit, i.e. exactly what
# insightface does internally, reimplemented here so the module keeps its
# numpy+cv2-only dependency footprint and stays unit-testable.
#
# Any residual disagreement with the installed insightface build is cancelled
# out at runtime by aligned_correction() below, so this never has to match
# bit-for-bit to be safe.
# --------------------------------------------------------------------------
ARCFACE_DST = np.array([
    [38.2946, 51.6963],
    [73.5318, 51.5014],
    [56.0252, 71.7366],
    [41.5493, 92.3655],
    [70.7299, 92.2041],
], dtype=np.float32)


def _umeyama(src: np.ndarray, dst: np.ndarray):
    """Least-squares similarity (scale+rotation+translation) src -> dst."""
    src = np.asarray(src, np.float64).reshape(-1, 2)
    dst = np.asarray(dst, np.float64).reshape(-1, 2)
    num = src.shape[0]
    if num < 2:
        return None
    src_mean = src.mean(axis=0)
    dst_mean = dst.mean(axis=0)
    src_d = src - src_mean
    dst_d = dst - dst_mean
    A = (dst_d.T @ src_d) / num
    d = np.ones(2, np.float64)
    if np.linalg.det(A) < 0:
        d[1] = -1.0
    try:
        U, S, Vt = np.linalg.svd(A)
    except np.linalg.LinAlgError:
        return None
    rank = np.linalg.matrix_rank(A)
    if rank == 0:
        return None
    if rank == 1:
        if np.linalg.det(U) * np.linalg.det(Vt) > 0:
            R = U @ Vt
        else:
            keep = d[1]
            d[1] = -1.0
            R = U @ np.diag(d) @ Vt
            d[1] = keep
    else:
        R = U @ np.diag(d) @ Vt
    var_src = src_d.var(axis=0).sum()
    scale = 1.0 if var_src <= 1e-12 else float((S @ d) / var_src)
    M = np.zeros((2, 3), np.float32)
    M[:, :2] = (scale * R).astype(np.float32)
    M[:, 2] = (dst_mean - scale * (R @ src_mean)).astype(np.float32)
    return M


def _arcface_dst(image_size: int):
    if image_size % 112 == 0:
        ratio = float(image_size) / 112.0
        diff_x = 0.0
    else:
        ratio = float(image_size) / 128.0
        diff_x = 8.0 * ratio
    return ARCFACE_DST * ratio + np.array([diff_x, 0.0], np.float32)


def estimate_norm(kps, image_size: int = 128):
    """Image-space -> aligned-crop affine for 5-point ArcFace keypoints."""
    try:
        lmk = np.asarray(kps, np.float32).reshape(-1, 2)
    except Exception:
        return None
    if lmk.shape[0] < 5:
        return None
    lmk = lmk[:5]
    dst = _arcface_dst(image_size)
    return _umeyama(lmk, dst)


def landmark_fit_error(kps, image_size: int = 128):
    """0..~1+ : how badly the 5 keypoints disagree with ANY single rigid pose.

    A real face's 5 landmarks - however extreme the pose - come from one rigid
    structure, so a similarity transform (rotation+scale+translation) can
    always be found that lands them close to the ArcFace canonical template.
    When a detector's landmark regression is unreliable - pushed past where it
    was trained by an extreme yaw/pitch, an eye guessed from hair, a mouth
    placed by the shape prior rather than the image - the 5 points stop being
    mutually consistent with any single pose, and the BEST-FIT residual spikes
    even though det_score and each individual coordinate can look
    unremarkable in isolation. That is exactly the failure this measures, and
    exactly what malforms compositing: fitting an affine to inconsistent
    points does not fail loudly, it silently returns a plausible-looking M
    that does not match the real head, so the aligned crop reprojects onto
    the wrong place at the wrong rotation and scale - a rotated, misplaced
    rectangle is the visible result.

    Unlike _frontal_score/_pitch_score (heuristics on where individual points
    sit), this is a direct geometric consistency check, so it also catches
    configurations that do not trip either heuristic's simple thresholds.

    Returns None if a transform cannot even be attempted (e.g. degenerate
    points that make the source covariance singular) - that is itself a
    reliability failure and should be treated as maximally unreliable by the
    caller.
    """
    try:
        lmk = np.asarray(kps, np.float32).reshape(-1, 2)[:5]
    except Exception:
        return None
    if lmk.shape[0] < 5:
        return None
    dst = _arcface_dst(image_size)
    M = _umeyama(lmk, dst)
    if M is None:
        return None
    try:
        proj = lmk @ M[:, :2].T + M[:, 2]
        err = np.linalg.norm(proj - dst, axis=1)
        # The jaw is not rigid. A wide-open mouth pulls the two mouth
        # corners far from the closed-mouth template and the whole face
        # was rejected, so the original showed. Eyes and nose stay put
        # on a real face and still fail when the read is hair or skull.
        err = err[:3]
        eye_dist = float(np.linalg.norm(dst[0] - dst[1])) + 1e-6
        return float(np.mean(err) / eye_dist)
    except Exception:
        return None


def _as3x3(M):
    T = np.eye(3, dtype=np.float32)
    T[:2, :] = np.asarray(M, np.float32).reshape(2, 3)
    return T


def aligned_correction(kps, M_actual, image_size: int):
    """Aligned-space correction C with  C @ estimate_norm(kps) == M_actual.

    Guarantees the reprojected crop lines up exactly with whatever affine the
    installed inswapper build actually used, so a cached aligned result can be
    re-pasted on a later frame with no seam at the hand-over.
    """
    if M_actual is None:
        return None
    est = estimate_norm(kps, image_size)
    if est is None:
        return None
    try:
        C = _as3x3(M_actual) @ np.linalg.inv(_as3x3(est))
        return C[:2, :].astype(np.float32)
    except Exception:
        return None


def scale_affine(M, k):
    """Scale an image->crop affine so it targets a crop k times larger.

    The swapper hands back an affine that maps image space into ITS OWN crop
    (128px). When the restored crop is kept at a higher resolution, every
    later consumer - aligned_correction, the mask, paste_back - must be told
    about a crop that is k times bigger, or the face is pasted at 1/k size.
    Pre-multiplying by a uniform scale is exactly that statement.
    """
    if M is None or k == 1.0:
        return M
    try:
        S = np.array([[float(k), 0.0, 0.0],
                      [0.0, float(k), 0.0],
                      [0.0, 0.0, 1.0]], np.float32)
        return (S @ _as3x3(M))[:2, :].astype(np.float32)
    except Exception:
        return M


def crop_upscale_ok(old_size: int, new_size: int) -> bool:
    """May a restored crop of new_size be kept in place of one of old_size?

    Keeping the bigger crop only works if the ArcFace template itself scales
    by the same factor, because every later consumer recomputes
    estimate_norm(kps, new_size) and the correction must cancel exactly.
    _arcface_dst switches branch on image_size % 112, so 512 from 128 scales
    perfectly (ratio 4, diff_x 32 both ways) while 448 from 128 does NOT -
    it lands on the 112 branch with diff_x 0 and the face would be pasted
    offset by ~46px of crop space. Verify the identity rather than trusting
    the ratio; it costs two tiny array builds and it is the difference
    between a sharper face and a misplaced one.
    """
    try:
        old_size = int(old_size)
        new_size = int(new_size)
    except Exception:
        return False
    if new_size == old_size:
        return True
    if old_size <= 0 or new_size < old_size:
        return False
    k = float(new_size) / float(old_size)
    try:
        return bool(np.allclose(_arcface_dst(new_size),
                                _arcface_dst(old_size) * k, atol=1e-3))
    except Exception:
        return False


def native_crop_span(M, size: int) -> float:
    """How many IMAGE pixels the aligned crop of `size` actually covers.

    M maps image space into the crop, so its linear part's scale is
    crop-pixels-per-image-pixel. Inverting that gives the face's true
    on-screen span - the only honest ceiling on useful crop resolution,
    because paste_back resamples the crop down to exactly this many pixels.
    """
    try:
        A = np.asarray(M, np.float32).reshape(2, 3)[:, :2]
        s = math.sqrt(abs(float(np.linalg.det(A))))
        if not (s > 1e-6):
            return float(size)
        return float(size) / s
    except Exception:
        return float(size)


def choose_crop_size(M, base: int, max_size: int) -> int:
    """Smallest admissible crop size that does not throw plate detail away.

    Keeping every restored crop at the restorer's native 512 would be 16x the
    compositing work of 128 on EVERY output frame (measured 28.6 ms vs 6.85 ms
    at 1080p) and most of it wasted: paste_back immediately resamples the crop
    down to the face's on-screen span, so resolution above that span buys
    nothing visible. Resolution BELOW it is the real defect - that is the
    enhancer's output being crushed to 128 and then re-upsampled by the paste.
    So: pick the smallest size at or above the on-screen span, clamp to what
    the restorer gave us, and only ever use sizes whose ArcFace template
    scales exactly (crop_upscale_ok).
    """
    base = int(base)
    max_size = int(max_size)
    try:
        cap = int(_P.get("restore_crop_max", 512) or 0)
        if cap > 0:
            max_size = min(max_size, cap)
    except Exception:
        pass
    if max_size <= base:
        return base
    # Half a pixel of slack: the span comes out of a sqrt of a determinant,
    # so an exact 3x face measures 384.0000001 and without the slack it would
    # be rounded UP to the next size and cost 16x the compositing for nothing.
    native = native_crop_span(M, base) - 0.5
    if base >= native:
        return base
    best = base
    k = 2
    while base * k <= max_size:
        cand = base * k
        if crop_upscale_ok(base, cand):
            best = cand
            if cand >= native:
                break
        k += 1
    return best


def apply_correction(C, M):
    if C is None:
        return M
    try:
        return (_as3x3(C) @ _as3x3(M))[:2, :].astype(np.float32)
    except Exception:
        return M


def _landmarks_to_aligned(lmk, M, size):
    """Project image-space landmarks into the aligned crop using affine M."""
    if lmk is None:
        return None
    try:
        pts = np.asarray(lmk, dtype=np.float32).reshape(-1, 2)
        if pts.shape[0] < 8:
            return None
        A = np.asarray(M, dtype=np.float32).reshape(2, 3)
        out = pts @ A[:, :2].T + A[:, 2]
        # keep only points that landed near the crop
        ok = (out[:, 0] > -size * 0.35) & (out[:, 0] < size * 1.35) & \
             (out[:, 1] > -size * 0.35) & (out[:, 1] < size * 1.35)
        out = out[ok]
        return out if len(out) >= 8 else None
    except Exception:
        return None


def hull_mask(pts_aligned, size) -> np.ndarray | None:
    """Convex hull of aligned landmarks, dilated + feathered, float32 [0,1]."""
    if pts_aligned is None:
        return None
    try:
        m = np.zeros((size, size), np.uint8)
        hull = cv2.convexHull(np.round(pts_aligned).astype(np.int32))
        cv2.fillConvexPoly(m, hull, 255)
        d = int(max(1, round(size * _P["hull_dilate"])))
        m = cv2.dilate(m, np.ones((d * 2 + 1, d * 2 + 1), np.uint8), 1)
        k = int(max(3, round(size * 0.10))) | 1
        m = cv2.GaussianBlur(m, (k, k), 0)
        return (m.astype(np.float32) / 255.0)
    except Exception:
        return None


# --------------------------------------------------------------------------
# Occlusion guard (optional): drop clearly non-skin pixels from the mask.
# --------------------------------------------------------------------------
def skin_confidence(aligned_bgr: np.ndarray, mask: np.ndarray) -> np.ndarray:
    """Per-pixel [0,1] confidence that a pixel belongs to the tracked face.

    Uses the face's OWN median chroma (not a fixed skin model), so it works
    across skin tones. Intended to suppress a hand, a microphone or another
    person's cheek that intrudes into the aligned crop during a hug.
    """
    try:
        full = aligned_bgr.shape[0]
        # The result is Gaussian-blurred to a twelfth of the crop before use, so
        # gathering it at half scale and scaling back changes it by at most
        # ~0.08 (mean 0.014) while costing 45% less.
        if full >= 96:
            small = cv2.resize(aligned_bgr, (full // 2, full // 2), interpolation=cv2.INTER_AREA)
            m_small = cv2.resize(mask, (full // 2, full // 2), interpolation=cv2.INTER_AREA)
            conf = skin_confidence(small, m_small)
            return cv2.resize(conf, (full, full), interpolation=cv2.INTER_LINEAR)
        ycc = cv2.cvtColor(aligned_bgr, cv2.COLOR_BGR2YCrCb).astype(np.float32)
        cr, cb = ycc[:, :, 1], ycc[:, :, 2]
        core = mask > 0.75
        if int(core.sum()) < 64:
            return np.ones(mask.shape, np.float32)
        mcr, mcb = float(np.median(cr[core])), float(np.median(cb[core]))
        scr = float(np.std(cr[core])) + 3.0
        scb = float(np.std(cb[core])) + 3.0
        d = np.sqrt(((cr - mcr) / scr) ** 2 + ((cb - mcb) / scb) ** 2)
        conf = np.clip(1.0 - (d - 2.2) / 2.6, 0.0, 1.0).astype(np.float32)
        k = max(3, (aligned_bgr.shape[0] // 12) | 1)
        conf = cv2.GaussianBlur(conf, (k, k), 0)
        floor = float(_P["occl_min_keep"])
        return (floor + (1.0 - floor) * conf).astype(np.float32)
    except Exception:
        return np.ones(mask.shape, np.float32)


def _face_stats(aligned_bgr):
    """This face's own skin statistics, and every pixel as a normalised residual.

    The sampling zone is forehead and outer cheeks only - never the eyes, brows
    or mouth, which are legitimately not skin and would poison the reference.

    The variance floors are PROPORTIONAL to the face's own brightness, not
    absolute. With absolute floors the normalisation stops being scale
    invariant: dimming a shot scales the measured spread but not the floor, so
    every learned residual shifts and the whole face reads as novel. Measured
    with absolute floors, a 45% light drop produced a 14.5% false cut on every
    frame afterwards.
    """
    h, w = aligned_bgr.shape[:2]
    if h != w:
        return None
    ycc = cv2.cvtColor(aligned_bgr, cv2.COLOR_BGR2YCrCb).astype(np.float32)
    yy, cr, cb = ycc[:, :, 0], ycc[:, :, 1], ycc[:, :, 2]
    ys, xs = np.mgrid[0:h, 0:w].astype(np.float32)
    ys = (ys + 0.5) / h
    xs = (xs + 0.5) / w
    inface = canonical_template(h) > 0.5
    zone = inface & (((ys > 0.14) & (ys < 0.28))
                     | ((ys > 0.44) & (ys < 0.62) & ((xs < 0.33) | (xs > 0.67))))
    if int(zone.sum()) < 100:
        return None
    mcr = float(np.median(cr[zone]))
    mcb = float(np.median(cb[zone]))
    my = float(np.median(yy[zone]))
    fl = max(2.0, 0.06 * my)
    scr = float(np.std(cr[zone])) + fl
    scb = float(np.std(cb[zone])) + fl
    sy = float(np.std(yy[zone])) + fl * 1.4
    nrm = np.dstack([(yy - my) / sy, (cr - mcr) / scr, (cb - mcb) / scb]).astype(np.float32)
    return nrm, inface, ys


def _occ_work(aligned_bgr):
    """Downscale to the occlusion working resolution (no-op if already small)."""
    h = aligned_bgr.shape[0]
    wrk = int(_P.get("occ_work", 192) or 192)
    if h <= wrk:
        return aligned_bgr
    return cv2.resize(aligned_bgr, (wrk, wrk), interpolation=cv2.INTER_AREA)


def occluder_keep(aligned_bgr, ref=None, nref=0):
    """1 on the face, 0 on an object held in front of it.

    The previous implementation could not fire AT ALL. It searched a box of
    rows 0.58-0.66 by columns 0.36-0.64 - 2.24% of the crop - and then
    required a connected component of at least 4% of the crop to accept it.
    The minimum area was larger than the entire search window, so the test
    was arithmetically unsatisfiable at every crop size and the function
    returned all-ones on every frame of every job. Verified against ice cream,
    a spoon and a hand: 0.00% removed in every case.

    It had been narrowed to that box, and given that floor, to stop it cutting
    the lower lip and the chin - because its only evidence was "this pixel is
    off the face's median chroma", and lips ARE off it. The replacement keeps
    the lip and chin by using evidence that actually separates them from an
    object, and so does not need to be blinded:

      1. NOT SKIN - off this face's own chroma or luma, in units of the face's
         own spread, so one threshold works on any skin tone under any light.
      2. NOT ITS OWN FACE - differs from the per-pixel appearance model this
         identity has built up in aligned space (see TrackState.occ_ref). A
         beard, glasses, a birthmark or a scar match their own history; ice
         cream in front of them does not. This is what lets the search cover
         the whole face instead of a 2% box, and it is also what catches food
         held OVER a beard, which a location-only exemption cannot.
      3. INTRUDING - the blob reaches outside the face oval or touches the
         crop border. This is the geometric fact that separates the lips from
         a held object: an object is attached to a hand, an arm, a cone, so
         its foreign region continues outside the face. The lips are an
         interior island and never touch the boundary. It is also what keeps
         an open mouth: the cavity is interior too.
      4. BIG ENOUGH - as a fraction of the face area, not of the crop.

    All four must hold. Nothing is cut during the first occ_ref_warm frames,
    while the appearance model is still forming: cutting then would punch a
    hole in a beard before the model can vouch for it.
    """
    try:
        H, W = aligned_bgr.shape[:2]
        small = _occ_work(aligned_bgr)
        h, w = small.shape[:2]
        st = _face_stats(small)
        if st is None:
            return np.ones((H, W), np.float32)
        nrm, inface, ys = st

        if int(nref) < int(_P.get("occ_ref_warm", 12)):
            return np.ones((H, W), np.float32)

        notskin = ((np.sqrt(nrm[:, :, 1] ** 2 + nrm[:, :, 2] ** 2)
                    > float(_P.get("occ_chroma", 2.6)))
                   | (np.abs(nrm[:, :, 0]) > float(_P.get("occ_luma", 2.6))))
        # Eyes and brows are not skin and never an occluder.
        notskin &= ~((ys > 0.24) & (ys < 0.46))

        novel = np.ones((h, w), bool)
        if ref is not None and getattr(ref, "shape", None) == nrm.shape:
            d_ch = np.sqrt((nrm[:, :, 1] - ref[:, :, 1]) ** 2
                           + (nrm[:, :, 2] - ref[:, :, 2]) ** 2)
            d_lu = np.abs(nrm[:, :, 0] - ref[:, :, 0])
            novel = ((d_ch > float(_P.get("occ_ref_chroma", 2.6)))
                     | (d_lu > float(_P.get("occ_ref_luma", 2.6))))

        k = max(3, (h // 64) | 1)
        cand = cv2.morphologyEx((notskin & novel).astype(np.uint8), cv2.MORPH_OPEN,
                                cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k)))
        if int(cand.max()) == 0:
            return np.ones((H, W), np.float32)

        face_area = float(inface.sum())
        outside = ~inface
        border = np.zeros((h, w), bool)
        b = max(2, h // 64)
        border[:b, :] = border[-b:, :] = border[:, :b] = border[:, -b:] = True
        # A band just inside the edge of the face region. Requiring a blob to
        # extend fully OUTSIDE the oval was too brittle: the part of a held
        # object that bridges to the hand is often itself close enough to skin
        # colour not to register, leaving the detected blob entirely inside
        # the oval with nothing outside it to measure. Reaching the EDGE of
        # the face is the robust version of the same fact, and the lips and
        # the mouth cavity sit far inside it - measured, the lip blob stays
        # about 0.16 of the crop clear of this band.
        rim_px = max(2, int(round(h * float(_P.get("occ_rim", 0.055)))))
        rim = inface & ~cv2.erode(
            inface.astype(np.uint8),
            cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (rim_px * 2 + 1,) * 2)
        ).astype(bool)
        n, labels, stats, _ = cv2.connectedComponentsWithStats(cand, connectivity=8)
        occ = np.zeros((h, w), np.uint8)
        min_frac = float(_P.get("occ_min_frac", 0.010))
        out_frac = float(_P.get("occ_out_frac", 0.08))
        rim_frac = float(_P.get("occ_rim_frac", 0.02))
        for i in range(1, n):
            comp = labels == i
            a_in = float((comp & inface).sum())
            if a_in / max(1.0, face_area) < min_frac:
                continue
            a_out = float((comp & outside).sum())
            a_tot = max(1.0, a_in + a_out)
            a_rim = float((comp & rim).sum())
            big = (a_in / max(1.0, face_area) >= float(_P.get("occ_big_frac", 0.045))
                   and int(nref) >= 2 * int(_P.get("occ_ref_warm", 12)))
            if (bool((comp & border).any())
                    or a_out / a_tot > out_frac
                    or a_rim / a_tot > rim_frac
                    or big):
                occ[comp] = 255
        if int(occ.max()) == 0:
            return np.ones((H, W), np.float32)
        kf = max(3, (h // 20) | 1)
        soft = cv2.GaussianBlur(occ, (kf, kf), 0).astype(np.float32) / 255.0
        keep = np.clip(1.0 - soft, 0.0, 1.0).astype(np.float32)
        if (h, w) != (H, W):
            keep = cv2.resize(keep, (W, H), interpolation=cv2.INTER_LINEAR)
        return keep
    except Exception as e:
        log.debug("occluder detection skipped: %s", e)
        return np.ones(aligned_bgr.shape[:2], np.float32)


def update_face_ref(ref, nref, aligned_bgr, keep):
    """Learn this face's per-pixel appearance - but never under an occluder.

    Learning where the mask was cut would teach the model the ice cream, and
    the model would then vouch for it on the next frame.
    """
    try:
        small = _occ_work(aligned_bgr)
        st = _face_stats(small)
        if st is None:
            return ref, nref
        nrm = st[0]
        k = keep
        if k.shape[:2] != nrm.shape[:2]:
            k = cv2.resize(k, (nrm.shape[1], nrm.shape[0]), interpolation=cv2.INTER_AREA)
        if ref is None or getattr(ref, "shape", None) != nrm.shape:
            return nrm.copy(), 1
        a = float(_P.get("occ_ref_ema", 0.10)) * (k > 0.9).astype(np.float32)[:, :, None]
        return (ref * (1.0 - a) + nrm * a).astype(np.float32), int(nref) + 1
    except Exception as e:
        log.debug("appearance model update skipped: %s", e)
        return ref, nref


def _bb_iou(a, b) -> float:
    """Axis-aligned IoU for two [x1,y1,x2,y2] boxes. 0 on any failure."""
    try:
        ax1, ay1, ax2, ay2 = [float(v) for v in np.asarray(a, np.float32).reshape(4)]
        bx1, by1, bx2, by2 = [float(v) for v in np.asarray(b, np.float32).reshape(4)]
        ix1, iy1 = max(ax1, bx1), max(ay1, by1)
        ix2, iy2 = min(ax2, bx2), min(ay2, by2)
        inter = max(0.0, ix2 - ix1) * max(0.0, iy2 - iy1)
        if inter <= 0.0:
            return 0.0
        area_a = max(1.0, (ax2 - ax1) * (ay2 - ay1))
        area_b = max(1.0, (bx2 - bx1) * (by2 - by1))
        return float(inter / (area_a + area_b - inter + 1e-6))
    except Exception:
        return 0.0


# --------------------------------------------------------------------------
# Per-identity temporal memory
# --------------------------------------------------------------------------
class TrackState:
    """Temporal memory for one identity slot.

    Holds everything that must NOT be recomputed independently per frame:
    the canonical mask, the colour correction, bbox/kps velocity, and the
    long-term identity embedding.
    """

    __slots__ = ("slot", "bbox", "obs_bbox", "kps", "lmk", "vel_bbox", "vel_kps",
                 "emb", "id_lock", "hits", "missed", "mask_ema", "cm_dmean", "cm_ratio",
                 "flip_votes", "crossing", "last_face", "det_score", "last_hit_bbox",
                 "hull_ema", "occl_w", "alpha_ema", "last_dt", "last_hit_kps", "_contact_vel",
                 "fake", "fake_corr", "fake_size", "fake_frame",
                 "_frame_wh", "_paste_frozen", "_reacquired",
                 "confirm_hits", "_confirm_ease", "ab_bbox", "ab_kps",
                 "skin_ref", "skin_hits", "kps_scale", "skin_miss",
                 "pose_ok", "occ_keep", "grain_ema", "mblur_ema",
                 "occ_ref", "occ_nref", "occn_keep", "prof_w", "eat_w",
                 "occ_prev_g",                  # v11.2.206: last frame's face crop (grey, 128 px) for the cut's motion
                 "occ_face_ref",                # v11.2.206: how often the occlusion model saw face at each pixel lately
                 "occn_core")                   # v11.2.206: the mouth rule's cut alone, smoothed as in 11.2.205 (eating rule)

    def __init__(self, slot=0):
        self.slot = slot
        self.bbox = None
        self.obs_bbox = None      # last RAW detection (unsmoothed) — association
        self.kps = None
        self.lmk = None
        self.vel_bbox = np.zeros(4, np.float32)
        self.vel_kps = None
        # Alpha-beta filter position states. Deliberately NOT the same thing
        # as bbox/kps (display-smoothed, and advanced with confidence damping
        # by predict()) nor as last_hit_bbox/last_hit_kps (raw measurements).
        # The filter needs its own undamped estimate to predict from, or the
        # residual it measures is contaminated by the display damping.
        self.ab_bbox = None
        self.ab_kps = None
        # This identity's own remembered face chroma (median Cr, Cb sampled at
        # its landmarks), learned only from frames where the face was actually
        # visible. skin_confidence() in this module answers a DIFFERENT
        # question: it takes its reference from the mask core of the crop it is
        # handed, so when an occluder covers that core the occluder's colour
        # BECOMES the reference and it confidently keeps the occluder while
        # trimming the real skin at the edges. It cannot detect occlusion of
        # the centre by construction. A reference carried across time can.
        self.skin_ref = None
        self.skin_hits = 0
        # Consecutive content-gate rejections. The gate learns its reference
        # ONLY from accepted frames, so without this the reference freezes the
        # moment it starts rejecting and can never recover. See _content_visible.
        self.skin_miss = 0
        # Did this identity's LAST accepted read describe a good pose? The
        # pose gate keeps painting through a marginal pose only for a head it
        # was already painting - see _kps_reliable's second threshold.
        self.pose_ok = False
        self.occ_keep = None
        # Plate-matching state. Both are per-frame MEASUREMENTS of the plate,
        # and a raw per-frame measurement jitters - which would make the grain
        # amplitude and the blur length crawl, a worse artefact than the one
        # being fixed. Smoothed, they track the shot instead of the frame.
        self.grain_ema = None
        self.mblur_ema = None
        # Per-pixel model of what THIS face looks like in aligned space, held
        # as NORMALISED residuals against each frame's own skin statistics.
        # The aligned crop is pose-normalised, so a beard, glasses, a
        # birthmark or a scar sits at the same crop coordinates on every frame
        # and matches its own history; an object held in front of the face
        # does not. Residuals rather than absolute YCrCb is what lets it
        # survive a lighting change or a cut - measured, storing absolute
        # values made a 45% light drop read the whole beard as novel and cut
        # 14.5% of the face on every frame afterwards.
        self.occ_ref = None
        self.occ_nref = 0
        self.occn_keep = None
        self.prof_w = None
        self.eat_w = 0.0
        self.occ_prev_g = None          # v11.2.206
        self.occ_face_ref = None
        self.occn_core = None
        # Slowly-smoothed SIZE of this identity's landmark constellation.
        # Position and size do not deserve the same filter; sharing one is
        # what makes a pasted face pulse. See the rescale site below.
        self.kps_scale = None
        self.emb = None
        # Frozen gallery identity. Set on the first confident bind and never
        # replaced by a different person (that was the male↔female re-entry
        # swap: a new face overwrote the slot, then the original person came
        # back looking "wrong" for their own slot).
        self.id_lock = None
        self.hits = 0
        self.missed = 0
        self.mask_ema = None
        self.cm_dmean = None     # np.float32[3]  LAB mean delta
        self.cm_ratio = None     # np.float32[3]  LAB std ratio
        self.flip_votes = 0
        self.crossing = False
        self.last_face = None
        self.det_score = 0.0
        self.last_hit_bbox = None
        self.last_dt = 1.0        # output frames between the last two detections
        self.last_hit_kps = None  # raw keypoints at the last real detection
        self._contact_vel = None  # v11.2.176: (bbox velocity, kps velocity) of the partner while in contact
        self.hull_ema = None      # smoothed landmark hull (aligned space)
        self.occl_w = 0.0         # CONTINUOUS occlusion weight in [0,1]
        self.alpha_ema = 1.0      # smoothed composite opacity
        # Cached aligned swap result. Holding the 128x128 crop (not a
        # full-frame paste) is what lets a later frame be composited with its
        # OWN background, its OWN geometry and its OWN lighting while reusing
        # the expensive ONNX forward pass.
        self.fake = None
        self.fake_corr = None     # aligned-space correction for this build
        self.fake_size = 0
        self.fake_frame = -10 ** 9
        # Last known frame size (W, H) from core assign/bind — used to freeze
        # constant-velocity prediction once the face has mostly left the shot.
        self._frame_wh = None
        self._paste_frozen = False  # True: stop advancing; dead for paste
        self._reacquired = False    # set by update() for core geom-stub clear
        self.confirm_hits = 0       # v11.1.10: reliable hits needed after reacquire
        self._confirm_ease = 0      # v11.2.1: neutralized (was CinemaQA soft ease-in)

    # -- geometry -------------------------------------------------------
    @property
    def established(self) -> bool:
        return self.hits >= int(_P["trk_lock_hits"]) or self.id_lock is not None

    def _commit_identity(self, e):
        """Seed or refresh identity. Never replace a lock with a different person."""
        if e is None:
            return
        e = np.asarray(e, np.float32)
        n = float(np.linalg.norm(e)) + 1e-6
        e = e / n
        if self.id_lock is None:
            self.id_lock = e
            self.emb = e
            return
        sim = float(np.dot(self.id_lock, e))
        if sim < 0.38:
            return
        if self.emb is None:
            self.emb = e
        else:
            mix = self.emb * 0.90 + e * 0.10
            self.emb = mix / (float(np.linalg.norm(mix)) + 1e-6)
        if sim >= 0.55:
            mix2 = self.id_lock * 0.97 + e * 0.03
            self.id_lock = mix2 / (float(np.linalg.norm(mix2)) + 1e-6)

    @property
    def match_bbox(self):
        """One-step-ahead prediction from the last RAW observation.

        Association must never use the EMA-smoothed bbox: smoothing lags, and
        when two people close on each other at different speeds the lagged
        estimates can cross over each other while the real faces have not.
        That lag was a direct cause of face-1/face-2 swapping in a hug.
        """
        base = self.obs_bbox if self.obs_bbox is not None else self.bbox
        if base is None:
            return None
        # Velocity is per OUTPUT frame, so the prediction has to span the
        # detector's actual interval - otherwise, at a cadence above 1, the
        # gate that decides who a detection belongs to is comparing against a
        # position the face left several frames ago.
        return (np.asarray(base, np.float32)
                + self.vel_bbox * float(max(1.0, self.last_dt))).astype(np.float32)

    def predict(self, n_frames: float = 1.0):
        """Advance geometry by ``n_frames`` output frames at constant velocity.

        ``n_frames`` exists because velocity is stored PER OUTPUT FRAME (see
        update()) while the caller may only get to advance a track once per
        detector interval. Assuming those are the same thing - which the
        previous signature forced - made the prediction lag by exactly the
        detection cadence, so the carried face trailed the real one during
        every fast movement and then snapped forward on the next detection.
        That snap is visible as a flick.

        v11.1.9 ReentrySafe: once the bbox is mostly outside the last known
        frame, stop advancing and mark paste-dead. Constant-velocity carry
        while off-screen compounds into empty-space / body paste on return.
        """
        n = max(0.0, float(n_frames))
        if n <= 0.0:
            return self.bbox
        steps = max(1, int(round(n)))
        m0 = self.missed
        self.missed = m0 + steps
        cv_ = getattr(self, "_contact_vel", None)
        if cv_ is not None and not self._paste_frozen:
            # v11.2.176: in contact, carried with the partner's motion (MultiFaceTracker._contact_motion), not on at its own
            vb, vk = cv_
            if self.bbox is not None:
                self.bbox = (self.bbox + vb * float(steps)).astype(np.float32)
            if self.obs_bbox is not None:
                self.obs_bbox = (self.obs_bbox + vb * float(steps)).astype(np.float32)
            if self.kps is not None and vk is not None:
                self.kps = (self.kps + vk * float(steps)).astype(np.float32)
            return self.bbox
        # Already left the frame — count the miss but do not keep coasting.
        if self._paste_frozen:
            return self.bbox
        # Confidence in an extrapolation decays per FRAME advanced, so the
        # damping has to be summed over the frames being covered. Applying the
        # end-of-interval damping factor to the whole interval at once (n * damp)
        # under-advances a multi-frame catch-up badly - a 5-frame advance moved
        # about 2.2 frames' worth - which shows up as the carried face trailing
        # the real one and then snapping forward on the next detection.
        # Fast motion must not be damped. 0.85 per frame made a 5-frame gap
        # travel only ~3 frames, so the paste trailed a quick head turn and
        # then snapped. Slow motion keeps the old damping so a still face
        # does not drift.
        speed = 0.0
        if self.vel_bbox is not None:
            speed = float(np.hypot(float(self.vel_bbox[0]), float(self.vel_bbox[1])))
        damp = 0.98 if speed > 3.5 else 0.85
        step = float(sum(damp ** min(m0 + i, 12) for i in range(1, steps + 1)))
        if self.bbox is not None:
            self.bbox = (self.bbox + self.vel_bbox * step).astype(np.float32)
        if self.obs_bbox is not None:
            self.obs_bbox = (self.obs_bbox + self.vel_bbox * step).astype(np.float32)
        if self.kps is not None and self.vel_kps is not None:
            self.kps = (self.kps + self.vel_kps * step).astype(np.float32)
        # Freeze when mostly outside the last known frame (set by core).
        if self._frame_wh is not None and self.bbox is not None:
            try:
                W, H = float(self._frame_wh[0]), float(self._frame_wh[1])
                x1, y1, x2, y2 = [float(v) for v in self.bbox]
                area = max(1.0, (x2 - x1) * (y2 - y1))
                ix = max(0.0, min(x2, W) - max(x1, 0.0))
                iy = max(0.0, min(y2, H) - max(y1, 0.0))
                contain = float(max(0.0, min(1.0, (ix * iy) / area)))
                if contain < 0.38:
                    self._paste_frozen = True
                    self.confirm_hits = 0  # v11.1.10: must re-confirm on return
            except Exception:
                pass
        return self.bbox

    def flow_correct(self, prev_bgr, curr_bgr) -> bool:
        """Move this face by what the pixels actually did since the last key frame.

        Constant-velocity coast lags a real acceleration: a quick nod or turn
        changes speed inside one detector gap, and the paste arrives late.
        Lucas-Kanade on the five landmarks is what live swap tools use for
        that gap. It is a few points, not a full-frame flow, so it stays cheap
        on CPU. A disagreed or low-confidence track returns False and the
        caller keeps the velocity coast.
        """
        if self._paste_frozen or self.kps is None or prev_bgr is None or curr_bgr is None:
            return False
        if prev_bgr.shape[:2] != curr_bgr.shape[:2]:
            return False
        pts = np.asarray(self.kps, np.float32).reshape(-1, 1, 2)
        if pts.shape[0] < 3:
            return False
        try:
            prev_g = cv2.cvtColor(prev_bgr, cv2.COLOR_BGR2GRAY)
            curr_g = cv2.cvtColor(curr_bgr, cv2.COLOR_BGR2GRAY)
            nxt, st, err = cv2.calcOpticalFlowPyrLK(
                prev_g, curr_g, pts, None,
                winSize=(21, 21), maxLevel=3,
                criteria=(cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 12, 0.03),
            )
        except Exception:
            return False
        if nxt is None or st is None or err is None:
            return False
        ok = (st.reshape(-1) == 1) & (err.reshape(-1) < 18.0)
        if int(np.count_nonzero(ok)) < 3:
            return False
        delta = (nxt.reshape(-1, 2) - pts.reshape(-1, 2))[ok]
        med = np.median(delta, axis=0).astype(np.float32)
        spread = float(np.median(np.linalg.norm(delta - med, axis=1)))
        if spread > 14.0 or float(np.hypot(med[0], med[1])) > 96.0:
            return False
        measured = nxt.reshape(-1, 2)
        original = pts.reshape(-1, 2)
        new_kps = original.copy()
        for i, good in enumerate(ok):
            new_kps[i] = measured[i] if good else original[i] + med
        self.kps = new_kps.astype(np.float32)
        slide = np.array([med[0], med[1], med[0], med[1]], np.float32)
        if self.bbox is not None:
            self.bbox = (np.asarray(self.bbox, np.float32) + slide).astype(np.float32)
        if self.obs_bbox is not None:
            self.obs_bbox = (np.asarray(self.obs_bbox, np.float32) + slide).astype(np.float32)
        dt = max(1.0, float(self.last_dt or 1.0))
        per = (med / dt).astype(np.float32)
        self.vel_kps = np.broadcast_to(per, self.kps.shape).copy()
        self.vel_bbox = np.array([per[0], per[1], per[0], per[1]], np.float32)
        return True

    def update(self, face, update_embedding=True, dt_frames: float = 1.0, kps_ok: bool = True):
        a = float(_P["trk_alpha"])
        dt = max(1.0, float(dt_frames or 1.0))
        self.last_dt = dt
        # Frames since this track last had a REAL detection. predict() adds to
        # `missed`; a hit resets it. `dt` covers the interval that has not been
        # counted yet.
        elapsed = max(1.0, float(self.missed) + dt)
        bb = np.asarray(face.bbox, np.float32).reshape(4).copy()

        # --- v11.1.9 ReentrySafe: reacquire snap ---------------------------
        # After a long miss / off-screen / round-trip, EMA-blending the new
        # detection toward the stale *predicted* bbox (and deriving velocity
        # from (new - last_hit)/elapsed across the gap) paints the first
        # returned frames in the wrong place. Snap hard instead.
        # Prevents off-screen carry → wrong-place paste on return.
        # --- v11.1.10 HairGate: keep _paste_frozen until confirm_hits >= 2
        # reliable frames so a hair/skull/neck first-hit cannot paint.
        reacquire = False
        if self.last_hit_bbox is not None:
            lh = np.asarray(self.last_hit_bbox, np.float32).reshape(4)
            lw = max(1.0, float(lh[2] - lh[0]))
            lhgt = max(1.0, float(lh[3] - lh[1]))
            cx0 = 0.5 * (float(lh[0]) + float(lh[2]))
            cy0 = 0.5 * (float(lh[1]) + float(lh[3]))
            cx1 = 0.5 * (float(bb[0]) + float(bb[2]))
            cy1 = 0.5 * (float(bb[1]) + float(bb[3]))
            # v11.2.2: judge displacement against where this track's OWN
            # tracked velocity says it should be after `elapsed` frames, not
            # against the raw last-hit position. The un-scaled version
            # (comparing raw consecutive-detection IOU/distance regardless of
            # how many frames separated them) fired on ordinary continuous
            # motion across a sparse detector cadence - a subject crossing a
            # whole box-width between two detector calls (normal at
            # Fast/Optimized SKIP_N with real movement) looked identical to a
            # genuine re-acquisition elsewhere, snapping velocity to zero and
            # re-freezing paste on exactly the "fast movement" footage this
            # project has been trying to fix. Verified directly: the
            # project's own regression suite (t_final.py) caught this -
            # constant 10px/frame motion at a 10-frame detector cadence was
            # being LEARNED AS ZERO velocity because every update reacquired.
            exp_cx, exp_cy = cx0, cy0
            if self.vel_bbox is not None:
                exp_cx += 0.5 * (float(self.vel_bbox[0]) + float(self.vel_bbox[2])) * elapsed
                exp_cy += 0.5 * (float(self.vel_bbox[1]) + float(self.vel_bbox[3])) * elapsed
            cdist = float(math.hypot(cx1 - exp_cx, cy1 - exp_cy))
            # v11.2.3: this OR clause's own flat "8" disagreed with
            # trk_max_missed (24, the budget _predicted_miss_budget() and
            # this same class' own .missed > trk_max_missed checks use for
            # "how long may a gap be trusted"). The position-based cdist
            # check above is the primary signal for "did the identity
            # actually move elsewhere"; missed alone should only force a
            # re-confirm once a gap is long enough that even good position
            # tracking stops being trustworthy - the same bar the rest of
            # this class already uses, not a stricter, unrelated one.
            # Measured directly: on sustained rapid oscillating motion, a
            # handful of motion-veto-rejected frames alone could push
            # missed past 8 while the track was still being correctly
            # predicted through the gap, forcing an unnecessary reacquire
            # (and its 2-hit HairGate confirm delay) at the exact moment a
            # good real detection arrived to end the gap.
            if (int(self.missed) >= int(_P.get("trk_max_missed", 24) or 24)
                    or cdist > 0.75 * max(lw, lhgt)):
                reacquire = True
        # v11.2.4 HoldThrough: overlapping boxes are a turn / talk / open
        # mouth, not an exit. HairGate's freeze-until-2-hits is what left
        # the original face on screen for seconds after a rapid head turn
        # even though the detector was already reporting the same head.
        # Only a true teleport (near-zero overlap with both last hit AND
        # the predicted box) may freeze paste.
        same_head = False
        if self.last_hit_bbox is not None:
            try:
                same_head = _bb_iou(self.last_hit_bbox, bb) >= 0.18
            except Exception:
                same_head = False
        if (not same_head) and self.bbox is not None:
            try:
                same_head = _bb_iou(self.bbox, bb) >= 0.18
            except Exception:
                pass
        if same_head:
            reacquire = False
            if self._paste_frozen:
                self._paste_frozen = False
                self.confirm_hits = 2
                self.alpha_ema = 1.0
        # v11.2.0 CinemaQA: sticky until core wipes geom timeline.
        # Previously `= reacquire` cleared the flag on the confirming update
        # *before* _record_geometry could scrub stubs → exit/return ghost glide.
        if reacquire:
            self._reacquired = True

        if reacquire:
            # v11.2.3 tried keeping the pre-gap vel_bbox here instead of
            # zeroing it, reasoning the subject likely kept moving through
            # the gap. Measured directly and found WORSE on sustained
            # oscillating motion: at a reversal point in the motion (the
            # exact moment a reacquire is likely, since that is where the
            # constant-velocity assumption breaks hardest) the pre-gap
            # velocity points the WRONG WAY, so projecting forward with it
            # overshoots in the opposite direction - worse than assuming
            # no velocity at all. Reverted to zero; the real fix for this
            # class of failure is a motion model that represents
            # acceleration/reversal, not a better guess at which stale
            # velocity to keep, which is out of scope here.
            self.vel_bbox = np.zeros(4, np.float32)
            self.ab_bbox = bb.copy()
            self.obs_bbox = bb.copy()
            self.last_hit_bbox = bb.copy()
            self.bbox = bb.copy()
            kps = getattr(face, "kps", None)
            if kps is not None:
                kp = np.asarray(kps, np.float32).copy()
                self.kps = kp
                self.ab_kps = kp.copy()
                # v11.2.3: None, not zeros. update()'s own velocity EMA
                # ("v if self.vel_kps is None else vel_kps*0.6 + v*0.4")
                # treats an existing vel_kps as a real prior to blend with -
                # a zeroed vector is not "no estimate yet", it is "was
                # stationary", and got treated as such: the FIRST genuine
                # velocity reading after a reacquire was damped 60% toward
                # that false zero, understating a subject who kept moving
                # right through the reacquire. That understated velocity is
                # exactly what core_pipeline.py's motion-consistency veto
                # uses for its expected-position budget, so a second real,
                # correct detection could still get vetoed on nothing more
                # than this residual damping - measured directly as the
                # repeated short-recovery/long-dropout cycle a sustained
                # fast, oscillating motion produced even after the veto's
                # own zero-velocity skip (immediately below/elsewhere) was
                # added. None restores the same fresh-start treatment a
                # genuine first-time establishment already gets.
                self.vel_kps = None
                self.kps_scale = None
                self.last_hit_kps = kp.copy()
            lmk = getattr(face, "landmark_2d_106", None)
            if lmk is not None:
                self.lmk = np.asarray(lmk, np.float32).copy()
            if update_embedding:
                self._commit_identity(getattr(face, "normed_embedding", None))
            self.det_score = _fnum_local(getattr(face, "det_score", 0.5), 0.5)
            self.last_face = face
            self.hits += 1
            self.missed = 0
            # v11.2.4: a CLEAN first return (kps_ok) paints immediately.
            # Waiting for a second consecutive reliable hit is what made
            # the original face linger for seconds after the subject was
            # already back. Unreliable first hit still waits one more.
            if kps_ok:
                self.confirm_hits = 2
                self._paste_frozen = False
                self.alpha_ema = 1.0
            else:
                self.confirm_hits = 0
                self._paste_frozen = True
            self._confirm_ease = 0
            return

        # --- alpha-beta motion filter (v11.2.6) ---------------------------
        # PRE-v11.2.6 NOTE, kept because it is the trap this code has to keep
        # avoiding: velocity must never be measured against obs_bbox. predict()
        # advances obs_bbox, so (bb - obs_bbox) is the prediction RESIDUAL, and
        # feeding a residual back AS velocity means an accurate prediction
        # halves the velocity - a few accurate predictions in a row drive it to
        # zero, the carried face stops moving mid-gap, then jumps when the
        # detector next reports.
        #
        # An alpha-beta filter uses that same residual, but as a CORRECTION
        # added to the velocity rather than as the velocity itself:
        #
        #     x_pred = x + v*dt         (where the filter thought it would be)
        #     r      = z - x_pred       (how wrong that was)
        #     x      = x_pred + a*r     (position: believe the measurement)
        #     v      = v + (b/dt)*r     (velocity: accelerate toward the truth)
        #
        # r = 0 therefore leaves v untouched, which is the correct response to
        # motion the filter is already predicting - the exact opposite of the
        # degenerate case above. What it buys over the old flat EMA of measured
        # deltas is acceleration: the residual is large and signed while the
        # subject is speeding up, slowing down or reversing, so v is corrected
        # in the right direction on the FIRST detection after the change
        # instead of being averaged toward it over several. That interval is
        # what a zoomed shot magnifies (the same head turn covers far more
        # pixels), and it is where the held face was ending up hundreds of
        # pixels from the real one.
        #
        # Dividing by `elapsed` (not by 1) keeps the unit at pixels per OUTPUT
        # frame whatever the detector cadence is, and makes the velocity gain
        # correct for the gap actually being corrected over: the same residual
        # accumulated across ten frames implies a tenth of the per-frame
        # velocity error it would imply across one.
        _ab_a = float(_P.get("ab_alpha", 0.85) or 0.85)
        _ab_b = _ab_beta()
        if self.last_hit_bbox is None or self.ab_bbox is None:
            self.vel_bbox = np.zeros(4, np.float32)
            self.ab_bbox = bb.copy()
        else:
            x_pred = self.ab_bbox + self.vel_bbox * elapsed
            r = bb - x_pred
            self.vel_bbox = (self.vel_bbox + (_ab_b / elapsed) * r).astype(np.float32)
            self.ab_bbox = (x_pred + _ab_a * r).astype(np.float32)
        self.obs_bbox = bb.copy()
        # v11.2.176 (SDOS-176): the faster the face moves, the less it is smoothed. v11.2.92 blended every detection into the
        # last position (box 0.42; the 5 points' One Euro filter barely opened with speed), so on a fast step - 60 px a frame -
        # the paint trailed the face by up to 50 px, a ghost beside it. From 4 % of the face width a frame the smoothing fades,
        # gone at 10 %; a still or slow face keeps all of it. Not while two faces touch (their points are steadied there).
        _fast_w = 0.0
        if (bool(_P.get("fast_snap", 1)) and self.bbox is not None and not bool(getattr(self, "crossing", False))
                and self.last_hit_bbox is not None):
            try:
                _fw = max(8.0, float(bb[2] - bb[0]))
                _dc = (np.array([bb[0] + bb[2], bb[1] + bb[3]], np.float32) - np.array(
                    [self.bbox[0] + self.bbox[2], self.bbox[1] + self.bbox[3]], np.float32)) * 0.5
                _sp = float(np.hypot(_dc[0], _dc[1])) / max(1.0, float(elapsed)) / _fw
                _fast_w = float(np.clip((_sp - 0.04) / 0.06, 0.0, 1.0))
            except Exception:
                _fast_w = 0.0
        self.last_hit_bbox = bb.copy()
        if self.bbox is None:
            self.bbox = bb
        else:
            _a = a + (1.0 - a) * _fast_w
            self.bbox = (self.bbox * (1.0 - _a) + bb * _a).astype(np.float32)

        kps = getattr(face, "kps", None)
        if kps is not None:
            kp = np.asarray(kps, np.float32).copy()
            if self.kps is not None and self.kps.shape == kp.shape:
                # One Euro filter, t_e = 1 frame. A raw per-frame speed
                # estimate (this frame's delta) drives the cutoff, not the
                # already-smoothed vel_kps - the filter needs to react to
                # how fast things are moving RIGHT NOW, not a lagged
                # estimate of that, or it would itself lag exactly when
                # responsiveness matters most.
                raw_speed = float(np.mean(np.abs(kp - self.kps))) / elapsed
                cutoff = float(_P["kps_min_cutoff"]) + float(_P["kps_beta"]) * raw_speed
                # t_e = elapsed frames, not a hard-coded 1. With a detector
                # cadence above 1 the old form under-smoothed by that factor.
                r = 2.0 * math.pi * cutoff * elapsed
                a = r / (r + 1.0)
                a = a + (1.0 - a) * _fast_w          # v11.2.176: fast motion, no lag (see the box above)
                sm = self.kps * (1.0 - a) + kp * a
                # Same alpha-beta filter as vel_bbox, on its own state. Note
                # this is a SECOND, independent filter and not a duplicate of
                # the One Euro smoothing just above: One Euro produces the
                # DISPLAY keypoints (self.kps, jitter-free but deliberately
                # lagged), while this produces the MOTION MODEL (vel_kps, what
                # predict() extrapolates with and what core_pipeline's
                # motion-consistency veto sizes its budget from). Smoothing the
                # motion model with the display filter would make the veto
                # reject exactly the fast, correct detections it exists to let
                # through.
                if (self.last_hit_kps is not None
                        and self.last_hit_kps.shape == kp.shape
                        and self.ab_kps is not None
                        and self.ab_kps.shape == kp.shape
                        and self.vel_kps is not None
                        and self.vel_kps.shape == kp.shape):
                    kx_pred = self.ab_kps + self.vel_kps * elapsed
                    kr = kp - kx_pred
                    self.vel_kps = (self.vel_kps + (_ab_b / elapsed) * kr).astype(np.float32)
                    self.ab_kps = (kx_pred + _ab_a * kr).astype(np.float32)
                else:
                    # No usable prior: seed from the raw measured delta rather
                    # than from zero, so a subject who is already moving does
                    # not spend a detection interval being modelled as still.
                    if self.last_hit_kps is not None and self.last_hit_kps.shape == kp.shape:
                        self.vel_kps = ((kp - self.last_hit_kps) / elapsed).astype(np.float32)
                    else:
                        self.vel_kps = np.zeros_like(kp)
                    self.ab_kps = kp.copy()
                # --- damp SIZE separately from position -------------------
                # One Euro deliberately relaxes its smoothing as speed rises,
                # so a fast-moving face is not lagged. That is right for WHERE
                # the landmarks are and wrong for HOW BIG they are: a head's
                # apparent size does not change because it moved sideways, so
                # scale was being speed-relaxed for no reason and the
                # detector's own box error passed straight into the size of
                # the pasted face. Measured with a jittering detector box
                # (t_jitter): the paste never drops out - no flicker in the
                # presence sense - but its area swings up to 31% frame to
                # frame, which is the reported "little flicker on movement".
                #
                # The constellation is rescaled about its own centroid toward
                # a slow EMA of its size. Position and rotation are untouched,
                # so nothing here adds lag to a moving face; only the
                # breathing is removed. The EMA runs per DETECTION, not per
                # frame, so its time constant does not shift with cadence.
                _c = sm.mean(axis=0)
                _sc = float(np.mean(np.linalg.norm(sm - _c, axis=1)))
                if _sc > 1e-3:
                    if self.kps_scale is None:
                        self.kps_scale = _sc
                    else:
                        self.kps_scale = float(self.kps_scale * (1.0 - _KPS_SCALE_EMA)
                                               + _sc * _KPS_SCALE_EMA)
                    sm = _c + (sm - _c) * (self.kps_scale / _sc)
                self.kps = sm.astype(np.float32)
            else:
                self.kps = kp
                self.vel_kps = np.zeros_like(kp)
                self.ab_kps = kp.copy()
            self.last_hit_kps = kp.copy()

        lmk = getattr(face, "landmark_2d_106", None)
        if lmk is not None:
            self.lmk = np.asarray(lmk, np.float32).copy()

        if update_embedding:
            self._commit_identity(getattr(face, "normed_embedding", None))

        self.det_score = _fnum_local(getattr(face, "det_score", 0.5), 0.5)
        self.last_face = face
        self.hits += 1
        self.missed = 0
        # v11.1.10 HairGate: while paste-frozen (exit or reacquire), require
        # confirm_hits >= 2 reliable updates before allowing paste again.
        if self._paste_frozen:
            if kps_ok:
                self.confirm_hits = int(getattr(self, "confirm_hits", 0) or 0) + 1
                if self.confirm_hits >= 2:
                    self._paste_frozen = False
                    # v11.2.1 SolidFace: binary paste at full strength — no soft
                    # ease / no alpha_ema reseed to 0.70 (that made original bleed).
                    self._confirm_ease = 0
                    self.alpha_ema = 1.0
            else:
                self.confirm_hits = 0
                # keep _paste_frozen True
        else:
            if kps_ok:
                self.confirm_hits = max(int(getattr(self, "confirm_hits", 0) or 0), 2)

    def predicted_face(self):
        """A stand-in face object usable by inswapper on a skipped frame."""
        if self.bbox is None or self.kps is None:
            return None
        return PredictedFace(self.bbox, self.kps, self.lmk,
                             getattr(self.last_face, "normed_embedding", None),
                             self.det_score)

    # -- appearance -----------------------------------------------------
    def smooth_hull(self, hull: np.ndarray | None):
        """EMA the landmark hull on its own, slower clock.

        The hull is the only POSE-DEPENDENT term in an otherwise
        pose-normalised mask, so it is the term that makes the silhouette
        breathe when the head yaws. Smoothing the composed mask (as before)
        could not separate this from legitimate scale changes; smoothing the
        hull itself can.
        """
        if hull is None:
            return self.hull_ema
        a = float(_P.get("hull_ema", 0.22) or 0.22)
        if a <= 0 or self.hull_ema is None or self.hull_ema.shape != hull.shape:
            self.hull_ema = hull.astype(np.float32).copy()
        else:
            self.hull_ema = (self.hull_ema * (1.0 - a) + hull * a).astype(np.float32)
        return self.hull_ema

    def ramp_occlusion(self, target: float) -> float:
        """Move the occlusion weight toward ``target`` at a bounded rate.

        A hard on/off guard moved the mask area by several percent between
        consecutive frames, and the mask is exactly what the colour statistics
        are weighted by - so one toggle shifted the silhouette AND the
        brightness at the same time. Ramping removes both steps.
        """
        r = float(_P.get("occl_ramp", 0.25) or 0.25)
        t = float(np.clip(target, 0.0, 1.0))
        self.occl_w = float(self.occl_w + (t - self.occl_w) * np.clip(r, 0.01, 1.0))
        return self.occl_w

    def smooth_alpha(self, target: float) -> float:
        """Composite opacity EMA — snap-up to full strength, slow fade-out only.

        v11.2.1 SolidFace: when gates say YES the swap must sit at ~1.0, not
        linger half-transparent via a slow 0.72/0.28 climb. Prefer snap-up
        toward 1.0; use the slower EMA only when intentionally fading out.
        """
        t = float(np.clip(target, 0.0, 1.0))
        # Defensive: this used to assume alpha_ema could never be None, which
        # was true until a reset path set it to None and took a whole job down
        # with a TypeError. A smoothing state is never worth crashing a render
        # over - fall back to the construction default and carry on.
        cur = self.alpha_ema
        if cur is None:
            cur = 1.0
            log.debug("alpha_ema was None; recovered to 1.0")
        try:
            cur = float(cur)
        except Exception:
            cur = 1.0
        if t >= 0.94:
            # Snap-up / fast catch-up — never cap below full during stable track.
            self.alpha_ema = max(cur, float(cur * 0.45 + t * 0.55), t)
        elif t < cur:
            # Intentional fade-out (exit / miss budget) — keep slower EMA.
            self.alpha_ema = float(cur * 0.72 + t * 0.28)
        else:
            self.alpha_ema = float(cur * 0.45 + t * 0.55)
        return self.alpha_ema

    def reset_for_cut(self):
        """Forget WHERE this person was and what they looked like - not WHO.

        At a hard cut nothing about the previous shot is evidence about this
        one: the position, the velocity, the cached aligned crop, the colour
        and mask EMAs and the measured grain all describe a frame that no
        longer exists. Carrying them is what pastes the last shot's face onto
        the first frames of the next one, and what makes the geometry glide
        from the old position to the new one over the next half second.

        identity is deliberately KEPT - id_lock, emb, slot_gender. The person
        we were told to swap is still the person we were told to swap; we have
        only lost track of where they are. Clearing identity here would hand a
        virgin slot to whoever the detector happens to see first in the new
        shot, which is the "wrong person bound to the slot" defect this engine
        has been fixed for twice.
        """
        self.bbox = None
        self.obs_bbox = None
        self.kps = None
        self.lmk = None
        self.ab_bbox = None
        self.ab_kps = None
        self.last_hit_bbox = None
        self.last_hit_kps = None
        self.occn_keep = None
        self.occ_prev_g = None          # v11.2.206
        self.occ_face_ref = None
        self.occn_core = None
        self.prof_w = None
        self.eat_w = 0.0
        self.vel_bbox = np.zeros(4, np.float32)
        self.vel_kps = None
        self.kps_scale = None
        # Appearance state measured on the old shot's light.
        self.mask_ema = None
        self.hull_ema = None
        self.occ_keep = None
        self.cm_dmean = None
        self.cm_ratio = None
        self.grain_ema = None
        self.mblur_ema = None
        # 1.0, NOT None. __init__ sets this to 1.0 and every other assignment
        # in this class is a float; smooth_alpha does `float(self.alpha_ema)`
        # with no guard because the field was never None in the first place.
        # Nulling it here broke that invariant and crashed the job on the
        # first frame after a shot cut:
        #   TypeError: float() argument must be ... not 'NoneType'
        # The opacity EMA is not stale evidence about the old shot - it is a
        # smoothing state whose correct post-cut value is "fully opaque",
        # exactly as at construction.
        self.alpha_ema = 1.0
        # The cached aligned crop IS the old shot's face. This is the one that
        # produces the reported "the pasted face holds" on a scene change.
        self.fake = None
        self.fake_corr = None
        self.fake_size = 0
        self.fake_frame = -10**9
        # Treat the person as not currently seen, so the next real detection is
        # a re-acquisition rather than a continuation, but do not kill the
        # track outright - its identity is still valid.
        self.missed = max(int(self.missed), 1)
        self.hits = 0
        self.confirm_hits = 0
        self._confirm_ease = 0
        self._paste_frozen = False
        self._reacquired = True
        self.crossing = False
        self.flip_votes = 0
        self.pose_ok = False
        self.last_face = None
        self.det_score = 0.0

    def cache_fake(self, fake, corr, frame_ord):
        self.fake = fake
        self.fake_corr = corr
        self.fake_size = int(fake.shape[0]) if fake is not None else 0
        self.fake_frame = int(frame_ord)

    def smooth_mask(self, mask: np.ndarray) -> np.ndarray:
        a = float(_P["mask_ema"])
        if a <= 0 or self.mask_ema is None or self.mask_ema.shape != mask.shape:
            self.mask_ema = mask.astype(np.float32).copy()
        else:
            self.mask_ema = (self.mask_ema * (1.0 - a) + mask * a).astype(np.float32)
        return self.mask_ema

    def smooth_colour(self, dmean, ratio):
        """EMA colour correction with per-frame delta clamp (SoftStable).

        Clamp each channel's dmean to ±cm_delta_clamp from the previous
        *smoothed* value before EMA so lighting/pose jumps cannot pop
        brightness. SoftStable only — no hold-everywhere paste logic.
        """
        a = float(_P["cm_ema"])
        dmean = np.asarray(dmean, np.float32).reshape(-1).copy()
        ratio = np.asarray(ratio, np.float32).reshape(-1).copy()
        # NOTE: the previous version also re-seeded outright whenever
        # missed > 8. Dropping a converged correction and replacing it with a
        # single frame's raw measurement is a step change in face brightness,
        # and it fired precisely on the frames a long occlusion ended - which
        # is when a brightness pop is most visible. Only seed when there is
        # genuinely nothing to carry.
        if self.cm_dmean is None:
            self.cm_dmean = dmean.astype(np.float32).copy()
            self.cm_ratio = ratio.astype(np.float32).copy()
        else:
            max_step = float(_P.get("cm_delta_clamp", 5.0) or 5.0)
            prev = self.cm_dmean
            clamped = np.clip(dmean, prev - max_step, prev + max_step)
            self.cm_dmean = (prev * (1.0 - a) + clamped * a).astype(np.float32)
            self.cm_ratio = (self.cm_ratio * (1.0 - a) + ratio * a).astype(np.float32)
        return self.cm_dmean, self.cm_ratio

    def reset_appearance(self, hard: bool = False):
        """Let the appearance memory re-converge; do not delete it.

        This is called whenever the tracker merely SUSPECTS a relabel, which
        on a geometric test happens routinely during a crossing. Clearing the
        colour EMA outright produced a measured ~4x frame-to-frame luma step
        on the very next frame - a visible brightness pop in exactly the hug /
        kiss shots it was meant to protect. Halving the correction lets it
        re-converge over a few frames instead, which is invisible. ``hard``
        remains available for a genuine identity change.
        """
        self.mask_ema = None
        self.hull_ema = None
        self.fake = None
        self.fake_corr = None
        self.fake_size = 0
        if hard:
            self.cm_dmean = None
            self.cm_ratio = None
        else:
            if self.cm_dmean is not None:
                self.cm_dmean = (self.cm_dmean * 0.5).astype(np.float32)
            if self.cm_ratio is not None:
                self.cm_ratio = (1.0 + (self.cm_ratio - 1.0) * 0.5).astype(np.float32)


class PredictedFace:
    """Minimal duck-typed stand-in matching insightface's Face attributes."""

    # NOTE: `_slot` belongs here. Without it, a caller tagging a carried face
    # with its identity slot raised AttributeError - silently, because those
    # call sites are inside try/except - so a carried face reached the renderer
    # with no slot and was dropped. The effect was that key frames where the
    # detector was deliberately skipped contributed no geometry at all.
    # v11.2.2: `_frame_shape` added for the same reason `_slot` was above -
    # core_pipeline.py's ReentrySafe containment check tags carried faces
    # with it (`pf._frame_shape = ...`), and the assignment was silently
    # swallowed by the same try/except pattern, falling back to (correct,
    # but only by luck of a second code path existing) TrackState._frame_wh.
    __slots__ = ("bbox", "kps", "landmark_2d_106", "normed_embedding",
                 "embedding", "det_score", "predicted", "_track", "_slot",
                 "_occlusion_guard", "_frame_shape")

    def __init__(self, bbox, kps, lmk=None, emb=None, det_score=0.5):
        self.bbox = np.asarray(bbox, np.float32).reshape(4).copy()
        self.kps = np.asarray(kps, np.float32).copy()
        self.landmark_2d_106 = None if lmk is None else np.asarray(lmk, np.float32).copy()
        self.normed_embedding = emb
        self.embedding = emb
        self.det_score = float(det_score)
        self.predicted = True
        self._track = None
        self._slot = None
        self._occlusion_guard = 0.0   # continuous weight, not a flag


# --------------------------------------------------------------------------
# The compositor
# --------------------------------------------------------------------------
# --------------------------------------------------------------------------
# Plate matching: grain and motion blur  (SDOS-071 F2 / F3)
# --------------------------------------------------------------------------
# Both passes answer the same question - "what does the ORIGINAL footage look
# like at high spatial frequencies, right here, right now?" - and make the
# swap agree with the answer. Both must run per OUTPUT FRAME, never on the
# cached crop: grain baked into a crop that is reused for twenty frames stops
# being grain and becomes dirt on the lens, and blur baked in would persist
# after the head stopped moving.

_IMMERKAER = np.array([[1.0, -2.0, 1.0],
                       [-2.0, 4.0, -2.0],
                       [1.0, -2.0, 1.0]], np.float32)


# SDOS-075 attribution: how often the occluder gate actually cut anything.
# Without this, "is the new occluder gate causing the reverts?" can only be
# answered by guessing.
OCC_STATS = {"frames": 0, "cut_frames": 0, "cut_area_sum": 0.0}

# --------------------------------------------------------------------------
# Occlusion net (SDOS-091): a trained face-occlusion segmenter decides what is
# in front of the mouth and chin.
#
# The colour/novelty gate above could not tell food from lips on real faces
# (SDOS-083..087: 8-76 % of a scoop found depending on its colour, and on real
# footage it cut 82-91 % of all face-frames). This is FaceFusion's "face
# occluder" (XSeg, DeepFaceLab lineage, 256x256 BGR in, 1 = face / 0 =
# occluded out), trained on real occlusions. Measured on 12 real faces: every
# pixel of a realistic scoop at the mouth, the lips or a cheek is found, for
# all six colours tested, and nothing is cut on a clean face (normal, dim,
# dark+noise, side light, blur). Two rules keep the rest of the swap exactly
# as it was:
#   * only INSIDE the face's own landmark outline (eroded), so the edge of the
#     swap (hairline, jaw, ears) is not re-shaped;
#   * only pieces that reach the mouth/chin zone, so hair falling over a cheek
#     (which the model rightly calls an occluder) does not cut the face.
# --------------------------------------------------------------------------
OCCNET_STATS = {"frames": 0, "cut_frames": 0, "cut_area_sum": 0.0, "ms": 0.0}
_OCCNET = {"sess": None, "name": None, "error": None}


def occ_net_load(path, threads=2):
    """Load the occlusion model; never raises. Returns True when ready."""
    try:
        import onnxruntime as ort
        so = ort.SessionOptions()
        so.intra_op_num_threads = max(1, int(threads))
        so.inter_op_num_threads = 1
        so.execution_mode = ort.ExecutionMode.ORT_SEQUENTIAL
        so.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
        so.add_session_config_entry("session.intra_op.allow_spinning", "0")
        sess = ort.InferenceSession(str(path), sess_options=so, providers=["CPUExecutionProvider"])
        shp = sess.get_inputs()[0].shape
        if len(shp) != 4 or int(shp[1]) != 256 or int(shp[3]) != 3:
            raise RuntimeError("unexpected input shape %s" % (shp,))
        _OCCNET["sess"] = sess
        _OCCNET["name"] = os.path.basename(str(path))
        _OCCNET["error"] = None
        return True
    except Exception as e:
        _OCCNET["sess"] = None
        _OCCNET["error"] = "%s: %s" % (type(e).__name__, e)
        return False


_OCCNET_RAW = {"key": None, "m": None}
PROFILE_STATS = {"frames": 0, "w_sum": 0.0}


def occ_net_raw(aligned_bgr):
    """The occlusion net's own face map (256x256, 1 = face) for an aligned crop; None without the net.
    The last result is kept, so the profile mask and the mouth/chin rule share one forward pass per crop."""
    sess = _OCCNET.get("sess")
    if sess is None or aligned_bgr is None:
        return None
    key = (aligned_bgr.shape, aligned_bgr.__array_interface__["data"][0], int(aligned_bgr[::7, ::5].sum()))
    if _OCCNET_RAW["key"] == key:
        return _OCCNET_RAW["m"]
    W = 256
    x = cv2.resize(aligned_bgr, (W, W), interpolation=cv2.INTER_LINEAR).astype(np.float32)[None] / 255.0
    m = sess.run(None, {sess.get_inputs()[0].name: x})[0][0, :, :, 0]
    m = np.clip(m, 0.0, 1.0).astype(np.float32)
    _OCCNET_RAW["key"], _OCCNET_RAW["m"] = key, m
    return m


def _yaw_offset(kps):
    """The nose's sideways offset from the eye midpoint, roll-corrected, in eye distances (as profile_weight): frontal
    0.0-0.25, 36-45 deg 0.34-0.51, 55-71 deg 0.76-1.48. None without points."""
    try:
        k = np.asarray(kps, np.float32).reshape(-1, 2)
        le, re, nose = k[0], k[1], k[2]
        ev = re - le
        ed = float(np.linalg.norm(ev)) + 1e-6
        roll = float(np.arctan2(ev[1], ev[0]))
        c, s = math.cos(-roll), math.sin(-roll)
        rel = nose - (le + re) * 0.5
        return abs(float(rel[0] * c - rel[1] * s)) / ed
    except Exception:
        return None


def profile_weight(kps):
    """0 for any pose up to about 45 deg of yaw, rising to 1 at about 55-60 deg (calibrated on AFLW2000's true yaw).

    The nose's sideways offset from the eye midpoint, roll-corrected, in eye distances. Frontal 0.0-0.25,
    36-45 deg 0.34-0.51, 55-71 deg 0.76-1.48. Raised cosine between profile_lo and profile_hi."""
    if kps is None or float(_P.get("profile_mask", 0.0) or 0.0) <= 0.0:
        return 0.0
    try:
        k = np.asarray(kps, np.float32).reshape(-1, 2)
        if k.shape[0] < 3:
            return 0.0
        le, re, nose = k[0], k[1], k[2]
        ev = re - le
        ed = float(np.linalg.norm(ev)) + 1e-6
        roll = float(np.arctan2(ev[1], ev[0]))
        c, s = math.cos(-roll), math.sin(-roll)
        rel = nose - (le + re) * 0.5
        h = abs(float(rel[0] * c - rel[1] * s)) / ed
        lo, hi = float(_P.get("profile_lo", 0.45)), float(_P.get("profile_hi", 0.70))
        if h <= lo:
            return 0.0
        if h >= hi:
            return 1.0
        return float(0.5 - 0.5 * math.cos(math.pi * (h - lo) / (hi - lo)))
    except Exception:
        return 0.0


def profile_mask(aligned_bgr, pts_aligned, size):
    """Paint weight for an extreme side view: the visible face's own outline, None when it cannot be built.

    Face map of the occlusion net (it segments the face on profiles, not just frontal faces) times the landmark
    outline dilated a little (so a neck, a hand or another face next to it is never taken for this face), with a
    short feather and the template's crop-border roll-off. Without the net: the landmark outline alone."""
    try:
        hull = None
        if pts_aligned is not None:
            hm = np.zeros((size, size), np.uint8)
            cv2.fillConvexPoly(hm, cv2.convexHull(np.round(np.asarray(pts_aligned, np.float32)).astype(np.int32)), 255)
            d = int(max(1, round(size * 0.04)))
            hm = cv2.dilate(hm, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * d + 1, 2 * d + 1)))
            hull = hm.astype(np.float32) / 255.0
        m = occ_net_raw(aligned_bgr)
        if m is not None:
            seg = cv2.resize(m, (size, size), interpolation=cv2.INTER_LINEAR)
            seg = np.clip((seg - 0.35) / 0.30, 0.0, 1.0)
            pm = seg if hull is None else seg * hull
        elif hull is not None:
            pm = hull
        else:
            return None
        k = int(max(3, round(size * float(_P.get("profile_feather", 0.025)) * 2))) | 1
        pm = cv2.GaussianBlur(pm.astype(np.float32), (k, k), 0)
        b = float(_P.get("mask_border", 0.08) or 0.0)
        if b > 0.0:
            g = (np.arange(size, dtype=np.float32) + 0.5) / size
            e = np.minimum(g, 1.0 - g)
            pm *= np.clip(np.minimum(e[:, None], e[None, :]) / b, 0.0, 1.0)
        return np.clip(pm, 0.0, 1.0).astype(np.float32)
    except Exception as e:
        log.debug("profile mask skipped: %s", e)
        return None


EAT_STATS = {"frames": 0, "w_sum": 0.0}
_LIPS = list(range(52, 72))      # insightface 2d106det: outer and inner lip contour


def _eating_mouth(mask, keep, pts_aligned, size, track=None):
    """Show the footage's own lips while an object is at the mouth (see eat_mouth). Returns the new mask."""
    try:
        pts = np.asarray(pts_aligned, np.float32).reshape(-1, 2)
        if pts.shape[0] < 72:
            return mask
        lips = pts[_LIPS]
        lm = np.zeros((size, size), np.uint8)
        cv2.fillConvexPoly(lm, cv2.convexHull(np.round(lips).astype(np.int32)), 1)
        pad = int(max(1, round(size * float(_P.get("eat_lip_pad", 0.035)))))
        lips_pad = cv2.dilate(lm, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * pad + 1, 2 * pad + 1)))
        mw = float(lips[:, 0].max() - lips[:, 0].min())
        zr = int(max(3, round(mw * 0.6)))
        zone = cv2.dilate(lm, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * zr + 1, 2 * zr + 1)))
        cut = (keep < 0.5) & (zone > 0) & (lips_pad == 0)
        frac = float(cut.sum()) / float(size * size)
        lo, hi = float(_P.get("eat_lo", 0.002)), float(_P.get("eat_hi", 0.008))
        e = 0.0 if frac <= lo else 1.0 if frac >= hi else 0.5 - 0.5 * math.cos(math.pi * (frac - lo) / (hi - lo))
        if track is not None:
            prev = float(getattr(track, "eat_w", 0.0) or 0.0)
            a = float(_P.get("eat_attack", 0.6)) if e > prev else float(_P.get("eat_release", 0.12))
            e = prev + (e - prev) * a
            track.eat_w = e
        if e < 0.01:
            e = 0.0
        if e <= 0.0:
            return mask
        k = int(max(3, round(size * 0.05))) | 1
        region = cv2.GaussianBlur(lips_pad.astype(np.float32), (k, k), 0)
        EAT_STATS["frames"] += 1
        EAT_STATS["w_sum"] += e
        return (mask * (1.0 - e * np.clip(region, 0.0, 1.0))).astype(np.float32)
    except Exception as ex:
        log.debug("eating mouth skipped: %s", ex)
        return mask


_OCC_TL = threading.local()
_OCC_GRID = {}


def _occ_flow(track, aligned_bgr):
    """v11.2.206: where each pixel of this face crop was in the previous one (DIS optical flow at 128 px, footage only).
    None on the first frame of a track, after a size change, or if OpenCV has no DIS."""
    try:
        g = cv2.cvtColor(cv2.resize(aligned_bgr, (128, 128), interpolation=cv2.INTER_AREA), cv2.COLOR_BGR2GRAY)
    except Exception:
        return None
    prev = getattr(track, "occ_prev_g", None)
    track.occ_prev_g = g
    if prev is None or getattr(prev, "shape", None) != g.shape:
        return None
    if float(np.mean(cv2.absdiff(g, prev))) > 40.0:
        return None                      # a different picture (a shot cut): nothing to carry over
    try:
        dis = getattr(_OCC_TL, "dis", None)
        if dis is None:
            dis = cv2.DISOpticalFlow_create(cv2.DISOPTICAL_FLOW_PRESET_ULTRAFAST)
            _OCC_TL.dis = dis
        return dis.calc(g, prev, None)
    except Exception:
        return None


def _occ_warp(keep_prev, flow, size):
    """Move last frame's cut (keep < 1) along the flow into this frame's crop. Areas outside stay uncut."""
    if flow is None or keep_prev is None:
        return keep_prev
    try:
        grid = _OCC_GRID.get(size)
        if grid is None:
            gx, gy = np.meshgrid(np.arange(size, dtype=np.float32), np.arange(size, dtype=np.float32))
            grid = _OCC_GRID[size] = (gx, gy)
        f = cv2.resize(flow, (size, size), interpolation=cv2.INTER_LINEAR) * (size / 128.0)
        cut = cv2.remap(1.0 - keep_prev, grid[0] + f[..., 0], grid[1] + f[..., 1], cv2.INTER_LINEAR,
                        borderMode=cv2.BORDER_CONSTANT, borderValue=0)
        return np.clip(1.0 - cut, 0.0, 1.0).astype(np.float32)
    except Exception:
        return keep_prev


def _occ_snap(K, aligned_bgr, size):
    """v11.2.206: fit the edge of the cut (0 < K < 1) to the picture's own edges; the inside and the rest are not touched."""
    try:
        band = (K > 0.02) & (K < 0.98)
        if not bool(band.any()):
            return K
        r = max(2, int(round(size / 64.0)))
        band = cv2.dilate(band.astype(np.uint8), np.ones((2 * r + 1, 2 * r + 1), np.uint8)).astype(bool)
        gray = cv2.cvtColor(aligned_bgr, cv2.COLOR_BGR2GRAY)
        eps = (float(_P.get("occ_snap_eps", 0.03)) * 255.0) ** 2
        try:
            g = cv2.ximgproc.guidedFilter(gray, K.astype(np.float32), r, eps)
        except Exception:
            return K
        out = K.copy()
        out[band] = np.clip(g[band], 0.0, 1.0)
        return out.astype(np.float32)
    except Exception:
        return K


def _occ_net_wide(keep, m, occ, hull, hull0, pts, outside, prev_cut, region, need, W):
    """v11.2.206 (SDOS-206): the occlusion model's cut away from the mouth. A big piece over the inner face (a hand over an eye
    or a cheek, a cup, a phone) is cut, and followed out to the face's edge where the model saw face on the last frames. The
    lips (with a margin) are left out and stay under 11.2.205's mouth rule: a smile's teeth are not an object. Hair falling
    along the face's edge is a thin piece at the outline and is not cut; the background, hair and the swap's own soft border
    around the face are never joined in. In place on keep (256 px)."""
    ei = int(round(float(_P.get("occ_net_wide_erode", 0.10)) * W)) | 1
    inner = cv2.erode(hull.astype(np.uint8), cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (ei, ei))).astype(bool)
    wmin = float(_P.get("occ_net_wide_min", 0.010)) * W * W
    winner = float(_P.get("occ_net_wide_inner", 0.25))
    lipz = np.zeros((W, W), np.uint8)
    try:
        lp = np.asarray(pts, np.float32)[_LIPS]
        cv2.fillConvexPoly(lipz, cv2.convexHull(np.round(lp).astype(np.int32)), 1)
        lm = int(round(float(_P.get("occ_net_wide_lips", 0.04)) * W)) | 1
        lipz = cv2.dilate(lipz, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (lm, lm)))
    except Exception:
        pass
    lipz = lipz.astype(bool)
    ez = int(round(float(_P.get("occ_net_wide_zone_erode", 0.03)) * W)) | 1
    zone = cv2.erode(hull0.astype(np.uint8), cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (ez, ez))).astype(bool) | hull
    cand = (m < 0.5) & zone & ~lipz & (keep >= 0.999)    # nearer the face's edge than the mouth rule's zone
    if not bool(cand.any()):
        return
    if region is not None and getattr(region, "shape", None) == (W, W):
        face = region | hull
    else:
        ed = int(round(float(_P.get("occ_net_wide_edge", 0.04)) * W)) | 1
        face = cv2.dilate(hull0.astype(np.uint8), cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (ed, ed))).astype(bool)
    face &= ~lipz
    if outside is not None:
        face &= ~outside
    full_lab = None
    hold = float(_P.get("occ_net_wide_hold", 0.30))
    n, lab = cv2.connectedComponents(cand.astype(np.uint8), connectivity=8)
    for c in range(1, n):
        comp = lab == c
        if outside is not None and bool((comp & outside).any()):
            continue
        area = float(comp.sum())
        if area >= wmin and float((comp & inner).sum()) >= winner * area:
            OCCNET_STATS["wide"] = OCCNET_STATS.get("wide", 0) + 1
        elif (prev_cut is not None and area >= need and float((comp & prev_cut).sum()) >= hold * area
              and (region is None or float((comp & (region | inner)).sum()) >= 0.5 * area)):
            # the object cut on the last frame (moved with the footage) stays cut while it leaves, even when what is left
            # of it over the face is small
            OCCNET_STATS["held"] = OCCNET_STATS.get("held", 0) + 1
        else:
            continue
        keep[comp] = np.minimum(keep[comp], m[comp])
        if full_lab is None:
            full_lab = cv2.connectedComponents(((m < 0.5) & face).astype(np.uint8), connectivity=8)[1]
        for fl in np.unique(full_lab[comp]):
            if fl:
                ext = full_lab == fl
                keep[ext] = np.minimum(keep[ext], m[ext])


def occ_net_keep(aligned_bgr, pts_aligned, size, M=None, frame_wh=None, raw_out=None, prev_cut=None, region=None,
                 wide=None):
    """1 = paint the swap, <1 = something is in front of the mouth/chin here. None when the net is unavailable or there is no outline."""
    sess = _OCCNET.get("sess")
    if sess is None or aligned_bgr is None or pts_aligned is None:
        return None
    try:
        t0 = time.perf_counter()
        W = 256
        m = occ_net_raw(aligned_bgr)
        if m is None:
            return None
        m = (np.clip(cv2.GaussianBlur(m, (0, 0), float(_P.get("occ_net_blur", 3.0))), 0.5, 1.0) - 0.5) * 2.0
        hull = np.zeros((W, W), np.uint8)
        pts = np.asarray(pts_aligned, np.float32) * (W / float(size))
        cv2.fillConvexPoly(hull, cv2.convexHull(np.round(pts).astype(np.int32)), 1)
        e = int(round(float(_P.get("occ_net_hull_erode", 0.08)) * W)) | 1
        hull0 = hull
        hull = cv2.erode(hull, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (e, e))).astype(bool)
        keep = np.ones((W, W), np.float32)
        occ = (m < 0.5) & hull
        if raw_out is not None:              # v11.2.206: where the model sees something in front, anywhere on the face
            raw_out.append(cv2.resize(occ.astype(np.uint8), (size, size), interpolation=cv2.INTER_NEAREST).astype(bool)
                           if size != W else occ.copy())
            raw_out.append(m)                # ...and its face map (256 px), for the caller's memory of where the face is
        # Where the crop runs off the picture it is filled with stretched edge pixels, which the model reads as an
        # occluder. Nothing that touches that part may be cut (a face at the frame edge stays as it was).
        outside = None
        if M is not None and frame_wh is not None:
            try:
                IM = cv2.invertAffineTransform(np.asarray(M, np.float32).reshape(2, 3))
                g = (np.arange(W, dtype=np.float32) + 0.5) * (size / float(W)) - 0.5
                gx, gy = np.meshgrid(g, g)
                ix = IM[0, 0] * gx + IM[0, 1] * gy + IM[0, 2]
                iy = IM[1, 0] * gx + IM[1, 1] * gy + IM[1, 2]
                fw, fh = float(frame_wh[0]), float(frame_wh[1])
                outside = (ix < 0.5) | (iy < 0.5) | (ix > fw - 1.5) | (iy > fh - 1.5)
                if bool(outside.any()):
                    outside = cv2.dilate(outside.astype(np.uint8), np.ones((9, 9), np.uint8)).astype(bool)
                else:
                    outside = None
            except Exception:
                outside = None
        if bool(occ.any()):
            yy, xx = np.mgrid[0:W, 0:W]
            cx = float(_P.get("occ_net_core_x", 0.17))
            core = (np.abs(xx / float(W) - 0.5) < cx) & (yy / float(W) >= float(_P.get("occ_net_core_y", 0.58)))
            need = float(_P.get("occ_net_core_min", 0.002)) * W * W
            n, lab = cv2.connectedComponents(occ.astype(np.uint8), connectivity=8)
            for c in range(1, n):
                comp = lab == c
                if outside is not None and bool((comp & outside).any()):
                    continue
                if float((comp & core).sum()) >= need:
                    keep[comp] = m[comp]
            core_keep = keep.copy()
            if (float(_P.get("occ_net_wide", 0.0) or 0.0) > 0.0) if wide is None else bool(wide):
                _occ_net_wide(keep, m, occ, hull, hull0, pts, outside, prev_cut, region, need, W)
        else:
            core_keep = keep
        if raw_out is not None:              # ...and the mouth rule's own cut (11.2.205's), for the eating rule
            raw_out.append(cv2.resize(core_keep, (size, size), interpolation=cv2.INTER_LINEAR) if size != W else core_keep.copy())
        if size != W:
            keep = cv2.resize(keep, (size, size), interpolation=cv2.INTER_LINEAR)
        OCCNET_STATS["ms"] += (time.perf_counter() - t0) * 1000.0
        return np.clip(keep, 0.0, 1.0).astype(np.float32)
    except Exception as e:
        log.debug("occlusion net skipped: %s", e)
        return None

_GRAIN_POOL = None
_GRAIN_POOL_N = 0


def _grain_field(h: int, w: int, rng=None):
    """A unit-variance noise tile, sampled at a random offset from a pool.

    Drawing fresh Gaussians every frame is the single most expensive thing in
    the whole plate-matching path: four 512x512 draws measured ~11 ms, more
    than the entire rest of the composite. A pool generated once and read at a
    random offset per frame is visually indistinguishable - the eye cannot
    detect reuse of a 1024-wide noise field offset differently each frame -
    and costs a memory copy. The variance is exactly 1 either way, so nothing
    downstream needs to change.
    """
    global _GRAIN_POOL, _GRAIN_POOL_N
    need = int(max(h, w)) * 2
    if _GRAIN_POOL is None or _GRAIN_POOL_N < need:
        _GRAIN_POOL_N = max(1024, need)
        _GRAIN_POOL = np.random.standard_normal(
            (_GRAIN_POOL_N, _GRAIN_POOL_N)).astype(np.float32)
    P = _GRAIN_POOL_N
    r = rng if rng is not None else np.random
    oy = int(r.integers(0, P - h)) if hasattr(r, "integers") else \
        int(r.randint(0, P - h))
    ox = int(r.integers(0, P - w)) if hasattr(r, "integers") else \
        int(r.randint(0, P - w))
    return _GRAIN_POOL[oy:oy + h, ox:ox + w]


def noise_sigma(gray: np.ndarray, w: np.ndarray) -> float:
    """Immerkaer noise estimate, restricted to the mask.

    Deliberately NOT "std of a high-pass", which a face defeats: pores, lashes
    and the lid crease are high-frequency STRUCTURE and would be counted as
    noise, so the estimate would ride up on detailed faces and the matcher
    would inject grain that is not there. Immerkaer's kernel is built to have
    zero response to any locally-quadratic surface, which is what smooth skin
    plus soft shading is, so structure largely cancels and noise does not.
    Reference: J. Immerkaer, "Fast Noise Variance Estimation", CVIU 1996.
    """
    try:
        if gray is None or w is None:
            return 0.0
        r = cv2.filter2D(gray.astype(np.float32), -1, _IMMERKAER,
                         borderType=cv2.BORDER_REFLECT101)
        wsum = float(w.sum())
        if wsum < 64.0:
            return 0.0
        # mean |response| under the mask, scaled to a Gaussian sigma
        return float(math.sqrt(math.pi / 2.0) * float((np.abs(r) * w).sum())
                     / (6.0 * wsum))
    except Exception:
        return 0.0


def motion_anisotropy(gray, ux: float, uy: float, w) -> float:
    """Gradient energy PERPENDICULAR to a direction, over energy ALONG it.

    This replaces an absolute sharpness comparison, which was wrong in a way
    that mattered: a restored face is SUPPOSED to be sharper than the plate -
    that is what the restorer is for - so "fake is sharper than target" is the
    normal case even on a locked-off tripod shot, and a pass driven by it
    would blur the restoration away on every frame with any movement at all.

    Motion blur is not a loss of sharpness, it is a DIRECTIONAL loss of
    sharpness: it suppresses detail along the travel axis and leaves detail
    across it untouched. So the quantity to match is the asymmetry, which is
    ~1.0 for any unblurred image at any detail level and climbs with blur
    length. Measured across detail amplitudes 8, 20 and 40 the three curves
    agree to within 3%, so this is genuinely independent of how much texture
    the face has - which is exactly the property the absolute measure lacked.
    """
    try:
        g = np.asarray(gray, np.float32)
        gx = cv2.Sobel(g, cv2.CV_32F, 1, 0, ksize=3)
        gy = cv2.Sobel(g, cv2.CV_32F, 0, 1, ksize=3)
        along = np.abs(gx * ux + gy * uy)
        perp = np.abs(gx * (-uy) + gy * ux)
        wsum = float(w.sum())
        if wsum < 64.0:
            return 1.0
        a = float((along * w).sum() / wsum)
        pq = float((perp * w).sum() / wsum)
        if a < 1e-6:
            return 1.0
        return pq / a
    except Exception:
        return 1.0


def _ema(prev, cur, a):
    if prev is None:
        return float(cur)
    return float(prev) * (1.0 - a) + float(cur) * a


def match_grain(face_bgr, plate_bgr, w, track=None, rng=None):
    """Add the grain the plate has and the restored face does not - IN IMAGE SPACE.

    This deliberately does NOT run on the aligned crop, and that is the whole
    point. Grain is what the sensor wrote onto the final pixel grid, so both
    halves of the job have to happen on that grid:

      * MEASURED on the untouched plate. The aligned target is produced by a
        bilinear warp, and bilinear interpolation averages neighbours, which
        is a low-pass filter - it destroys roughly half the grain amplitude
        before anything can measure it.
      * INJECTED after the paste warp, not before. Grain added to the crop
        goes through that same filter on the way back out, losing about half
        again, and is also geometrically stretched by the warp - which is
        something a camera cannot do.

    Measured end to end, doing this in crop space closed a 95% grain mismatch
    only as far as 85%. The reference region is the plate UNDER the mask: that
    is the original face, so it is the same subject at the same distance under
    the same lighting, which is the fairest grain reference available.
    """
    try:
        amt = float(_P.get("grain_strength", 0.0) or 0.0)
        if amt <= 0.0 or w is None:
            return face_bgr
        wsum = float(w.sum())
        if wsum < 64.0:
            return face_bgr

        s_t = noise_sigma(cv2.cvtColor(plate_bgr, cv2.COLOR_BGR2GRAY), w)
        s_f = noise_sigma(cv2.cvtColor(face_bgr, cv2.COLOR_BGR2GRAY), w)

        # Quadrature, not subtraction: noise powers add, amplitudes do not.
        deficit = math.sqrt(max(s_t * s_t - s_f * s_f, 0.0)) * amt
        deficit = min(deficit, float(_P.get("grain_max", 9.0)))

        if track is not None:
            track.grain_ema = _ema(getattr(track, "grain_ema", None), deficit,
                                   float(_P.get("grain_ema", 0.25)))
            deficit = float(track.grain_ema)
        if deficit < 0.35:          # below the 8-bit quantiser - invisible
            return face_bgr

        h, wd = face_bgr.shape[:2]
        chroma = float(_P.get("grain_chroma", 0.35))
        out = face_bgr.astype(np.float32)
        # Sensor grain is mostly luma; adding equal independent noise to all
        # three BGR channels produces coloured speckle that reads as
        # compression damage rather than film. One shared luma field plus a
        # weak independent chroma field per channel is what real grain looks
        # like. The mask weight keeps it inside the face, so it cannot put a
        # rectangle of sparkle on the background.
        lw = _grain_field(h, wd, rng) * (deficit * w)
        for c in range(3):
            out[:, :, c] += lw
            if chroma > 0.0:
                out[:, :, c] += _grain_field(h, wd, rng) * (deficit * chroma * w)
        np.clip(out, 0, 255, out=out)
        return out.astype(np.uint8)
    except Exception as e:
        log.debug("grain match skipped: %s", e)
        return face_bgr


def match_motion_blur(fake_bgr, target_bgr, mask, M, track=None):
    """Soften the swap to the plate's own sharpness, along the motion axis.

    The length is not guessed from shutter physics - it is MEASURED, from how
    DIRECTIONAL the plate's own blur is (see motion_anisotropy). Comparing
    absolute sharpness instead would be wrong in a way that defeats the whole
    build: the restored face is meant to be sharper than the plate, so that
    comparison fires on every moving frame and blurs the restoration away.
    Anisotropy is ~1.0 for any unblurred face regardless of how much texture
    it has, so on a tripod shot this pass measures no deficit and does
    nothing at all, while on a whip pan it measures a large one.

    The direction comes from the track's image-space keypoint velocity pushed
    through M's linear part, because the blur has to lie along the face's
    motion IN THE CROP, which rotates with the head.
    """
    try:
        amt = float(_P.get("mblur_strength", 0.0) or 0.0)
        if amt <= 0.0 or track is None or mask is None:
            return fake_bgr
        v = getattr(track, "vel_kps", None)
        if v is None:
            return fake_bgr
        vel = np.asarray(v, np.float32).reshape(-1, 2).mean(axis=0)
        A = np.asarray(M, np.float32).reshape(2, 3)[:, :2]
        va = A @ vel                      # image-space velocity -> crop space
        speed = float(np.hypot(va[0], va[1]))
        size = int(fake_bgr.shape[0])
        if speed < max(1.0, size * 0.004):
            return fake_bgr               # effectively still - never soften

        w = mask.astype(np.float32)
        if float(w.sum()) < 64.0:
            return fake_bgr
        ux, uy = float(va[0]) / speed, float(va[1]) / speed
        a_t = motion_anisotropy(cv2.cvtColor(target_bgr, cv2.COLOR_BGR2GRAY),
                                ux, uy, w)
        a_f = motion_anisotropy(cv2.cvtColor(fake_bgr, cv2.COLOR_BGR2GRAY),
                                ux, uy, w)
        # The plate must be measurably MORE smeared along the travel axis than
        # the swap is. On a sharp plate both sides read ~1.0, the deficit is
        # zero, and nothing happens - which is the behaviour that makes this
        # safe to leave on.
        deficit = a_t - a_f
        if deficit <= 0.05:
            return fake_bgr

        L = 1.0 + deficit * float(_P.get("mblur_k", 6.0)) * amt
        # Never blur further than the motion itself could have smeared, and
        # never past the global cap - an over-long kernel turns a fast turn
        # into a smear that no real camera would produce.
        L = min(L, speed, size * float(_P.get("mblur_max", 0.055)))
        if track is not None:
            track.mblur_ema = _ema(getattr(track, "mblur_ema", None), L,
                                   float(_P.get("mblur_ema", 0.30)))
            L = float(track.mblur_ema)
        k = int(round(L))
        if k < 2:
            return fake_bgr
        k = min(k | 1, 31)                # odd, and bounded for cost

        kern = np.zeros((k, k), np.float32)
        kern[k // 2, :] = 1.0
        ang = math.degrees(math.atan2(float(va[1]), float(va[0])))
        R = cv2.getRotationMatrix2D((k / 2.0 - 0.5, k / 2.0 - 0.5), -ang, 1.0)
        kern = cv2.warpAffine(kern, R, (k, k), flags=cv2.INTER_LINEAR)
        ssum = float(kern.sum())
        if ssum <= 1e-6:
            return fake_bgr
        kern /= ssum

        blurred = cv2.filter2D(fake_bgr, -1, kern,
                               borderType=cv2.BORDER_REFLECT101)
        # Feather the swap-in by the mask so the crop border never shows a
        # step between blurred and unblurred pixels.
        w3 = w[:, :, None]
        return (blurred.astype(np.float32) * w3
                + fake_bgr.astype(np.float32) * (1.0 - w3)).astype(np.uint8)
    except Exception as e:
        log.debug("motion-blur match skipped: %s", e)
        return fake_bgr


class AlignedCompositor:
    """Swap + blend entirely inside the ArcFace-aligned crop."""

    def __init__(self, swapper):
        self.swapper = swapper
        self._warned_no_M = False

    # -- inswapper interop ---------------------------------------------
    def _raw_swap(self, img, face, src_face):
        """Return (bgr_fake_128, M) or (None, None).

        insightface's INSwapper.get(..., paste_back=False) returns
        (bgr_fake, M). Older/forked builds may return only bgr_fake. If M
        is missing we recover it from the 5-point ArcFace template. If get()
        fails entirely we run the ONNX session ourselves with the swapper's
        own emap — that is the actual "no swap / original face" recovery,
        not a rewrite of the pipeline.
        """
        size = 128
        insz = getattr(self.swapper, "input_size", None)
        if insz is not None:
            size = int(insz[0] if not isinstance(insz, int) else insz)
        M_est = estimate_norm(getattr(face, "kps", None), size)

        out = None
        try:
            out = self.swapper.get(img, face, src_face, paste_back=False)
        except Exception as e:
            log.debug("paste_back=False unsupported (%s)", e)

        fake, M = None, None
        if isinstance(out, (tuple, list)) and len(out) >= 1:
            fake = out[0]
            if len(out) >= 2:
                M = out[1]
        elif isinstance(out, np.ndarray):
            fake = out

        if fake is not None:
            fake = np.asarray(fake)
            if fake.ndim == 4:
                fake = fake[0]
            if fake.ndim == 3 and fake.shape[0] in (1, 3) and fake.shape[-1] not in (1, 3):
                fake = np.transpose(fake, (1, 2, 0))
            if fake.dtype != np.uint8:
                if float(np.max(fake)) <= 1.5:
                    fake = fake * 255.0
                fake = np.clip(fake, 0, 255).astype(np.uint8)
            # A full-frame paste-back is not an aligned crop.
            if fake.ndim == 3 and fake.shape[0] == img.shape[0] and fake.shape[1] == img.shape[1]:
                fake = None
            elif fake.ndim != 3 or min(fake.shape[:2]) < 64:
                fake = None

        if M is not None:
            try:
                M = np.asarray(M, np.float32).reshape(2, 3)
            except Exception:
                M = None
        if M is None:
            M = M_est

        if fake is not None and M is not None:
            return fake, M

        bound = self._raw_swap_session(img, face, src_face, M_est, size)
        if bound[0] is not None:
            return bound

        if not self._warned_no_M:
            log.warning("inswapper did not return an aligned crop; "
                        "caller will use the paste-back path")
            self._warned_no_M = True
        return None, None

    def _raw_swap_session(self, img, face, src_face, M, size):
        """Direct ONNX forward using the loaded inswapper session + emap."""
        sw = self.swapper
        sess = getattr(sw, "session", None)
        kps = getattr(face, "kps", None)
        latent = getattr(src_face, "normed_embedding", None)
        if latent is None:
            latent = getattr(src_face, "embedding", None)
        if sess is None or kps is None or latent is None:
            return None, None
        if M is None:
            M = estimate_norm(kps, size)
        if M is None:
            return None, None
        try:
            aimg = cv2.warpAffine(
                img, M, (size, size),
                flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE,
            )
            lat = np.asarray(latent, np.float32).reshape(1, -1)
            nrm = float(np.linalg.norm(lat))
            if nrm > 1e-6:
                lat = lat / nrm
            emap = getattr(sw, "emap", None)
            if emap is not None:
                lat = np.dot(lat, np.asarray(emap, np.float32))
                lat = lat / (np.linalg.norm(lat) + 1e-6)
            mean = float(getattr(sw, "input_mean", 0.0) or 0.0)
            std = float(getattr(sw, "input_std", 255.0) or 255.0)
            blob = cv2.dnn.blobFromImage(
                aimg, 1.0 / std, (size, size), (mean, mean, mean), swapRB=True,
            )
            names = list(getattr(sw, "input_names", None) or [i.name for i in sess.get_inputs()])
            onames = list(getattr(sw, "output_names", None) or [o.name for o in sess.get_outputs()])
            feeds = {names[0]: np.ascontiguousarray(blob)}
            if len(names) > 1:
                feeds[names[1]] = np.ascontiguousarray(lat.astype(np.float32))
            pred = sess.run([onames[0]], feeds)[0]
            fake = np.asarray(pred)
            if fake.ndim == 4:
                fake = fake[0]
            if fake.ndim == 3 and fake.shape[0] in (1, 3):
                fake = np.transpose(fake, (1, 2, 0))
            if float(np.max(fake)) <= 1.5:
                fake = fake * 255.0
            fake = np.clip(fake, 0, 255).astype(np.uint8)
            if fake.shape[-1] == 3:
                fake = fake[:, :, ::-1]
            return fake, np.asarray(M, np.float32).reshape(2, 3)
        except Exception as e:
            log.debug("session swap skipped: %s", e)
            return None, None

    # -- mask ------------------------------------------------------------
    def build_mask(self, face, M, size, track=None, occlusion_guard=0.0,
                   aligned_target=None, rivals=None, frame_wh=None):
        """Face mask in aligned space.

        ``occlusion_guard`` is a CONTINUOUS weight in [0,1], not a flag: a
        boolean guard changed the mask silhouette (and therefore the colour
        statistics weighted by it) in a single frame every time it toggled.

        ``rivals`` are other faces' image-space landmark sets belonging to
        people who are IN FRONT of this one. Two faces in contact have
        essentially identical chroma, so skin_confidence() is blind to a cheek
        pressed against this face - but the rival's own landmarks say exactly
        where it is, and they project into this crop through the same affine.
        """
        mask = canonical_template(size).copy()

        pts = _landmarks_to_aligned(getattr(face, "landmark_2d_106", None), M, size)
        h = hull_mask(pts, size)
        if track is not None:
            h = track.smooth_hull(h)
        if h is not None:
            floor = float(_P["hull_floor"])
            shaped = floor + (1.0 - floor) * h
            # The jaw hull follows the lips and was opening and closing
            # the lower lip and chin. Below the mouth the steady oval
            # is the mask, so that edge does not breathe.
            row = np.linspace((0.5 / size), 1.0 - (0.5 / size), size, dtype=np.float32)[:, None]
            lower = np.clip((row - 0.68) / 0.08, 0.0, 1.0).astype(np.float32)
            shaped = shaped * (1.0 - lower) + lower
            mask = mask * shaped
        else:
            row = None

        # Extreme side view (SDOS-092): move over to the face's own outline. 0 below ~45 deg = mask unchanged.
        pw = profile_weight(getattr(face, "kps", None))
        if track is not None:
            prev_pw = getattr(track, "prof_w", None)
            pw = pw if prev_pw is None else 0.6 * float(prev_pw) + 0.4 * pw
            track.prof_w = pw
        if pw < 0.005:
            pw = 0.0
        if pw > 0.0 and aligned_target is not None:
            pm = profile_mask(aligned_target, pts, size)
            if pm is not None:
                mask = mask * (1.0 - pw) + pm * pw
                try:
                    PROFILE_STATS["frames"] += 1
                    PROFILE_STATS["w_sum"] += pw
                except Exception:
                    pass

        if rivals:
            cut = float(_P.get("rival_cut", 0.85) or 0.0)
            if cut > 0.0:
                block = np.zeros((size, size), np.float32)
                for rl in rivals:
                    rp = _landmarks_to_aligned(rl, M, size)
                    rh = hull_mask(rp, size)
                    if rh is not None:
                        np.maximum(block, rh, out=block)
                if float(block.max()) > 0.02:
                    k = int(max(3, round(size * float(_P.get("rival_feather", 0.09))))) | 1
                    block = cv2.GaussianBlur(block, (k, k), 0)
                    mask = mask * (1.0 - cut * np.clip(block, 0.0, 1.0))

        g = float(np.clip(occlusion_guard, 0.0, 1.0))
        if g > 0.01 and aligned_target is not None:
            conf = skin_confidence(aligned_target, mask)
            mask = mask * (1.0 - g + g * conf)

        mask = np.clip(mask, 0.0, 1.0).astype(np.float32)
        if track is not None:
            mask = track.smooth_mask(mask)
        # v11.2.206: the occlusion model runs first, so its view (anywhere on the face) can confirm the colour test, and
        # the flow of the footage inside the crop moves last frame's cuts with the object.
        _raw = []
        _nk_early = None
        _wide_now = False
        _flow = _occ_flow(track, aligned_target) if (track is not None and aligned_target is not None
                                                     and float(_P.get("occ_flow", 0.0) or 0.0) > 0.0) else None
        if aligned_target is not None and pts is not None and float(_P.get("occ_net", 0.0) or 0.0) > 0.0:
            _pc = None
            _wide = float(_P.get("occ_net_wide", 0.0) or 0.0) > 0.0
            # v11.2.206: the wide cut stands aside where 11.2.205's own rules decide - two faces in contact (the rival cut
            # decides front and behind) and a turned face (over ~35 deg the outline reaches past the face, where the model
            # rightly sees no face)
            _yo = _yaw_offset(getattr(face, "kps", None))
            _wide_now = _wide and not rivals and _yo is not None and _yo < float(_P.get("occ_net_wide_yaw", 0.34))
            if track is not None and _wide_now:
                _pv = getattr(track, "occn_keep", None)
                if _pv is not None and getattr(_pv, "shape", None) == (size, size) and float(_pv.min()) < 0.5:
                    if _flow is not None:
                        _pv = _occ_warp(_pv, _flow, size)
                    _pc = cv2.resize(_pv, (256, 256), interpolation=cv2.INTER_LINEAR) < 0.5
            _rg = None
            if _wide_now and track is not None:
                _fr = getattr(track, "occ_face_ref", None)
                if _fr is not None and getattr(_fr, "shape", None) == (256, 256):
                    # (not moved with the flow: the crop is aligned to the face, so the face stays where it is in it)
                    _rg = _fr > float(_P.get("occ_net_wide_face", 0.4))   # the model saw face here on recent frames
            _nk_early = occ_net_keep(aligned_target, pts, size, M=M, frame_wh=frame_wh,
                                     raw_out=_raw if (_wide or float(_P.get("occ_instant", 0.0) or 0.0) > 0.0) else None,
                                     prev_cut=_pc, region=_rg, wide=_wide_now)
            if _wide and track is not None and len(_raw) >= 2 and _raw[1] is not None:
                # remember where the face is: learnt where nothing is cut now, so an object never teaches itself as face
                _fm = (_raw[1] >= 0.5).astype(np.float32)
                _fr = getattr(track, "occ_face_ref", None)
                if _fr is None or getattr(_fr, "shape", None) != _fm.shape:
                    track.occ_face_ref = _fm
                else:
                    _cutnow = (cv2.resize(_nk_early, (256, 256), interpolation=cv2.INTER_LINEAR) < 0.5
                               if _nk_early is not None else np.zeros_like(_fm, bool))
                    _r0 = _raw[0] if _raw[0].shape == (256, 256) else cv2.resize(
                        _raw[0].astype(np.uint8), (256, 256), interpolation=cv2.INTER_NEAREST).astype(bool)
                    _cutnow |= _r0                                  # inside the outline "not face" is always something in front
                    upd = 0.85 * _fr + 0.15 * _fm
                    track.occ_face_ref = np.where(_cutnow, _fr, upd).astype(np.float32)
        _K = None
        # After the temporal mask, so a cone or scoop is removed on the
        # frame it appears instead of being smoothed back in.
        if aligned_target is not None:
            keep = occluder_keep(aligned_target,
                                 ref=getattr(track, "occ_ref", None) if track is not None else None,
                                 nref=getattr(track, "occ_nref", 0) if track is not None else 0)
            if track is not None:
                prev = getattr(track, "occ_keep", None)
                if prev is None or getattr(prev, "shape", None) != keep.shape:
                    track.occ_keep = np.ones_like(keep)
                else:
                    # The hole used to open at 0.10 per frame, which is 22
                    # frames to reach 90% of it - most of a second of the new
                    # face being painted over the spoon before the hole was
                    # even open, and for food that moves to and from the mouth
                    # every second it never opened at all. Opening is now the
                    # FAST direction (occ_open) because the detector it is
                    # smoothing no longer fires on lips, an open mouth, a
                    # beard, glasses, a shadow or a lighting change; closing
                    # stays slower, as cheap insurance against a blink.
                    o = float(_P.get("occ_open", 0.45))
                    c = float(_P.get("occ_close", 0.22))
                    prev_k = _occ_warp(track.occ_keep, _flow, keep.shape[0]) if _flow is not None else track.occ_keep
                    opening = keep < prev_k
                    a = np.where(opening, o, c).astype(np.float32)
                    if _raw and _raw[0].shape == keep.shape and float(_P.get("occ_instant", 0.0) or 0.0) > 0.0:
                        a[opening & _raw[0]] = 1.0       # v11.2.206: both tests see the object - cut it on this frame
                    track.occ_keep = (prev_k * (1.0 - a)
                                      + keep * a).astype(np.float32)
                keep = track.occ_keep
                try:
                    OCC_STATS["frames"] += 1
                    _cut = float(1.0 - float(keep.mean()))
                    if _cut > 0.002:
                        OCC_STATS["cut_frames"] += 1
                        OCC_STATS["cut_area_sum"] += _cut
                except Exception:
                    pass
                # Learn AFTER deciding, from the decision, so the model is
                # never taught the occluder it just rejected.
                track.occ_ref, track.occ_nref = update_face_ref(
                    track.occ_ref, track.occ_nref, aligned_target, keep)
            _K = keep
        _nk_final = None
        if aligned_target is not None and pts is not None and float(_P.get("occ_net", 0.0) or 0.0) > 0.0:
            nk = _nk_early
            if nk is not None:
                if track is not None:
                    prev = getattr(track, "occn_keep", None)
                    if prev is not None and _flow is not None and getattr(prev, "shape", None) == nk.shape:
                        prev = _occ_warp(prev, _flow, nk.shape[0])      # v11.2.206: the give-back follows the object
                    if prev is not None and getattr(prev, "shape", None) == nk.shape:
                        # a cut follows at once; giving the face back takes a few frames, so one missed frame does not flash
                        _sm = np.minimum(nk, 0.5 * prev + 0.5 * nk).astype(np.float32)
                        if (_wide_now and len(_raw) >= 3
                                and getattr(_raw[2], "shape", None) == nk.shape):
                            # v11.2.206: ...except where the model is sure it sees face again (away from the mouth rule's
                            # cut): the face comes back on that frame, so a hand moving on leaves no ghost behind it
                            _sure = cv2.resize(_raw[1], (nk.shape[1], nk.shape[0]), interpolation=cv2.INTER_LINEAR) > float(
                                _P.get("occ_net_back", 0.9))
                            _sm = np.where(_sure & (_raw[2] > 0.999), nk, _sm).astype(np.float32)
                        nk = _sm
                    track.occn_keep = nk
                try:
                    OCCNET_STATS["frames"] += 1
                    _c = float((nk < 0.5).mean())
                    if _c > 0.001:
                        OCCNET_STATS["cut_frames"] += 1
                        OCCNET_STATS["cut_area_sum"] += _c
                except Exception:
                    pass
                _K = nk if _K is None else _K * nk
                _nk_final = nk
        if _K is not None:
            if float(_P.get("occ_snap", 0.0) or 0.0) > 0.0 and aligned_target is not None and float(_K.min()) < 0.98:
                _K = _occ_snap(_K, aligned_target, size)          # v11.2.206: a clean edge where the object crosses the face
            mask = mask * _K
        if _nk_final is not None and len(_raw) >= 3 and getattr(_raw[2], "shape", None) == _nk_final.shape:
            # the eating rule sees only the mouth rule's cut, smoothed exactly as in v11.2.205: a hand or cup on the cheek
            # is not someone eating
            _ec = _raw[2]
            if track is not None:
                _pe = getattr(track, "occn_core", None)
                if _pe is not None and getattr(_pe, "shape", None) == _ec.shape:
                    _ec = np.minimum(_ec, 0.5 * _pe + 0.5 * _ec).astype(np.float32)
                track.occn_core = _ec
            _nk_eat = _ec
        else:
            _nk_eat = _nk_final
        if _nk_eat is not None and float(_P.get("eat_mouth", 0.0) or 0.0) > 0.0:
            mask = _eating_mouth(mask, _nk_eat, pts, size, track)          # this frame's model answer, as in v11.2.205
        if row is not None:
            # Longer falloff under the chin only. The lip stays fully painted.
            t = np.clip((row - 0.86) / 0.14, 0.0, 1.0)
            ramp = np.cos(t * (np.pi * 0.5)).astype(np.float32)
            mask = np.minimum(mask, ramp)
        return np.clip(mask, 0.0, 1.0).astype(np.float32)

    # -- colour ----------------------------------------------------------
    @staticmethod
    def _masked_stats(lab: np.ndarray, w: np.ndarray):
        """Mask-weighted per-channel mean and std.

        Deliberately a per-channel loop over contiguous 2D slices. A "vectorised"
        version that broadcasts the weights over all three channels at once was
        measured 5x SLOWER (1.69 ms vs 0.34 ms): it allocates two full
        HxWx3 float arrays and reduces over a non-contiguous axis, whereas each
        2D slice here stays in cache.
        """
        wsum = float(w.sum())
        if wsum < 32.0:
            return None, None
        mean = np.empty(3, np.float32)
        std = np.empty(3, np.float32)
        for c in range(3):
            ch = lab[:, :, c]
            m = float((ch * w).sum() / wsum)
            v = float((((ch - m) ** 2) * w).sum() / wsum)
            mean[c] = m
            std[c] = math.sqrt(max(v, 1e-6))
        return mean, std

    def colour_match(self, fake_bgr, target_bgr, mask, track=None, strength=1.0):
        """Match the swap to the scene using FACE-ONLY statistics.

        The historical bug: statistics were taken over the whole detector bbox,
        which on a profile turn is mostly hair and background. Matching to that
        pushed the face toward the background colour -> the brown patch. Here
        every statistic is weighted by the face mask, inside a crop that
        contains nothing but the face.
        """
        if strength <= 0:
            return fake_bgr
        w = mask.astype(np.float32)
        if float(w.sum()) < 32.0:
            return fake_bgr

        f_lab = cv2.cvtColor(fake_bgr, cv2.COLOR_BGR2LAB).astype(np.float32)
        t_lab = cv2.cvtColor(target_bgr, cv2.COLOR_BGR2LAB).astype(np.float32)
        # Statistics are gathered at FULL resolution on purpose. Gathering them
        # on a half-scale copy saves only ~0.1 ms and area-averaging destroys
        # variance: the measured per-channel std came out ~15 LAB levels low.
        # std drives `ratio`, the contrast-matching term - the exact quantity
        # whose mis-scaling produced the flat "brown patch" this engine was
        # written to fix. Not a safe place to trade accuracy for speed.
        fm, fs = self._masked_stats(f_lab, w)
        tm, ts = self._masked_stats(t_lab, w)
        if fm is None or tm is None:
            return fake_bgr

        dmean = np.clip(tm - fm, -_P["cm_max_shift"], _P["cm_max_shift"]).astype(np.float32)
        ratio = np.clip(ts / (fs + 1e-6), _P["cm_std_lo"], _P["cm_std_hi"]).astype(np.float32)

        if track is not None:
            dmean, ratio = track.smooth_colour(dmean, ratio)

        s = np.array([_P["cm_strength_l"], _P["cm_strength_ab"],
                      _P["cm_strength_ab"]], np.float32) * float(strength)
        eff_ratio = 1.0 + (ratio - 1.0) * s
        eff_dmean = dmean * s

        # In-place on f_lab — no full LAB duplicate (CPU bandwidth). Per-channel
        # for the same cache reason as _masked_stats: broadcasting this over all
        # three channels at once measured 2.6x slower (0.37 ms vs 0.14 ms).
        for c in range(3):
            f_lab[:, :, c] = (f_lab[:, :, c] - fm[c]) * eff_ratio[c] + fm[c] + eff_dmean[c]
        np.clip(f_lab, 0, 255, out=f_lab)
        return cv2.cvtColor(f_lab.astype(np.uint8), cv2.COLOR_LAB2BGR)

    # -- paste back --------------------------------------------------------
    @staticmethod
    def paste_back(img, fake_bgr, mask, M, alpha=1.0, orig=None, track=None):
        """Warp the aligned result back using a face-sized destination ROI.

        The old implementation called ``warpAffine(..., (W, H))`` twice for
        every face swap. At 720p/1080p that means allocating and filling two
        full-resolution images even though the actual replacement occupies a
        small face ROI. The affine transform is identical; only the destination
        coordinate system is translated to the ROI. This preserves the visual
        result while removing most of the per-swap memory bandwidth.
        """
        H, W = img.shape[:2]
        IM = cv2.invertAffineTransform(np.asarray(M, np.float32).reshape(2, 3))

        # Transform the aligned-crop corners to obtain a conservative image-space
        # ROI. The aligned crop is only 128x128 for the standard inswapper model,
        # so this bounds the replacement without ever creating a W×H warp buffer.
        size_h, size_w = fake_bgr.shape[:2]
        corners = np.array([[[0.0, 0.0], [size_w - 1.0, 0.0],
                            [size_w - 1.0, size_h - 1.0], [0.0, size_h - 1.0]]],
                           dtype=np.float32)
        dst = cv2.transform(corners, IM)[0]
        x1 = max(0, int(np.floor(dst[:, 0].min())) - 2)
        y1 = max(0, int(np.floor(dst[:, 1].min())) - 2)
        x2 = min(W, int(np.ceil(dst[:, 0].max())) + 3)
        y2 = min(H, int(np.ceil(dst[:, 1].max())) + 3)
        if x2 <= x1 or y2 <= y1:
            return img

        rw, rh = x2 - x1, y2 - y1
        # cv2.warpAffine treats the supplied matrix as a source->destination
        # transform and internally inverts it. To make the destination origin
        # equal to (x1,y1), translate the source->destination matrix by -ROI
        # origin; this is equivalent to cropping the full-frame warp without
        # changing any sampled pixels.
        local_M = IM.copy()
        local_M[:, 2] -= np.array([float(x1), float(y1)], np.float32)

        # The two warps must keep DIFFERENT border modes and therefore cannot be
        # packed into one 4-channel call. The canonical template is 0.881 at the
        # bottom-centre edge of the aligned crop (the chin runs right off it), so
        # warping the face with BORDER_CONSTANT would blend black in under the
        # chin at ~0.9 alpha - a dark fringe exactly where a seam is most
        # visible. BORDER_REPLICATE on the face is load-bearing.
        warp_face = cv2.warpAffine(fake_bgr, local_M, (rw, rh),
                                   flags=cv2.INTER_LINEAR,
                                   borderMode=cv2.BORDER_REPLICATE)
        warp_mask = cv2.warpAffine(mask, local_M, (rw, rh),
                                   flags=cv2.INTER_LINEAR,
                                   borderMode=cv2.BORDER_CONSTANT, borderValue=0)
        if float(warp_mask.max()) * float(alpha) <= 0.004:
            return img

        # Grain, on the output pixel grid, with the plate under the mask as
        # the reference. Here and nowhere earlier - see match_grain.
        if orig is not None:
            try:
                warp_face = match_grain(warp_face, orig[y1:y2, x1:x2],
                                        warp_mask, track=track)
            except Exception as e:
                log.debug("grain stage skipped: %s", e)

        out = img if img.flags.writeable else img.copy()
        roi = out[y1:y2, x1:x2]
        # 8-bit alpha composite through OpenCV's SIMD paths rather than
        # promoting the whole destination ROI to float32. The ROI is an order of
        # magnitude larger than the 128x128 aligned crop (typically ~290x290 at
        # 720p), so the float round-trip was the single most expensive step in
        # the per-frame composite: 1.44 ms of it, against 0.26 ms here.
        # Difference against the float path is at most 2/255 on a handful of
        # pixels - below the quantisation of the 8-bit output either way.
        m3 = cv2.cvtColor(cv2.convertScaleAbs(warp_mask, alpha=255.0 * float(alpha)),
                          cv2.COLOR_GRAY2BGR)
        cv2.add(cv2.multiply(warp_face, m3, scale=1.0 / 255.0),
                cv2.multiply(roi, cv2.bitwise_not(m3), scale=1.0 / 255.0),
                dst=roi)
        return out

    # -- composite tail (shared by the swap and reuse paths) ----------------
    def _composite(self, work, orig, face, fake, M, *, track, alpha,
                   colour_strength, occlusion_guard, rivals):
        size = int(fake.shape[0])
        aligned_target = cv2.warpAffine(orig, M, (size, size),
                                        borderMode=cv2.BORDER_REPLICATE)
        mask = self.build_mask(face, M, size, track=track,
                               occlusion_guard=occlusion_guard,
                               aligned_target=aligned_target,
                               rivals=rivals,
                               frame_wh=(int(orig.shape[1]), int(orig.shape[0])))
        toned = self.colour_match(fake, aligned_target, mask, track=track,
                                  strength=colour_strength)
        # Motion blur belongs HERE, in aligned space: it is a property of the
        # optics, so it must act on the face before the sensor stage, and the
        # aligned crop is the frame the head itself lives in, so one direction
        # vector describes it correctly however the head is rotated.
        toned = match_motion_blur(toned, aligned_target, mask, M, track=track)
        # Grain belongs in paste_back, on the output pixel grid, which is where
        # the sensor put it. Passing `orig` is what switches that stage on.
        return self.paste_back(work, toned, mask, M, alpha=alpha,
                               orig=orig, track=track)

    # -- one-shot -----------------------------------------------------------
    def run(self, work, orig, face, src_face, *, track=None, alpha=1.0,
            colour_strength=1.0, occlusion_guard=0.0, rivals=None,
            frame_ord=0, post=None):
        """Swap `face` in `work` with `src_face`. Returns (image, ok).

        The aligned result is cached on ``track`` so later frames can be
        composited from it without another ONNX forward pass - see
        ``reuse()``. ``post`` is an optional callable applied ONCE to the
        aligned crop (this is where a face enhancer belongs: enhancing the
        cached crop means every frame that reuses it is enhanced identically,
        instead of enhanced and unenhanced frames alternating at the swap
        cadence and pulsing).
        """
        fake, M = self._raw_swap(work, face, src_face)
        if fake is None:
            return work, False

        size = int(fake.shape[0])
        if post is not None:
            try:
                p = post(fake)
                # Accept a restorer that returns a LARGER square crop and keep
                # it. The old guard required the same shape, so a 512 restored
                # face was silently discarded and the 128 one used instead -
                # the enhancer's entire output thrown away. Everything
                # downstream is already size-parameterised; only the affine has
                # to be told the crop grew.
                if p is not None and getattr(p, "ndim", 0) == 3 \
                        and p.shape[0] == p.shape[1] and p.shape[0] >= size:
                    want = choose_crop_size(M, size, int(p.shape[0]))
                    if want != int(p.shape[0]):
                        p = cv2.resize(p, (want, want),
                                       interpolation=cv2.INTER_AREA)
                    if want != size:
                        M = scale_affine(M, float(want) / float(size))
                        size = want
                    fake = p
            except Exception as e:
                log.debug("aligned post-process skipped: %s", e)

        if track is not None:
            track.cache_fake(fake, aligned_correction(getattr(face, "kps", None), M, size),
                             frame_ord)

        out = self._composite(work, orig, face, fake, M, track=track, alpha=alpha,
                              colour_strength=colour_strength,
                              occlusion_guard=occlusion_guard, rivals=rivals)
        return out, True

    # -- reuse a cached aligned result on a later frame ---------------------
    def reuse(self, work, orig, kps, face, *, track, alpha=1.0,
              colour_strength=1.0, occlusion_guard=0.0, rivals=None):
        """Composite the cached aligned swap onto THIS frame's geometry.

        This is what replaces "paste the face ROI copied out of a different
        frame". The expensive part of a swap is the ONNX forward pass; the
        placement, the mask, the background and the colour match are cheap and
        are all recomputed here from the CURRENT frame. So a frame the swapper
        did not run on still gets its face in the right place, at the right
        angle, lit by its own scene - rather than a rectangle of some other
        moment stamped on top of it.
        """
        if track is None or track.fake is None:
            return work, False
        size = int(track.fake_size or track.fake.shape[0])
        M = estimate_norm(kps, size)
        if M is None:
            return work, False
        M = apply_correction(track.fake_corr, M)
        out = self._composite(work, orig, face, track.fake, M, track=track,
                              alpha=alpha, colour_strength=colour_strength,
                              occlusion_guard=occlusion_guard, rivals=rivals)
        return out, True


def swap_and_composite(swapper, work, orig, face, src_face, **kw):
    """Convenience wrapper. Returns (image, ok)."""
    return AlignedCompositor(swapper).run(work, orig, face, src_face, **kw)


def _det_gender(face):
    """InsightFace buffalo: 0 = female, 1 = male. Always a Python int or None."""
    if face is None:
        return None
    g = getattr(face, "gender", None)
    if g is None:
        g = getattr(face, "sex", None)
    if g is None:
        return None
    try:
        if isinstance(g, (bytes, str)):
            s = str(g).lower()
            if "female" in s or s in ("f", "w"):
                return 0
            if "male" in s or s == "m":
                return 1
            return None
        arr = np.asarray(g).reshape(-1)
        if arr.size == 0:
            return None
        if arr.size > 1:
            iv = int(np.argmax(arr))
        else:
            iv = int(arr[0])
        if iv in (0, 1):
            return iv
    except Exception:
        return None
    return None


# --------------------------------------------------------------------------
# Multi-face association
# --------------------------------------------------------------------------
def _iou(a, b):
    if a is None or b is None:
        return 0.0
    try:
        a = np.asarray(a, dtype=np.float32).reshape(-1)
        b = np.asarray(b, dtype=np.float32).reshape(-1)
        ax1, ay1, ax2, ay2 = [float(v) for v in a[:4]]
        bx1, by1, bx2, by2 = [float(v) for v in b[:4]]
    except Exception:
        return 0.0
    iw = max(0.0, min(ax2, bx2) - max(ax1, bx1))
    ih = max(0.0, min(ay2, by2) - max(ay1, by1))
    inter = iw * ih
    if inter <= 0:
        return 0.0
    ua = max(0.0, ax2 - ax1) * max(0.0, ay2 - ay1)
    ub = max(0.0, bx2 - bx1) * max(0.0, by2 - by1)
    u = ua + ub - inter
    return float(inter / u) if u > 0 else 0.0


def _two_boxes(a, b):
    """v11.2.176 (SDOS-176): two boxes are two faces: overlap under 0.40 and neither box's centre inside the other box. In a
    side-view kiss the two faces' 5 points sit within about 20 px of each other (all on the front half of each face), so a points
    test calls them one face; their boxes stay apart (measured: overlap 0.13-0.16, each centre outside the other box). A second
    box on one face (a cheek box, a zoomed box) has its centre inside the first."""
    try:
        a = np.asarray(a, dtype=np.float32).reshape(-1); b = np.asarray(b, dtype=np.float32).reshape(-1)
        if _iou(a, b) >= 0.40:
            return False
        for p, q in ((a, b), (b, a)):
            cx, cy = (p[0] + p[2]) * .5, (p[1] + p[3]) * .5
            if q[0] <= cx <= q[2] and q[1] <= cy <= q[3]:
                return False
        return True
    except Exception:
        return False


def _cdist_norm(a, b):
    if a is None or b is None:
        return 9.0
    try:
        a = np.asarray(a, dtype=np.float32).reshape(-1)
        b = np.asarray(b, dtype=np.float32).reshape(-1)
        ca = np.array([(a[0] + a[2]) * .5, (a[1] + a[3]) * .5], np.float32)
        cb = np.array([(b[0] + b[2]) * .5, (b[1] + b[3]) * .5], np.float32)
        diag = max(1.0, float((a[2] - a[0] + a[3] - a[1]) * 0.5))
        return float(np.linalg.norm(ca - cb) / diag)
    except Exception:
        return 9.0


def optimal_assignment(cost, forbidden=None):
    """Exact minimum-cost assignment for the tiny matrices we deal with.

    Still exhaustive - slots <= 4 - but over COLUMN choices only. The previous
    implementation looped over permutations of rows AND columns, which
    enumerates every assignment r! times over: at 4 slots x 12 detections that
    measured 209 ms of pure Python per frame, on a build whose whole point is
    CPU throughput. Iterating rows in fixed order and permuting only the
    columns visits each distinct assignment exactly once.

    Partial assignments (fewer pairs than min(n, m)) are still reachable:
    the search descends row by row and may leave a row unassigned, so a row
    with no admissible column no longer blocks the rows after it.
    """
    n = len(cost)
    if n == 0:
        return {}
    m = len(cost[0])
    if m == 0:
        return {}
    forbidden = forbidden or set()

    best = {"pairs": 0, "cost": float("inf"), "map": {}}
    cur = {}

    def rec(i, used, total, pairs):
        if i == n:
            if pairs > best["pairs"] or (pairs == best["pairs"] and total < best["cost"]):
                best["pairs"], best["cost"], best["map"] = pairs, total, dict(cur)
            return
        # The objective is lexicographic - most pairs first, then least cost -
        # so a branch may only be pruned on cost once it is established that it
        # cannot beat the incumbent on pair count either.
        reach = pairs + (n - i)
        if reach < best["pairs"]:
            return
        if reach == best["pairs"] and total >= best["cost"]:
            return
        for j in range(m):
            if j in used or (i, j) in forbidden:
                continue
            c = cost[i][j]
            if c >= 1e6:
                continue
            cur[i] = j
            used.add(j)
            rec(i + 1, used, total + c, pairs + 1)
            used.discard(j)
            cur.pop(i, None)
        rec(i + 1, used, total, pairs)     # leave row i unassigned

    rec(0, set(), 0.0, 0)
    return best["map"]


# Picked-slot admission (SDOS-022). Absolute 0.32 was a cliff: a man picked
# on one frame and seen later at another distance scored 0.20–0.31 against
# his own crop and was never swapped. Relative: this slot must prefer the
# face more than any other picked slot, above a low stranger floor.
_PICK_FLOOR = 0.18
_PICK_MARGIN = 0.05
_PICK_SEP = 0.08


def _ref_cos(emb, ref):
    if emb is None or ref is None:
        return -1.0
    try:
        ev = np.asarray(emb, np.float32).reshape(-1)
        rv = np.asarray(ref, np.float32).reshape(-1)
        k = min(ev.size, rv.size)
        if k < 8:
            return -1.0
        return float(np.dot(ev[:k], rv[:k]))
    except Exception:
        return -1.0


class MultiFaceTracker:
    """Occlusion-aware assignment of detections to replacement slots.

    Design notes
    ------------
    * Global optimum, not greedy — see optimal_assignment().
    * Hysteresis: an established slot keeps its detection unless a rival is
      better by `trk_flip_margin` for `trk_flip_frames` consecutive frames.
      Embedding noise on a profile turn lasts 1-3 frames, so it can no longer
      cause a label flip.
    * Crossing lock: while two tracks overlap (a hug), embeddings are frozen
      and label changes are blocked outright. ArcFace embeddings are least
      reliable exactly when two faces are cheek to cheek, so we stop believing
      them and trust motion instead.
    """

    def __init__(self, slots, slot_gender=None):
        self.tracks = {s: TrackState(s) for s in slots}
        # 0 = female, 1 = male, None = unknown (from the replacement photo)
        self.slot_gender = {s: slot_gender.get(s) if slot_gender else None for s in slots}
        # Relative-admission bookkeeping (SDOS-078). _rel_pend[slot] is the last
        # detection that was a candidate for rescue: (bbox, consecutive count,
        # call number). A rescue needs trk_rel_confirm consecutive, spatially
        # consistent detections, so a one-frame look-alike never binds.
        self._rel_pend = {}
        self._call_n = 0
        # v11.2.207: per slot with a Detect picture, how many detector calls in a row it stayed empty while a face nobody
        # else had was there; past trk_ref_stale_calls the picture no longer blocks finding that person by elimination
        self._ref_stale = {}
        self._ref_stale_logged = set()
        self.ref_fallback_n = 0
        # Why faces were NOT bound, per slot. Without this a job that binds
        # nothing for minutes is indistinguishable from one with nobody there.
        self.diag = {s: {"id_reject": 0, "rel_rescued": 0, "rel_waiting": 0,
                         "rel_no_margin": 0, "rel_below_floor": 0}
                     for s in slots}

    def _rel_admit(self, i, j, s, f, sim, sim_all, has_id_all, slots):
        """Admit a face the absolute gate rejected, if it is clearly THIS person.

        Returns True to admit. See _P["trk_rel_floor"] for why this exists.
        Deliberately conservative on every axis - this is the gate that decides
        whether a bystander gets the swap, and a wrong-person swap is worse than
        a missed frame."""
        d = self.diag.setdefault(s, {"id_reject": 0, "rel_rescued": 0,
                                     "rel_waiting": 0, "rel_no_margin": 0,
                                     "rel_below_floor": 0})
        floor = float(_P.get("trk_rel_floor", 0.25))
        margin = float(_P.get("trk_rel_margin", 0.15))
        need = max(1, int(_P.get("trk_rel_confirm", 2)))
        if sim < floor:
            d["rel_below_floor"] += 1
            # NOTE: deliberately does NOT clear _rel_pend. Faces are evaluated
            # one after another within a call, so a different face failing the
            # floor says nothing about the candidate being confirmed - clearing
            # here reset the real candidate's count on every call (the other
            # person is usually evaluated first) and it never reached
            # trk_rel_confirm. Staleness is handled by the consecutive-call
            # check below instead.
            return False
        others = [sim_all[i2][j] for i2 in range(len(slots))
                  if i2 != i and has_id_all[i2]]
        if not others:
            # Nothing to be RELATIVE to - with a single identified slot there is
            # no margin to measure, so keep the absolute rule.
            return False
        if sim - max(others) < margin:
            d["rel_no_margin"] += 1
            return False
        try:
            if self._belongs_to_other(s, f):
                return False
        except Exception:
            pass
        bb = np.asarray(f.bbox, np.float32).reshape(-1)[:4]
        pend = self._rel_pend.get(s)
        if (pend is not None and pend[2] == self._call_n - 1
                and _iou(pend[0], bb) >= 0.25):
            n = pend[1] + 1
        else:
            n = 1
        self._rel_pend[s] = (bb, n, self._call_n)
        if n < need:
            d["rel_waiting"] += 1
            return False
        d["rel_rescued"] += 1
        return True

    # ------------------------------------------------------------------
    def _mark_crossings(self):
        ids = [s for s, t in self.tracks.items() if t.bbox is not None]
        for s in ids:
            self.tracks[s].crossing = False
        for i, a in enumerate(ids):
            for b in ids[i + 1:]:
                ta, tb = self.tracks[a], self.tracks[b]
                if _iou(ta.match_bbox, tb.match_bbox) >= _P["trk_cross_iou"] or \
                   _cdist_norm(ta.match_bbox, tb.match_bbox) < 1.25:
                    ta.crossing = True
                    tb.crossing = True

    def _contact_motion(self):
        """v11.2.176 (SDOS-176): a track in contact with another (crossing) that is missed moves with its PARTNER's velocity when
        the partner was matched on the last call - in a kiss or a hug the two heads move together - and otherwise with its own
        velocity halved on every call. Constant-velocity coasting carried a face missed when the heads met (the approach stops
        dead) on into the partner, or left it behind when the couple moved: the paint drifted, then snapped back."""
        if not bool(_P.get("contact_follow", 1)):
            return
        for s, tr in self.tracks.items():
            tr._contact_vel = None
            if not getattr(tr, "crossing", False) or tr.bbox is None or not tr.established:
                continue
            best = None
            for s2, t2 in self.tracks.items():
                if s2 == s or t2.bbox is None:
                    continue
                d = _cdist_norm(tr.match_bbox, t2.match_bbox)
                if best is None or d < best[0]:
                    best = (d, t2)
            if best is None:
                continue
            o = best[1]
            if int(getattr(o, "missed", 0) or 0) == 0 and o.vel_bbox is not None:
                vk = None
                if o.vel_kps is not None:
                    vk = np.broadcast_to(np.asarray(o.vel_kps, np.float32).reshape(-1, 2).mean(0), (5, 2)).copy()
                tr._contact_vel = (np.asarray(o.vel_bbox, np.float32).copy(), vk)
            elif int(getattr(tr, "missed", 0) or 0) > 0:
                if tr.vel_bbox is not None:
                    tr.vel_bbox = (np.asarray(tr.vel_bbox, np.float32) * 0.5).astype(np.float32)
                if tr.vel_kps is not None:
                    tr.vel_kps = (np.asarray(tr.vel_kps, np.float32) * 0.5).astype(np.float32)

    def _partner_seen(self, s):
        """v11.2.176: is a partner this track is crossing found on this call (missed == 0)?"""
        tr = self.tracks.get(s)
        if tr is None or not getattr(tr, "crossing", False):
            return False
        for s2, t2 in self.tracks.items():
            if s2 != s and t2.bbox is not None and getattr(t2, "crossing", False) and int(getattr(t2, "missed", 0) or 0) == 0:
                return True
        return False

    def _miss_limit(self, s):
        """v11.2.176: how many missed calls a track is carried. In contact with a partner that is seen: contact_carry_max
        (the face is behind or against its partner, which is still there); otherwise trk_max_missed (v11.2.92)."""
        if (bool(_P.get("contact_follow", 1)) and self._partner_seen(s)
                and s not in (getattr(self, "_found_elsewhere", None) or ())):
            return int(_P.get("contact_carry_max", 240) or 240)
        return int(_P["trk_max_missed"])

    def _partner_side_why(self, i, j, s, faces, slots, sim, sim_all, has_id_all):
        """v11.2.176: "ok", or why detection j is not the partly hidden face of slot i in contact (see _partner_side)."""
        try:
            others = [i2 for i2 in range(len(slots)) if i2 != i and has_id_all[i2]]
            if not others:
                return "no_other_id"
            i2 = max(others, key=lambda k: sim_all[k][j])
            if sim_all[i2][j] < sim + 0.10:
                return "margin"
            t2 = self.tracks[slots[i2]]
            r2 = t2.last_hit_bbox if getattr(t2, "last_hit_bbox", None) is not None else t2.match_bbox
            if r2 is None:
                return "no_partner_ref"
            k_own = min(range(len(faces)), key=lambda k: _cdist_norm(r2, faces[k].bbox))
            if k_own == j:
                return "is_partner_det"
            if _cdist_norm(faces[j].bbox, faces[k_own].bbox) >= 1.25:
                return "far_from_partner"
            kj, kk = getattr(faces[j], "kps", None), getattr(faces[k_own], "kps", None)
            if kj is not None and kk is not None and np.size(kj) >= 10 and np.size(kk) >= 10:
                fwk = max(8.0, float(faces[k_own].bbox[2] - faces[k_own].bbox[0]))
                dk = np.asarray(kj, np.float32).reshape(-1, 2).mean(0) - np.asarray(kk, np.float32).reshape(-1, 2).mean(0)
                if float(np.linalg.norm(dk)) < 0.10 * fwk and not _two_boxes(faces[j].bbox, faces[k_own].bbox):
                    return "duplicate_points"
            return "ok"
        except Exception:
            return "error"

    def _partner_side(self, i, j, s, faces, slots, sim, sim_all, has_id_all):
        """v11.2.176 (SDOS-176, from v11.2.146-148): in contact, detection j is the partly hidden face of slot i: in a side-view kiss
        the partner fills half of the crop, so it reads as the partner (measured 0.75-0.88) and as itself 0.05-0.20. It must read as
        the partner by 0.10 or more, not be the partner's own detection, touch it, and not carry the partner's own points."""
        return self._partner_side_why(i, j, s, faces, slots, sim, sim_all, has_id_all) == "ok"

    def _elim_side(self, i, j, s, faces, slots, sim, sim_all, has_id_all):
        """v11.2.176 (SDOS-176): two people, two faces found. Face k is clearly the other person (0.45 or more, 0.10 above this
        face), face j is not them (under 0.40), j is nearer to where THIS person was last seen than k is, and j is a whole face
        (its box at least 0.82 of this person's last width, its points not marked unreliable). Then j is this person, whatever
        its own score (a side view, a turn, motion blur). A face that is only a sliver behind the other is not taken this way
        (box under 0.82, or points marked unreliable while it is against its partner)."""
        try:
            if not bool(_P.get("two_elim", 1)) or len(slots) != 2 or len(faces) != 2 or not all(has_id_all):
                return False
            k = 1 - j; i2 = 1 - i
            if sim_all[i2][k] < 0.45 or sim_all[i2][k] < sim_all[i2][j] + 0.10 or sim_all[i2][j] >= 0.40:
                return False
            tr = self.tracks[s]
            if not tr.established:
                return False
            ref = tr.last_hit_bbox if getattr(tr, "last_hit_bbox", None) is not None else tr.match_bbox
            if ref is None or _cdist_norm(ref, faces[j].bbox) >= _cdist_norm(ref, faces[k].bbox):
                return False
            if bool(getattr(faces[j], "_kps_weak", False)) and getattr(tr, "crossing", False):
                return False      # (points unreliable against its partner: may be a sliver; away from it: a blurred whole face)
            w_last = float(ref[2] - ref[0]); w_now = float(faces[j].bbox[2] - faces[j].bbox[0])
            w_ref = w_last
            if getattr(tr, "crossing", False):
                # against its partner: against the widest this face was identified on its own in the last 90 calls, not
                # only the last frame - a face sliding behind its partner shrinks a little each frame and never fell under
                # 0.82 of the frame before (measured on the hide clip: 317 px -> 244 px, its points guessed ~40 px off)
                _h = [w_ for c_, w_ in (getattr(self, "_sure_w", None) or {}).get(s, []) if self._call_n - c_ <= 90]
                if _h:
                    w_ref = max(w_ref, max(_h))
            if w_ref > 1.0 and w_now < 0.82 * w_ref:
                return False
            return True
        except Exception:
            return False

    def _log_refusal(self, i, j, s, faces, slots, sim, sim_all, has_id_all, xo, touching):
        """v11.2.176 (log only): why a detection was refused - counts per slot, and the first 60 refusals while the faces touch."""
        try:
            if not touching:
                reason = "not_touching"
            elif xo < sim + 0.10:
                reason = "reads_nobody_else"
            else:
                reason = self._partner_side_why(i, j, s, faces, slots, sim, sim_all, has_id_all)
            wc = getattr(self, "why_counts", None)
            if wc is None:
                wc = self.why_counts = {}
            d = wc.setdefault(int(s), {})
            d[reason] = d.get(reason, 0) + 1
            smp = getattr(self, "why_sample", None)
            if smp is None:
                smp = self.why_sample = []
            if touching and len(smp) < 60:
                smp.append((int(getattr(self, "_call_n", 0)), int(s), int(j), reason, round(float(sim), 2), round(float(xo), 2)))
        except Exception:
            pass

    def _identity(self, face, track, ref):
        emb = getattr(face, "normed_embedding", None)
        if emb is None:
            return -1.0
        emb = np.asarray(emb, np.float32)
        lock = getattr(track, "id_lock", None) if track is not None else None
        best = None
        if lock is not None:
            best = float(np.dot(emb, lock))
        elif track is not None and track.emb is not None:
            best = float(np.dot(emb, track.emb))
        # The Detect-frame reference is the identity the USER chose. It used to
        # be ignored the moment the slot locked onto its first bound frame -
        # a single frame, at whatever pose and light that happened to be - so
        # the stored lock silently outranked the one reference known to be a
        # good, deliberate picture of this person. Keep it as a second
        # prototype: the face matches if it matches EITHER.
        if ref is not None:
            try:
                r = float(_ref_cos(emb, ref))
            except Exception:
                r = float(np.dot(emb, np.asarray(ref, np.float32)))
            best = r if best is None else max(best, r)
        return -1.0 if best is None else best

    def _belongs_to_other(self, slot, face):
        """True if this detection sits closer to a different established track.

        This is the flip detector. It compares the candidate against every
        track's one-step prediction, so it catches the case where slot #0 is
        about to take the detection that is plainly slot #1's face — the exact
        failure that shows up as the two faces trading places mid-hug.
        """
        tr = self.tracks[slot]
        own_box = tr.match_bbox
        if own_box is None:
            return False
        own = _iou(own_box, face.bbox)
        own_d = _cdist_norm(own_box, face.bbox)
        for s2, t2 in self.tracks.items():
            if s2 == slot or not t2.established or t2.match_bbox is None:
                continue
            o = _iou(t2.match_bbox, face.bbox)
            od = _cdist_norm(t2.match_bbox, face.bbox)
            if o > own + 0.12 or (od + 0.20 < own_d):
                return True
        return False

    # ------------------------------------------------------------------
    def mark_cut(self):
        """A hard cut happened. Reset every track's geometry, keep identities."""
        n = 0
        self._rel_pend.clear()
        for tr in self.tracks.values():
            if tr is None:
                continue
            try:
                tr.reset_for_cut()
                n += 1
            except Exception as e:
                log.debug("cut reset failed on slot %s: %s", getattr(tr, "slot", "?"), e)
        return n

    def assign(self, faces, refs, dt_frames: float = 1.0):
        """faces: list of detections. refs: {slot: reference embedding}.

        Returns {slot: face} for slots that got a detection this frame. Slots
        that missed are advanced by prediction, and the caller can still swap
        them via TrackState.predicted_face().
        """
        self._mark_crossings()
        self._contact_motion()           # v11.2.176
        self._found_elsewhere = set()    # v11.2.176: slots whose person is seen elsewhere this call (see the end of assign)
        slots = sorted(self.tracks.keys())
        if faces is None or (hasattr(faces, "__len__") and len(faces) == 0):
            for t in self.tracks.values():
                t.predict(dt_frames)
            self._preserve_identity_on_expire()
            return {}
        faces = list(faces)

        n, m = len(slots), len(faces)

        def _cos_emb(a, b):
            if a is None or b is None:
                return -1.0
            va = np.asarray(a, np.float32).reshape(-1)
            vb = np.asarray(b, np.float32).reshape(-1)
            k = min(va.size, vb.size)
            if k < 8:
                return -1.0
            return float(np.dot(va[:k], vb[:k]))

        # Duplicate woman-box locked two slots. Free the clone so the man
        # who joins later still has a virgin slot.
        for i, s in enumerate(slots):
            e1 = getattr(self.tracks[s], "id_lock", None)
            if e1 is None:
                e1 = self.tracks[s].emb
            if e1 is None:
                continue
            ref1 = refs.get(s) if refs else None
            for i2 in range(i + 1, n):
                s2 = slots[i2]
                e2 = getattr(self.tracks[s2], "id_lock", None)
                if e2 is None:
                    e2 = self.tracks[s2].emb
                if e2 is None:
                    continue
                if _cos_emb(e1, e2) < 0.38:
                    continue
                ref2 = refs.get(s2) if refs else None
                keep = s
                if ref1 is not None or ref2 is not None:
                    if _cos_emb(ref2, e2) > _cos_emb(ref1, e1):
                        keep = s2
                drop_s = s2 if keep == s else s
                trd = self.tracks[drop_s]
                trd.emb = None
                trd.id_lock = None
                trd.hits = 0

        # A slot must not keep a lock that belongs to another slot's Detect ref.
        for i, s in enumerate(slots):
            ref = refs.get(s) if refs else None
            lock = getattr(self.tracks[s], "id_lock", None)
            if lock is None:
                lock = self.tracks[s].emb
            if ref is None or lock is None:
                continue
            own = _cos_emb(lock, ref)
            other = -1.0
            for s2 in slots:
                if s2 == s:
                    continue
                r2 = refs.get(s2) if refs else None
                if r2 is not None:
                    other = max(other, _cos_emb(lock, r2))
            # v11.2.208: a picture the fallback gave up on matches nobody, so "own" is noise around 0 and the lock was reset
            # whenever the other picture read 0.04 higher - also noise. Then only a real likeness to the other picture counts.
            if s in self._ref_stale_logged and other < float(_P.get("trk_ref_stale_other", 0.30)) + 0.05:
                continue
            if other > own + 0.04:
                trd = self.tracks[s]
                trd.emb = None
                trd.id_lock = None
                trd.hits = 0
                logging.info("slot %s lock belonged to another ref (own=%.2f other=%.2f) — reset",
                             s, own, other)

        cost = [[1e9] * m for _ in range(n)]
        sim_tab = [[-1.0] * m for _ in range(n)]
        ref_sim = [[-1.0] * m for _ in range(n)]
        for i, s_ in enumerate(slots):
            _r = refs.get(s_) if refs else None
            if _r is None:
                continue
            for j, f in enumerate(faces):
                ref_sim[i][j] = _ref_cos(getattr(f, "normed_embedding", None), _r)

        self._call_n += 1
        # (slot index, face index) pairs the relative-admission rule let through
        # the absolute gate. The post-pairing check further down has ITS OWN
        # absolute floor (0.32) and has to be told about these, or it quietly
        # throws away exactly the faces the rescue just admitted.
        rescued = set()
        contact_ok = set()   # v11.2.176: (slot index, face index) kept in contact by where it touches its partner, or by elimination
        # Every slot's similarity to every face, computed up front. The main
        # loop below visits slot 0 first, when slot 1's row has not been filled
        # in yet, and the relative-admission rule needs all of them.
        sim_all = [[self._identity(f, self.tracks[s_], refs.get(s_) if refs else None)
                    for f in faces] for s_ in slots]
        has_id_all = [
            (getattr(self.tracks[s_], "id_lock", None) is not None
             or self.tracks[s_].emb is not None
             or (refs.get(s_) if refs else None) is not None)
            for s_ in slots]

        for i, s in enumerate(slots):
            tr = self.tracks[s]
            pred = tr.match_bbox
            for j, f in enumerate(faces):
                sim = self._identity(f, tr, refs.get(s))
                sim_tab[i][j] = sim
                iou = _iou(pred, f.bbox) if pred is not None else 0.0
                dist = _cdist_norm(pred, f.bbox) if pred is not None else 9.0
                spatial = max(iou, max(0.0, 1.0 - dist * 0.7))

                gate = _P["trk_gate_hold"] if tr.established else _P["trk_gate_new"]
                if tr.crossing and tr.established:
                    gate = -1.0          # trust motion, not embeddings
                has_id = (getattr(tr, "id_lock", None) is not None) or (tr.emb is not None)
                long_gap = int(getattr(tr, "missed", 0) or 0) >= 8 or bool(getattr(tr, "_paste_frozen", False))
                # v11.2.176 (SDOS-176): is this face touching another one, and does its crop read as another tracked person?
                # Touching: boxes overlapping, or centres within 0.55 face widths, or - once two known faces are crossing -
                # the whole contact (the 0.55 line alone switched the decision on and off from frame to frame in a kiss).
                touching = False
                for f2 in faces:
                    if f2 is f:
                        continue
                    if _iou(f.bbox, f2.bbox) > 0.02 or _cdist_norm(f.bbox, f2.bbox) < 0.55:
                        touching = True
                        break
                _cf = bool(_P.get("contact_follow", 1))
                if not touching and _cf and tr.established and tr.crossing:
                    touching = True
                _xo = max([sim_all[i2][j] for i2 in range(len(slots)) if i2 != i and has_id_all[i2]] or [-1.0])
                _reads_other = _cf and _xo >= sim + 0.10
                # Gender is not a reason to drop a face. InsightFace often
                # calls the man a woman, and the woman a man for a few frames.
                # The Detect-frame photo is the identity. A wrong gender tag
                # must not skip him or flash her back to the original.
                if has_id:
                    _abs_ok = True
                    if _reads_other and touching and self._partner_side(i, j, s, faces, slots, sim, sim_all, has_id_all):
                        contact_ok.add((i, j))               # v11.2.176: the partly hidden face of a kiss (reads as the partner)
                        self.partner_side_n = getattr(self, "partner_side_n", 0) + 1
                    elif self._elim_side(i, j, s, faces, slots, sim, sim_all, has_id_all):
                        contact_ok.add((i, j))               # v11.2.176: two people, the other one clearly the other person
                        if (sim < 0.40) if long_gap else (sim < 0.38 and not (spatial >= 0.55 and sim >= 0.22)):
                            self.elim_n = getattr(self, "elim_n", 0) + 1     # (log: only faces the identity gate refused)
                    elif long_gap:
                        if sim < 0.40:
                            _abs_ok = False
                    elif sim < 0.38 and not (spatial >= 0.55 and sim >= 0.22):
                        _abs_ok = False

                    if not _abs_ok:
                        # The absolute wall rejected it. Before dropping a face
                        # that may simply be this person at a different pose or
                        # light, ask whether it is clearly THEM relative to the
                        # other people - see _rel_admit.
                        if not self._rel_admit(i, j, s, f, sim, sim_all,
                                               has_id_all, slots):
                            self.diag[s]["id_reject"] += 1
                            self._log_refusal(i, j, s, faces, slots, sim, sim_all, has_id_all, _xo, touching)
                            continue
                        rescued.add((i, j))
                else:
                    ref = refs.get(s) if refs else None
                    if ref is not None:
                        rs = ref_sim[i][j]
                        if rs < _PICK_FLOOR:
                            continue
                        best_other = -1.0
                        for i2 in range(n):
                            if i2 != i:
                                best_other = max(best_other, ref_sim[i2][j])
                        if best_other > rs:
                            continue
                    else:
                        skip = False
                        for s2 in slots:
                            if s2 == s:
                                continue
                            le = getattr(self.tracks[s2], "id_lock", None)
                            if le is None:
                                le = self.tracks[s2].emb
                            if le is None:
                                continue
                            if _cos_emb(getattr(f, "normed_embedding", None), le) >= 0.45:
                                skip = True
                                break
                        if skip:
                            continue

                w_id, w_iou, w_d = _P["trk_w_id"], _P["trk_w_iou"], _P["trk_w_dist"]
                if tr.crossing and tr.established:
                    w_id, w_iou, w_d = 0.18, 0.55, 0.27
                if not has_id:
                    w_id, w_iou, w_d = 0.10, 0.55, 0.35
                cost[i][j] = (w_id * (1.0 - max(sim, -0.2)) +
                              w_iou * (1.0 - iou) +
                              w_d * min(1.0, dist / 3.0))

        pairing = optimal_assignment(cost)

        # Virgin slots only (no gallery lock yet). Never L-R rebind a slot
        # that already knows its person — that is how F1 leaving caused
        # Male/F3 to steal slot 0, then F1 coming back got the male paste.
        unresolved = [
            i for i, s in enumerate(slots)
            if pairing.get(i) is None
            and getattr(self.tracks[s], "id_lock", None) is None
            and self.tracks[s].emb is None
        ]
        if unresolved:
            claimed = set(pairing.values())
            leftovers = [j for j in range(m) if j not in claimed]
            # A leftover that still matches a locked slot is that person
            # (profile / return) — do not give them to a virgin slot.
            def _min_lock_sim(j):
                best = 1.0
                any_lock = False
                for i2, s2 in enumerate(slots):
                    if getattr(self.tracks[s2], "id_lock", None) is None and self.tracks[s2].emb is None:
                        continue
                    any_lock = True
                    best = min(best, sim_tab[i2][j])
                if not any_lock:
                    return 0.0
                return best
            leftovers = [j for j in leftovers if _min_lock_sim(j) < 0.45]
            leftovers.sort(key=lambda j: (_min_lock_sim(j), float(np.asarray(faces[j].bbox).reshape(-1)[0])))
            used_j = set()
            for i in unresolved:
                pick = None
                ref = refs.get(slots[i]) if refs else None
                if ref is not None:
                    best = _PICK_FLOOR
                    for j in leftovers:
                        if j in used_j:
                            continue
                        sim = ref_sim[i][j]
                        if sim <= best:
                            continue
                        best_other = -1.0
                        for i2 in range(n):
                            if i2 != i:
                                best_other = max(best_other, ref_sim[i2][j])
                        if best_other > sim:
                            continue
                        best, pick = sim, j
                if pick is None and ref is None:
                    for j in leftovers:
                        if j in used_j:
                            continue
                        emb = getattr(faces[j], "normed_embedding", None)
                        if emb is None:
                            continue
                        clone = False
                        for s2 in slots:
                            le = getattr(self.tracks[s2], "id_lock", None)
                            if le is None:
                                le = self.tracks[s2].emb
                            if le is None:
                                continue
                            if _cos_emb(emb, le) >= 0.45:
                                clone = True
                                break
                        if not clone:
                            pick = j
                            break
                if pick is not None:
                    pairing[i] = pick
                    used_j.add(pick)

        # Same person must not fill two slots (two boxes on the woman at start).
        taken = [i for i in range(n) if pairing.get(i) is not None]
        drop = set()
        for a in range(len(taken)):
            for b in range(a + 1, len(taken)):
                i, i2 = taken[a], taken[b]
                j, j2 = pairing[i], pairing[i2]
                e1 = getattr(faces[j], "normed_embedding", None)
                e2 = getattr(faces[j2], "normed_embedding", None)
                if e1 is None or e2 is None:
                    continue
                a1 = np.asarray(e1, np.float32).reshape(-1)
                a2 = np.asarray(e2, np.float32).reshape(-1)
                k = min(a1.size, a2.size)
                if k < 8:
                    continue
                if float(np.dot(a1[:k], a2[:k])) < 0.50:
                    continue
                # v11.2.176: not two boxes on one face but two people in contact - a side-view face has its partner in half its
                # crop and reads as them. Kept when one of the pairs passed the contact test and the boxes are two separate faces.
                if ((i, j) in contact_ok or (i2, j2) in contact_ok) and _iou(faces[j].bbox, faces[j2].bbox) < 0.40:
                    continue
                t1, t2 = self.tracks[slots[i]], self.tracks[slots[i2]]
                r1 = refs.get(slots[i]) if refs else None
                r2 = refs.get(slots[i2]) if refs else None

                def _rsim(r, e):
                    if r is None or e is None:
                        return -1.0
                    rv = np.asarray(r, np.float32).reshape(-1)
                    ev = np.asarray(e, np.float32).reshape(-1)
                    kk = min(rv.size, ev.size)
                    if kk < 8:
                        return -1.0
                    return float(np.dot(ev[:kk], rv[:kk]))

                keep_i = None
                if r1 is not None or r2 is not None:
                    s1 = max(_rsim(r1, e1), _rsim(r1, e2))
                    s2 = max(_rsim(r2, e1), _rsim(r2, e2))
                    if s1 != s2:
                        keep_i = i if s1 > s2 else i2
                if keep_i is None:
                    keep_i = i if (t1.emb is not None or getattr(t1, "id_lock", None) is not None) else i2
                    if t2.emb is not None and t1.emb is None:
                        keep_i = i2
                drop.add(i2 if keep_i == i else i)
        for i in drop:
            pairing.pop(i, None)

        # LATE JOIN: an empty slot takes a face that is clearly NOT anyone
        # already locked. This is the woman-first / man-later path and does
        # not depend on Detect-frame refs or the 0.32 cliff.
        claimed = set(pairing.values())
        empty_i = [
            i for i, s in enumerate(slots)
            if pairing.get(i) is None
            and getattr(self.tracks[s], "id_lock", None) is None
            and self.tracks[s].emb is None
        ]
        if empty_i:
            locked_e = []
            for s in slots:
                e = getattr(self.tracks[s], "id_lock", None)
                if e is None:
                    e = self.tracks[s].emb
                if e is not None:
                    locked_e.append(e)
            for j in range(m):
                if not empty_i:
                    break
                if j in claimed:
                    continue
                emb = getattr(faces[j], "normed_embedding", None)
                if emb is None:
                    continue
                mx = max((_cos_emb(emb, e) for e in locked_e), default=-1.0)
                if locked_e and mx >= 0.42:
                    continue
                pick_i = None
                best_rs = -1.0
                any_ref = False
                for i in list(empty_i):
                    r = refs.get(slots[i]) if refs else None
                    if r is None:
                        continue
                    any_ref = True
                    rs = ref_sim[i][j]
                    if rs < _PICK_FLOOR:
                        continue
                    other = max((ref_sim[i2][j] for i2 in range(n) if i2 != i), default=-1.0)
                    if other > rs:
                        continue
                    if rs > best_rs:
                        best_rs, pick_i = rs, i
                # v11.2.207 (SDOS-207): a Detect picture that has matched no face for trk_ref_stale_calls calls in a row,
                # while a face nobody else has was there, stops blocking: that slot is filled by elimination (gender
                # first), as it would be without a picture. The picture may be of another moment of the video (a split
                # part, another scene); with it the person stayed original until some frame happened to match it.
                _stale_n = int(_P.get("trk_ref_stale_calls", 0) or 0)
                stale_i = [i for i in empty_i if refs and refs.get(slots[i]) is not None
                           and _stale_n > 0 and (self._ref_stale.get(slots[i], 0) >= _stale_n
                                                 or slots[i] in self._ref_stale_logged)]   # given up once: at once
                # only with no more faces on screen than people to swap: with bystanders around, the picture must decide
                if pick_i is None and any_ref and stale_i and m <= n:
                    # not a face that one of the OTHER pictures claims, nor one a locked person looks like
                    _claimed_by_ref = max((ref_sim[i2][j] for i2 in range(n)
                                           if i2 not in stale_i and refs.get(slots[i2]) is not None), default=-1.0)
                    if _claimed_by_ref < float(_P.get("trk_ref_stale_other", 0.30)) and mx < 0.30:
                        got_g = _det_gender(faces[j])
                        # gender first, as the no-picture path: a slot whose replacement matches the face's gender; when
                        # none does, any of them (a wrong gender tag must not leave the person original)
                        pool = [i for i in stale_i if got_g in (0, 1) and self.slot_gender.get(slots[i]) == got_g] or list(stale_i)
                        if pool:
                            pick_i = pool[0]
                            self.ref_fallback_n += 1
                            try:
                                faces[j]._ref_fallback = True      # the job paints this person from this frame on, not before
                            except Exception:
                                pass
                            if slots[pick_i] not in self._ref_stale_logged:
                                self._ref_stale_logged.add(slots[pick_i])
                                logging.info("person %s: the Detect picture matched no face for %d detector calls - found "
                                             "by elimination instead (ref_sim=%.2f)", slots[pick_i] + 1 if isinstance(
                                                 slots[pick_i], int) else slots[pick_i], self._ref_stale.get(slots[pick_i], 0),
                                             ref_sim[pick_i][j])
                if pick_i is None and not any_ref:
                    got_g = _det_gender(faces[j])
                    pool = list(empty_i)
                    if len(self.tracks) >= 2 and got_g in (0, 1):
                        matched = [
                            i for i in empty_i
                            if self.slot_gender.get(slots[i]) == got_g
                        ]
                        wrong = [
                            i for i in empty_i
                            if self.slot_gender.get(slots[i]) in (0, 1)
                            and self.slot_gender.get(slots[i]) != got_g
                        ]
                        if matched:
                            pool = matched
                        # Do not refuse the face when every empty slot
                        # disagrees on gender. A wrong tag was leaving the
                        # man original for the whole clip.
                        if not pool:
                            pool = list(empty_i)
                    if pool:
                        pick_i = pool[0]
                if pick_i is None:
                    continue
                empty_i.remove(pick_i)
                pairing[pick_i] = j
                claimed.add(j)
                logging.info("late-join slot %s ← face (ref_sim=%.2f locked=%.2f)",
                             slots[pick_i], best_rs, mx)

        # v11.2.207: staleness of the Detect pictures (see above)
        if refs:
            _claimed_now = set(pairing.values())
            _free_face = any(j not in _claimed_now for j in range(m))
            for i, s in enumerate(slots):
                if refs.get(s) is None:
                    continue
                _locked = getattr(self.tracks[s], "id_lock", None) is not None or self.tracks[s].emb is not None
                if pairing.get(i) is not None or _locked:
                    self._ref_stale[s] = 0
                elif _free_face:
                    self._ref_stale[s] = self._ref_stale.get(s, 0) + 1

        # Re-entry steal: if a detection is clearly a locked slot's person,
        # give it back even if Hungarian/bootstrap parked it elsewhere.
        for i, s in enumerate(slots):
            lock = getattr(self.tracks[s], "id_lock", None)
            if lock is None:
                lock = self.tracks[s].emb
            if lock is None:
                continue
            best_j, best_sim = None, 0.40
            for j in range(m):
                if sim_tab[i][j] > best_sim:
                    best_sim, best_j = sim_tab[i][j], j
            if best_j is None:
                continue
            owner = next((i2 for i2 in range(n) if pairing.get(i2) == best_j), None)
            if owner is None:
                pairing[i] = best_j
            elif owner != i and best_sim >= sim_tab[owner][best_j] + 0.08:
                pairing.pop(owner, None)
                pairing[i] = best_j

        # Un-cross two established slots if swapping them raises identity
        # scores. This is the male↔female paste: Hungarian + left-to-right
        # bootstrap can lock the wrong pair, then hysteresis keeps it.
        established = [i for i, s in enumerate(slots)
                       if self.tracks[s].emb is not None or getattr(self.tracks[s], "id_lock", None) is not None]
        if len(established) >= 2:
            for a in range(len(established)):
                for b in range(a + 1, len(established)):
                    i, i2 = established[a], established[b]
                    j, j2 = pairing.get(i), pairing.get(i2)
                    if j is None or j2 is None:
                        continue
                    def _rs(ii, jj):
                        try:
                            return float(ref_sim[ii][jj])
                        except Exception:
                            return -1.0
                    cur = _rs(i, j) + _rs(i2, j2)
                    swp = _rs(i, j2) + _rs(i2, j)
                    # Swap only when the Detect-frame picks say the faces
                    # are crossed. A one-frame gender flicker must not
                    # trade them or drop either face to the original.
                    if swp > cur + 0.08:
                        pairing[i], pairing[i2] = j2, j

        # ---- hysteresis: veto flips that are not sustained ----------------
        # "Changed" is decided GEOMETRICALLY, never by python object identity:
        # detections are fresh objects every frame, so an identity test would
        # fire on literally every frame and permanently stall the tracker.
        result = {}
        for i, s in enumerate(slots):
            tr = self.tracks[s]
            j = pairing.get(i)
            if j is None:
                tr.predict(dt_frames)
                tr.flip_votes = max(0, tr.flip_votes - 1)
                continue
            f = faces[j]
            changed = self._belongs_to_other(s, f) and (i, j) not in contact_ok    # v11.2.176: a contact pair is not a flip

            if changed and tr.established:
                # The class docstring specifies that during a crossing "label
                # changes are blocked outright" - because this is exactly the
                # window where ArcFace embeddings are least reliable, so there
                # is no trustworthy basis for relabelling anyone. The previous
                # implementation only DELAYED the flip by trk_flip_frames (5)
                # frames: flip_votes ticked up every crossing frame and, once
                # it hit 5, the relabel went through anyway. Any real crossing
                # - two people walking past each other, a hug, one turning
                # across the other - lasts well over 5 frames, so in practice
                # the lock never held and the labels traded places mid-
                # crossing. Block outright while crossing and carry the
                # existing binding on motion, as designed; trk_max_missed
                # (24 frames) remains the safety valve if a "crossing" state
                # somehow persists, and it now preserves the learned
                # embedding so the track can re-acquire the RIGHT person by
                # identity afterwards instead of guessing.
                if tr.crossing:
                    tr.predict(dt_frames)
                    continue
                if sim_tab[i][j] < _P["trk_flip_margin"] + 0.30:
                    tr.flip_votes += 1
                    if tr.flip_votes < _P["trk_flip_frames"]:
                        # Keep the previous binding for now; geometry carries it.
                        tr.predict(dt_frames)
                        continue
                tr.flip_votes = 0
            else:
                tr.flip_votes = max(0, tr.flip_votes - 1)

            # Never poison the long-term identity with a profile/crossing frame
            # or with a *different person* after a gap (the 3rd-character steal).
            lock_sim = sim_tab[i][j]
            good = lock_sim >= 0.38 and not tr.crossing
            if getattr(tr, "id_lock", None) is None and tr.emb is None and not tr.crossing:
                good = True
            elif (getattr(tr, "id_lock", None) is not None and lock_sim < 0.32
                    and (i, j) not in rescued and (i, j) not in contact_ok):
                # Below the absolute floor. This used to be an unconditional
                # "not this slot's person". The gate above admits faces down to
                # 0.22 when they sit where the track expects its person (the
                # spatial rescue) and this line then discarded them, so that
                # rescue never worked - but it also happened to be the only
                # thing stopping a bystander standing in the tracked person's
                # spot at 0.22-0.32 from taking the slot. Removing the line
                # outright was measured to raise the bystander false-bind rate
                # from 0.4% to 2.0% (and 0% to 43% for a sustained look-alike).
                # So replace the blind floor with the real question - is this
                # clearly THEM relative to the other people, seen consistently -
                # which is exactly what _rel_admit asks.
                if not self._rel_admit(i, j, s, f, lock_sim, sim_all,
                                       has_id_all, slots):
                    self.diag[s]["post_reject"] = self.diag[s].get("post_reject", 0) + 1
                    tr.predict(dt_frames)
                    continue
                self.diag[s]["rel_rescued_post"] = self.diag[s].get("rel_rescued_post", 0) + 1

            # v11.2.0: fail-closed if landmarks missing (core usually pre-filters
            # with _kps_reliable; this is defense-in-depth for HairGate confirm).
            _kps = getattr(f, "kps", None)
            _kps_ok = _kps is not None and len(_kps) >= 5
            tr.update(f, update_embedding=good, dt_frames=dt_frames, kps_ok=_kps_ok)
            if changed:
                tr.reset_appearance()
            if lock_sim >= 0.38:
                # v11.2.176: the widths of this face when it was identified on its own, over the last 90 calls (the sliver
                # guard of _elim_side)
                try:
                    _sw = getattr(self, "_sure_w", None)
                    if _sw is None:
                        _sw = self._sure_w = {}
                    _h = [e for e in _sw.get(s, []) if self._call_n - e[0] <= 90]
                    _h.append((self._call_n, float(f.bbox[2] - f.bbox[0])))
                    _sw[s] = _h[-120:]
                except Exception:
                    pass
            result[s] = f
            # This slot is now TRACKING this face. The confirmation count in
            # _rel_admit exists to vet a NEW acquisition; a face the slot has
            # just been bound to, still at the same place, must not have to
            # re-earn trust each time its similarity wobbles across a
            # threshold. Without this, a face hovering around 0.32 was bound on
            # the frames above it, sent through the rescue on the frames below
            # it, and the frames above never advanced the rescue's
            # "consecutive" chain - measured recall 60-75% at a similarity of
            # 0.33 against ~99% once the chain is carried.
            try:
                self._rel_pend[s] = (np.asarray(f.bbox, np.float32).reshape(-1)[:4],
                                     max(1, int(_P.get("trk_rel_confirm", 2))),
                                     self._call_n)
            except Exception:
                pass

        # v11.2.176: the long carry in contact (contact_carry_max) is for a face hidden against its partner. When this person's
        # own face is found ELSEWHERE in the frame (it walked out from behind the other: a crossing), the carry ends at the
        # v11.2.92 limit, so the slot is re-acquired by identity as in v11.2.92 instead of staying glued to the partner.
        try:
            taken = {id(f_) for f_ in result.values()}
            for i, s in enumerate(slots):
                if s in result or not has_id_all[i] or self.tracks[s].missed <= int(_P["trk_max_missed"]):
                    continue
                for j, f_ in enumerate(faces):
                    if id(f_) in taken:
                        continue
                    o_ = max([sim_all[i2][j] for i2 in range(len(slots)) if i2 != i and has_id_all[i2]] or [-1.0])
                    if sim_all[i][j] >= 0.45 and sim_all[i][j] >= o_ + 0.10:
                        self._found_elsewhere.add(s)
                        break
        except Exception:
            pass
        self._preserve_identity_on_expire()
        return result

    def _preserve_identity_on_expire(self):
        """Drop coasted geometry after a long miss; keep the gallery lock.

        Geometry must die or the next person who walks into that region
        inherits the slot. Identity must live or the original person cannot
        reclaim the slot on return.
        """
        for s in list(self.tracks.keys()):
            tr = self.tracks[s]
            if tr.missed > self._miss_limit(s):           # v11.2.176: longer while in contact with a partner that is seen
                keep_emb = tr.emb
                keep_lock = getattr(tr, "id_lock", None)
                nw = TrackState(s)
                nw.emb = keep_emb
                nw.id_lock = keep_lock
                if keep_lock is not None or keep_emb is not None:
                    nw.hits = max(int(_P["trk_lock_hits"]), 1)
                self.tracks[s] = nw

    def bind(self, slot, face, update_embedding=True, dt_frames: float = 1.0,
             kps_ok: bool = True):
        """Attach a detection to a slot without running association.

        Used by the single-face path, which has its own well-tested pairing
        logic (startup identity lock, reference embeddings). We still want the
        track's temporal memory — mask EMA, colour EMA, velocity for carry —
        so the appearance of a single-face job is stabilised the same way.
        """
        tr = self.tracks.get(slot)
        if tr is None:
            tr = self.tracks[slot] = TrackState(slot)
        tr.crossing = False
        tr.update(face, update_embedding=update_embedding, dt_frames=dt_frames,
                  kps_ok=kps_ok)
        return tr

    # ------------------------------------------------------------------
    def carry(self, slots=None):
        """Predicted faces for slots with no detection this frame.

        This is what replaces "fall back to the original frame". A predicted
        face still has valid 5-point kps, which is all inswapper needs, so the
        swap keeps running through detector gaps instead of blinking.
        """
        out = {}
        for s, tr in self.tracks.items():
            if slots is not None and s not in slots:
                continue
            # NOTE: this used to also require ``tr.missed != 0``. That made
            # carry() return NOTHING on the single-face path, where a failed
            # pairing never advances the track - so the one code path that
            # exists to keep the swap alive through a bad frame was unreachable
            # exactly when it was called for, and the frame fell back to the
            # real face. A track with missed == 0 has CURRENT geometry, which
            # is the best case for carrying, not a reason to refuse.
            if not tr.established:
                continue
            if tr.missed > self._miss_limit(s):           # v11.2.176: longer while in contact with a partner that is seen
                continue
            # v11.1.9: frozen after leaving frame — do not offer for paste.
            if getattr(tr, "_paste_frozen", False):
                continue
            pf = tr.predicted_face()
            if pf is not None:
                out[s] = pf
        return out

# ════════════════════════════════════════════════════════════════════════════════
# PHASE 1: OUT-OF-FRAME BOUNDARY VALIDATION (Non-intrusive Addition)
# ════════════════════════════════════════════════════════════════════════════════
# This section adds boundary confidence validation WITHOUT modifying existing code.
# It works with the existing TrackState, PredictedFace, and swap logic.

from enum import Enum

class TrackingState(Enum):
    """State machine for face tracking at frame boundaries."""
    ACTIVE = "active"
    EDGE_RISK = "edge_risk"
    LOST = "lost"
    SLEEPING = "sleeping"


class FaceTrackState:
    """Per-face state tracking for boundary validation."""
    __slots__ = ["track_id", "state", "confidence_history", "bbox_history", "frames_in_state"]
    
    def __init__(self, track_id: str):
        self.track_id = track_id
        self.state = TrackingState.ACTIVE
        self.confidence_history: list = []
        self.bbox_history: list = []
        self.frames_in_state = 0
    
    def update_state(self, confidence: float, bbox: tuple):
        """Update state based on sustained confidence levels."""
        self.confidence_history.append(confidence)
        if len(self.confidence_history) > 30:
            self.confidence_history.pop(0)
        self.bbox_history.append(bbox)
        if len(self.bbox_history) > 5:
            self.bbox_history.pop(0)
        self.frames_in_state += 1
        
        # Hysteresis: require 3+ frames of sustained confidence for state change
        if len(self.confidence_history) >= 3:
            recent_conf = np.mean(self.confidence_history[-3:])
            threshold_high = 0.70  # Transition to EDGE_RISK
            threshold_low = 0.80   # Recover to ACTIVE
            
            if self.state == TrackingState.ACTIVE and recent_conf < threshold_high:
                self.state = TrackingState.EDGE_RISK
                self.frames_in_state = 0
            elif self.state == TrackingState.EDGE_RISK and recent_conf > threshold_low:
                self.state = TrackingState.ACTIVE
                self.frames_in_state = 0


def validate_detection_confidence(bbox, frame_shape, landmarks=None):
    """
    Calculate confidence penalty for faces at frame edges.
    Returns confidence multiplier [0.0, 1.0].
    """
    if bbox is None or frame_shape is None:
        return 1.0
    
    H, W = frame_shape[:2]
    if H <= 0 or W <= 0:
        return 1.0
    
    x1, y1, x2, y2 = bbox
    margin_edge = max(1, int(0.05 * min(W, H)))    # 5% margin
    margin_near = max(1, int(0.12 * min(W, H)))    # 12% margin
    
    penalty = 1.0
    
    # Horizontal edges
    if x1 < margin_edge or x2 > (W - margin_edge):
        penalty *= 0.50
    elif x1 < margin_near or x2 > (W - margin_near):
        penalty *= 0.60
    
    # Vertical edges
    if y1 < margin_edge or y2 > (H - margin_edge):
        penalty *= 0.50
    elif y1 < margin_near or y2 > (H - margin_near):
        penalty *= 0.60
    
    return float(np.clip(penalty, 0.0, 1.0))

