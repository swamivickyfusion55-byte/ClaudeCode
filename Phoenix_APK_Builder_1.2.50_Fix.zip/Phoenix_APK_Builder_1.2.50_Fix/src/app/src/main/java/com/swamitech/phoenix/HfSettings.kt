package com.swamitech.phoenix

data class HfSettings(
    val spaceUrl: String = "",
    val endpoint: String = "",
    val modelRepo: String = "",
    val modelRevision: String = "main"
)

data class PhoenixOptions(
    val durationSec: Int = 360,
    val fps: Int = 30,
    val resolution: String = "1080p (Full HD)",
    val quality: String = "Ultra",
    val enhancer: String = "GPEN + Cinematic",
    val swapEvery: String = "1",
    val detectEvery: String = "1",
    val detectInterval: Int = 4,
    val faceMode: String = "2 faces",
    val enhanceScope: String = "All faces",
    val deviceMode: String = "CPU only",
    val primarySlot: String = "Auto",
    val smoothMotion: String = "Off",
    // 1.2.30: lower-belly clear skin (Space v11.2.110+): every tattoo or mark from below the navel to the waist line removed, skin evened
    val bellyClear: Boolean = false,
    // 1.2.31: the band's length and breadth (Space v11.2.111+), x0.5 - x1.5
    val bellyLength: Float = 1f,
    val bellyWidth: Float = 1f,
    // 1.2.39: shift the band along the body. Positive is up, toward the navel. -0.12 to 0.12.
    val bellyShift: Float = 0f,
    // 1.2.42: the eight corners, in body coordinates, after Preview belly. The job uses this shape.
    val bellyNorm: String = "",
    val trimStart: Int = 0,
    val trimEnd: Int = 100,
    val password: String = "",
    val splitParts: String = "5 parts",
    val splitSharedSettings: Boolean = true,
    val splitFaceMode1: String = "2 faces",
    val splitFaceMode2: String = "2 faces",
    val splitFaceMode3: String = "2 faces",
    val splitFaceMode4: String = "2 faces",
    val splitFaceMode5: String = "2 faces",
    val splitFaceMode6: String = "2 faces",
    val splitFaceMode7: String = "2 faces",
    val splitFaceMode8: String = "2 faces",
    val splitFaceMode9: String = "2 faces",
    val splitFaceMode10: String = "2 faces",
    val autoMergeSplits: Boolean = true
)
