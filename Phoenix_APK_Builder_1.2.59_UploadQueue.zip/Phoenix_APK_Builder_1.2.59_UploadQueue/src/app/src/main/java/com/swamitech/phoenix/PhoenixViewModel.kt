package com.swamitech.phoenix

import android.app.ActivityManager
import android.app.Application
import android.app.ApplicationExitInfo
import android.content.ContentValues
import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.DocumentsContract
import android.content.Intent
import androidx.core.content.ContextCompat
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.swamitech.phoenix.local.LocalRuntime
import com.swamitech.phoenix.local.ModelPackManager
import com.swamitech.phoenix.net.HfApi
import com.swamitech.phoenix.net.UploadStalledException
import com.swamitech.phoenix.security.SecureStore
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.delay
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONArray
import org.json.JSONObject
import android.provider.OpenableColumns
import java.io.File
import java.util.UUID

class PhoenixViewModel(app: Application) : AndroidViewModel(app) {
    companion object {
        const val DEFAULT_SPACE = "https://swamivicky-swamitechgradio2.hf.space"
        const val DEFAULT_ENDPOINT = "phoenix_submit_video"
        const val MAX_SPACES = 21
        /** 1.2.59: video uploads running at the same time (each to its own Space). */
        const val VIDEO_UPLOADS_AT_ONCE = 3
        /** 1.2.59: a video upload that has had no byte accepted for this long steps aside and is tried again. */
        const val VIDEO_STALL_MS = 3 * 60 * 1000L
        /** 1.2.59: how many times a stalled upload is tried again before the part is marked Failed. */
        const val VIDEO_STALL_TRIES = 5
        /** A history entry in one of these states is not using its Space (1.2.29: Cancelled/Error/Downloading added). */
        val TERMINAL_STATUSES = setOf(
            "Done", "Failed", "Monitoring stopped", "Replaced", "Cancelled", "Canceled", "Error", "Stopped", "Expired",
            "Interrupted", "Downloading", "Merged"
        )
        private const val PREFS = "phoenix_history"
        private const val HISTORY_KEY = "items"
        private const val SPACES_JSON_KEY = "spaces_json"
        // Old two-slot keys, kept only so an existing install's Space 1/Space 2
        // configuration migrates into the new 5-slot list instead of being lost.
        private const val SPACE1_LABEL_KEY = "space1_label"
        private const val SPACE1_URL_KEY = "space1_url"
        private const val SPACE2_LABEL_KEY = "space2_label"
        private const val SPACE2_URL_KEY = "space2_url"
        private const val SELECTED_SPACE_KEY = "selected_space"
        private const val OUTPUT_TREE_KEY = "output_tree_uri"
        private const val SAVED_JOBS_KEY = "saved_remote_job_ids"
        private const val SERVER_KEEP_MS = 3L * 60L * 60L * 1000L
        private val DEAD_STATUSES = setOf("Done", "Failed", "Monitoring stopped")
        private val NETWORK_HOLD_STATUSES = setOf(
            "Waiting for network", "Ready on server", "On server", "Reconnecting"
        )
    }

    data class SpaceSlot(val label: String, val url: String)

    data class HistoryItem(
        val id: String,
        val kind: String,
        val name: String,
        val uri: String?,
        val status: String,
        val createdAt: Long,
        val spaceLabel: String = "Space 1",
        val spaceUrl: String = "",
        val remoteJobId: String? = null,
        val progress: Float = 0f,
        val eta: String = "ETA —",
        val groupId: String? = null,
        val partIndex: Int = 0,
        val partCount: Int = 1,
        val sourcePath: String? = null,
        val detail: String = "",
        // 1.2.57: a split part remembers its original video and its range there, so Redo part can cut it again
        val origUri: String? = null,
        val origStartPct: Int = -1,
        val origEndPct: Int = -1
    )

    private val secure = SecureStore(app)
    private val models = ModelPackManager(app)
    private val saveLock = Any()
    private val savingJobIds = mutableSetOf<String>()

    // Keyed by space+video so two concurrent jobs on DIFFERENT Spaces never
    // collide on a single shared slot - the old 3-field design let a
    // still-in-flight write on one Space be read by a job targeting a
    // different Space, handing back a path that was never uploaded there at
    // all. A ConcurrentHashMap of Deferred (not plain values) also makes
    // concurrent calls for the SAME key single-flight: a second caller joins
    // the one already-running upload instead of starting a wasteful
    // duplicate transfer of the same file.
    private val videoUploadCache = java.util.concurrent.ConcurrentHashMap<String, Deferred<UploadedVideo>>()

    /**
     * A video already sitting on a Space, plus whatever trim the server
     * still has to apply to it. When the clip was cut locally before upload,
     * the uploaded file IS the selected range, so the original percentages
     * must not be sent again - that would trim an already-trimmed clip.
     */
    private data class UploadedVideo(
        val path: String,
        val trimStartPct: Int,
        val trimEndPct: Int,
        /** Where the uploaded file starts in the ORIGINAL video (a local cut lands on a key frame), microseconds. */
        val offsetUs: Long = 0L
    )

    /**
     * Upload concurrency is isolated PER Space. A global semaphore made jobs
     * on different Hugging Face Spaces wait behind each other even though the
     * remote renderers are independent. Keep one upload in flight per Space
     * to protect the phone/network while allowing Space 1 and Space 2 (etc.)
     * to start independently.
     */
    private val uploadGates = java.util.concurrent.ConcurrentHashMap<String, Semaphore>()

    private fun uploadGate(settings: HfSettings): Semaphore {
        val key = settings.spaceUrl.trim().trimEnd('/').lowercase()
        return uploadGates.computeIfAbsent(key) { Semaphore(permits = 3) }
    }

    // The trim range is part of the key: the uploaded file is now the cut
    // segment, not the whole source, so two different trims are two
    // genuinely different uploads. Without this, changing the trim would
    // silently reuse the previously-cut file.
    private fun videoCacheKey(settings: HfSettings, uri: Uri, trimStart: Int, trimEnd: Int): String =
        "${settings.spaceUrl.trim().trimEnd('/')}|$uri|$trimStart-$trimEnd"

    private fun resumableToken(vararg parts: Any?): String {
        val d = java.security.MessageDigest.getInstance("SHA-256").digest(parts.joinToString("|").toByteArray())
        return d.joinToString("") { "%02x".format(it) }.take(40)
    }

    /**
     * Sends the video. 1.2.23: through the Space's resumable routes when it has them (Space v11.2.80+), so a
     * dropped connection or a pause in the background loses one 4-MB chunk, not the whole upload; on an
     * older Space, or a gallery provider that cannot be read at an offset, Gradio's one-request /upload as
     * before.
     */
    private fun sendVideo(settings: HfSettings, uri: Uri, file: File?, mime: String, key: String,
                          progress: (Long, Long) -> Unit): String {
        val app = getApplication<Application>()
        val pfd = if (file == null) runCatching { app.contentResolver.openFileDescriptor(uri, "r") }.getOrNull() else null
        try {
            val size = file?.length() ?: pfd?.statSize ?: -1L
            val channel: java.nio.channels.FileChannel? = when {
                file != null -> runCatching { java.io.RandomAccessFile(file, "r").channel }.getOrNull()
                pfd != null -> runCatching { java.io.FileInputStream(pfd.fileDescriptor).channel }.getOrNull()
                else -> null
            }
            if (size > 0L && channel != null) {
                try {
                    val token = resumableToken(settings.spaceUrl.trim().trimEnd('/'), key, size)
                    val path = hf.uploadResumable(
                        settings, "phoenix_video_${token.take(12)}.mp4", size, token,
                        // 1.2.59: 3 minutes without a byte accepted ends this try (it was 15, and a single request
                        // of the whole file followed): the part steps aside, the others go on, and it resumes later
                        maxStallMs = VIDEO_STALL_MS,
                        readChunk = { off, n ->
                            val buf = java.nio.ByteBuffer.allocateDirect(n)
                            var pos = off
                            var spins = 0
                            while (buf.hasRemaining()) {
                                val r = channel.read(buf, pos)
                                if (r < 0) break
                                if (r == 0) {
                                    if (++spins > 8) break          // 1.2.37: a source that keeps answering 0 bytes must not spin forever
                                    continue
                                }
                                spins = 0
                                pos += r
                            }
                            if (buf.position() == n) buf.array() else buf.array().copyOf(buf.position())
                        },
                        onProgress = progress
                    )
                    if (path != null) return path
                } catch (e: kotlinx.coroutines.CancellationException) {
                    throw e
                } catch (e: UploadStalledException) {
                    throw e                         // 1.2.59: no whole-file request after a stall - try again later instead
                } catch (e: Throwable) {
                    // 1.2.37 (from 1.2.34): a chunk that dies part way (a proxy page, a restart, a short read) must not end the
                    // job. The whole file still goes up by the older single request.
                    status = "Resumable upload stopped (${e.message ?: e.javaClass.simpleName}). Sending the video in one request."
                } finally {
                    runCatching { channel.close() }
                }
            }
        } finally {
            runCatching { pfd?.close() }
        }
        return if (file != null) hf.upload(settings, file, mime, progress)
        else hf.uploadUri(settings, app.contentResolver, uri, "phoenix_video_${System.currentTimeMillis()}.mp4", mime, progress)
    }

    // 1.2.23: the keep-alive service runs while an upload is in progress, and only then. It is started while
    // the app is on screen (a tap on Start), as a plain started service that promotes itself to the
    // foreground - never with startForegroundService() from the background, which is what made 1.2.19/1.2.20
    // vanish (Android ends an app whose foreground-service start it refused, with no message).
    private val activeTransfers = java.util.concurrent.atomic.AtomicInteger(0)
    /**
     * 1.2.59: three videos go up at once (each to its own Space). With one at a time, a single part whose Space did not
     * answer held every other part at "Uploading video 2 %" for 30 minutes and more. Memory stays small: the resumable
     * upload reads 1 MB at a time per part, and the parts are cut one after another before this.
     */
    private val videoUploadSlots = Semaphore(VIDEO_UPLOADS_AT_ONCE)
    /** Parts waiting for an upload slot, in order, so each card can say where it is in the queue. */
    private val uploadQueue = java.util.concurrent.CopyOnWriteArrayList<String>()

    private fun refreshUploadQueue() {
        uploadQueue.forEachIndexed { i, id ->
            updateHistory(id, eta = if (i == 0) "Queued - next to upload ($VIDEO_UPLOADS_AT_ONCE upload at a time)"
                else "Queued - $i part${if (i == 1) "" else "s"} ahead ($VIDEO_UPLOADS_AT_ONCE upload at a time)")
        }
    }

    private fun isUploadStall(e: Throwable): Boolean {
        var t: Throwable? = e
        var depth = 0
        while (t != null && depth++ < 8) {
            if (t is UploadStalledException) return true
            t = t.cause
        }
        return false
    }

    private fun transferStarted() {
        if (activeTransfers.incrementAndGet() == 1) {
            runCatching {
                val app = getApplication<Application>()
                app.startService(Intent(app, PhoenixKeepAliveService::class.java))
            }
        }
    }

    private fun transferEnded() {
        if (activeTransfers.decrementAndGet() <= 0) {
            activeTransfers.set(0)
            runCatching {
                val app = getApplication<Application>()
                app.stopService(Intent(app, PhoenixKeepAliveService::class.java))
            }
        }
    }

    private suspend fun uploadVideoOnce(
        settings: HfSettings,
        uri: Uri,
        trimStart: Int = options.trimStart,
        trimEnd: Int = options.trimEnd,
        onProgress: ((written: Long, total: Long) -> Unit)? = null
    ): UploadedVideo {
        val key = videoCacheKey(settings, uri, trimStart, trimEnd)
        val wantStart = trimStart
        val wantEnd = trimEnd
        val deferred = videoUploadCache.computeIfAbsent(key) {
            viewModelScope.async(Dispatchers.IO) {
                val app = getApplication<Application>()
                val mime = app.contentResolver.getType(uri) ?: "video/mp4"

                // Cut the clip locally so only the selected range crosses the
                // network. Trimming used to happen entirely server-side, so a
                // 10-second selection out of a 4-minute clip still uploaded
                // all 4 minutes - the slowest part of the job, and the exact
                // transfer that has been dropping when several Spaces start
                // together. Any failure here falls straight through to the
                // old behaviour (upload everything, let the server trim): a
                // trim that cannot be performed must never fail the job.
                var trimmedFile: File? = null
                var sendStart = wantStart
                var sendEnd = wantEnd
                var offsetUs = 0L
                if (wantStart > 0 || wantEnd < 100) {
                    val totalUs = VideoTrimmer.durationUs(app, uri)
                    if (totalUs != null && totalUs > 0L) {
                        val startUs = totalUs * wantStart / 100L
                        val endUs = totalUs * wantEnd / 100L
                        if (endUs > startUs) {
                            status = "Trimming video locally…"
                            val dest = File(app.cacheDir, "phoenix_trim_${System.currentTimeMillis()}.mp4")
                            val cut = VideoTrimmer.trim(app, uri, startUs, endUs, dest)
                            if (cut != null && cut.durationUs > 0L) {
                                trimmedFile = cut.file
                                offsetUs = (startUs - cut.residualStartUs).coerceAtLeast(0L)
                                // Only the sync-frame residue is left for the
                                // server, expressed against the NEW duration.
                                // Truncating (not rounding) is deliberate: the
                                // server's trim is an integer percentage, so
                                // the residue can't always be expressed
                                // exactly, and truncating errs toward keeping
                                // a few extra milliseconds at the head rather
                                // than cutting into footage the user actually
                                // selected. The residual error is far finer
                                // than the trim slider itself, which is 1% of
                                // the SOURCE (seconds on a long clip).
                                sendStart = ((cut.residualStartUs * 100.0) / cut.durationUs)
                                    .toInt().coerceIn(0, 99)
                                sendEnd = 100
                            }
                        }
                    }
                }

                var lastProgressPush = 0L
                val progress: (Long, Long) -> Unit = { written, total ->
                    val now = System.currentTimeMillis()
                    if (now - lastProgressPush >= 400L || (total > 0 && written >= total)) {
                        lastProgressPush = now
                        val doneMb = "%.1f".format(written / 1_048_576.0)
                        status = if (total > 0) {
                            val totalMb = "%.1f".format(total / 1_048_576.0)
                            val pct = (written.toFloat() / total * 100).toInt()
                            "Uploading video — $doneMb of $totalMb MB ($pct%)"
                        } else {
                            "Uploading video — $doneMb MB so far"
                        }
                        onProgress?.invoke(written, total)
                    }
                }
                transferStarted()
                val path = try {
                    uploadGate(settings).withPermit {
                        sendVideo(settings, uri, trimmedFile, mime, key, progress)
                    }
                } finally {
                    transferEnded()
                }
                trimmedFile?.let { safeDelete(it) }
                UploadedVideo(path, sendStart, sendEnd, offsetUs)
            }
        }
        return try {
            deferred.await()
        } catch (e: Throwable) {
            // A failed upload must not poison the cache for a later retry.
            videoUploadCache.remove(key, deferred)
            throw e
        }
    }
    private val local by lazy { LocalRuntime(getApplication()) }
    private val hf = HfApi { secure.getToken() }
    private val prefs = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private var processingJob: Job? = null
    // Concurrent map so multiple job coroutines can safely add/remove their
    // own entries without corrupting the map's internal structure - a plain
    // mutableMapOf is not safe for concurrent modification even for simple
    // put/remove calls from different threads.
    private val parallelJobs = java.util.concurrent.ConcurrentHashMap<String, Job>()
    private var latestJobLocalId: String? = null

    var appMode by mutableStateOf(AppMode.HUGGING_FACE); private set
    var activeTab by mutableStateOf("Video"); private set
    var status by mutableStateOf("Ready — Phoenix Cloud mode"); private set
    var eta by mutableStateOf("ETA —"); private set
    var progress by mutableFloatStateOf(0f); private set
    var farmPhase by mutableStateOf(""); private set
    var farmPercent by mutableIntStateOf(0); private set
    var running by mutableStateOf(false); private set

    private fun setFarm(phase: String, pct: Int) {
        farmPhase = phase
        farmPercent = pct.coerceIn(0, 100)
        progress = farmPercent / 100f
        status = if (phase.isBlank()) status else "$phase  ${farmPercent}%"
        eta = if (phase.isBlank()) eta else "${farmPercent}%"
    }

    var selectedVideo by mutableStateOf<Uri?>(null); private set
    var selectedImage by mutableStateOf<Uri?>(null); private set
    var face1 by mutableStateOf<Uri?>(null); private set
    var face2 by mutableStateOf<Uri?>(null); private set
    var face3 by mutableStateOf<Uri?>(null); private set
    var face4 by mutableStateOf<Uri?>(null); private set
    var resultUri by mutableStateOf<Uri?>(null); private set
    var imageResultUri by mutableStateOf<Uri?>(null); private set

    var framePercent by mutableStateOf(0); private set
    var detectedFrameUri by mutableStateOf<Uri?>(null); private set

    // ---- Skin tone (1.2.51; Space v11.2.205) -------------------------------------------------------------------
    /** A person the Space toned on the preview frame: slot 1-4, face box (0-1 of the frame), amount -1..1, skin share. */
    data class SkinPerson(val slot: Int, val box: List<Float>, val amount: Float, val skin: Float)
    var skinBusy by mutableStateOf(false); private set
    var skinMessage by mutableStateOf<String?>(null); private set
    var skinBefore by mutableStateOf<File?>(null); private set
    var skinAfter by mutableStateOf<File?>(null); private set
    var skinPeople by mutableStateOf<List<SkinPerson>>(emptyList()); private set
    var skinPreviewPct by mutableStateOf(-1); private set

    fun skinToneAt(slot: Int): Float = options.skinTone.getOrNull(slot - 1) ?: 0f
    val skinToneOn: Boolean get() = options.skinTone.any { kotlin.math.abs(it) >= 0.005f }
    /** The person's own face from Detect (who is toned) when captured, else the replacement face. */
    fun skinThumb(slot: Int): Uri? = targetRefs.getOrNull(slot - 1)

    fun setSkinTone(slot: Int, value: Float) {
        if (slot !in 1..4) return
        val v = Math.round(value.coerceIn(-1f, 1f) * 20f) / 20f          // steps of 5 %
        updateOptions { o ->
            val l = o.skinTone.toMutableList()
            while (l.size < 4) l.add(0f)
            l[slot - 1] = v
            o.copy(skinTone = l.toList())
        }
    }

    fun resetSkinTone() {
        updateOptions { it.copy(skinTone = listOf(0f, 0f, 0f, 0f)) }
        skinMessage = null
    }

    private fun clearSkinPreview() {
        skinAfter?.let { runCatching { it.delete() } }
        skinBefore?.let { runCatching { it.delete() } }
        skinAfter = null; skinBefore = null; skinPeople = emptyList(); skinPreviewPct = -1; skinMessage = null
    }

    /** Tone the frame picked in step 01 on the Space, exactly as the video job will (phoenix_skin_preview). */
    fun previewSkin() {
        val uri = selectedVideo ?: run { skinMessage = "Select a target video first"; return }
        if (skinBusy) return
        if (!skinToneOn) { skinMessage = "Move a slider first: everyone is at Natural."; return }
        skinBusy = true
        val pct = framePercent
        val tone = options.skinTone.toList()
        skinMessage = "Toning the frame at $pct % on $spaceLabel… (the first time also loads the skin models, about 20 s)"
        viewModelScope.launch(guard + Dispatchers.IO) {
            try {
                val st = settings()
                hf.wakeSpace(st) { msg -> skinMessage = "$spaceLabel · $msg" }
                val videoPath = uploadVideoOnce(st, uri).path
                val resolver = getApplication<Application>().contentResolver
                val refs = JSONArray()
                for (i in 0 until 4) {
                    val r = targetRefs[i]
                    val path = r?.let { ref ->
                        runCatching { hf.uploadUri(st, resolver, ref, "phoenix_skinref_${i + 1}.jpg", resolver.getType(ref) ?: "image/jpeg") }.getOrNull()
                    }
                    if (path == null) refs.put(JSONObject.NULL) else refs.put(path)
                }
                // the replacement faces too: the Space then matches people to slots exactly as the job does (their gender)
                val faceList = listOf(face1, face2, face3, face4)
                val faces = JSONArray()
                for (i in 0 until 4) {
                    val f = faceList[i]
                    val path = f?.let { fu ->
                        runCatching { hf.uploadUri(st, resolver, fu, "phoenix_skinface_${i + 1}.jpg", resolver.getType(fu) ?: "image/jpeg") }.getOrNull()
                    }
                    if (path == null) faces.put(JSONObject.NULL) else faces.put(path)
                }
                val slots = JSONArray()
                faceList.forEachIndexed { i, f -> if (f != null) slots.put(i + 1) }
                val js = JSONObject().put("position_pct", pct)
                    .put("skin_tone", JSONArray(tone.map { it.toDouble() }))
                    .put("target_refs", refs)
                    .put("faces", faces)
                if (slots.length() > 0) js.put("slots", slots)
                val res = hf.skinPreview(st, videoPath, js.toString())
                val info = res.info
                if (info != null && !info.optBoolean("ok", false)) {
                    throw IllegalStateException(info.optString("error").ifBlank { "the Space could not tone it" })
                }
                val afterPath = res.after ?: throw IllegalStateException("the Space returned no picture")
                val after = downloadToCache(st, afterPath, "skin_after")
                val before = res.before?.let { runCatching { downloadToCache(st, it, "skin_before") }.getOrNull() }
                val people = mutableListOf<SkinPerson>()
                info?.optJSONArray("people")?.let { arr ->
                    for (k in 0 until arr.length()) {
                        val o = arr.optJSONObject(k) ?: continue
                        val b = o.optJSONArray("box")
                        people.add(SkinPerson(o.optInt("slot"),
                            if (b != null) (0 until b.length()).map { b.optDouble(it).toFloat() } else emptyList(),
                            o.optDouble("amount", 0.0).toFloat(), o.optDouble("skin", 0.0).toFloat()))
                    }
                }
                withContext(Dispatchers.Main) {
                    skinAfter?.let { runCatching { it.delete() } }
                    skinBefore?.let { runCatching { it.delete() } }
                    skinAfter = after; skinBefore = before; skinPeople = people; skinPreviewPct = pct
                }
                val missing = info?.optJSONArray("not_found")
                skinMessage = buildString {
                    append("Preview ready")
                    info?.optInt("ms", -1)?.takeIf { it >= 0 }?.let { append(" (%.1f s)".format(it / 1000.0)) }
                    append(". Drag the line to compare Before and After.")
                    if (missing != null && missing.length() > 0) {
                        append(" Not on this frame: " + (0 until missing.length()).joinToString { "#" + missing.optInt(it) } + ". Pick another frame.")
                    }
                    if (info != null && info.optString("by") != "Detect references") {
                        append(" People were matched by " + info.optString("by") + "; capture each person in Detect (step 02) " +
                            "so the video matches them the same way for sure.")
                    }
                }
            } catch (e: Throwable) {
                val d = e.message ?: e.javaClass.simpleName
                skinMessage = if (d.contains("phoenix_skin_preview") || d.contains("404") || d.contains("fn_index"))
                    "This Space has no Skin tone yet (it needs Phoenix v11.2.205 or later). Update the Space, then Preview again."
                else "Preview failed: $d"
            } finally {
                skinBusy = false
            }
        }
    }

    // ---- Patch Removal (1.2.25 / 1.2.26; Space v11.2.96 / v11.2.97) -------------------------------------------
    var patches by mutableStateOf<List<PatchSpec>>(emptyList()); private set
    var patchBusy by mutableStateOf(false); private set
    var patchMessage by mutableStateOf<String?>(null); private set
    /** The editor's state lives here, so rotating the phone (or leaving the app briefly) never closes or resets it. */
    var patchEditorOpen by mutableStateOf(false); private set
    var patchSession by mutableStateOf<PatchSession?>(null); private set

    private fun patchDir(): File = File(getApplication<Application>().filesDir, "patches").apply { mkdirs() }

    fun openPatchEditor() {
        val v = selectedVideo ?: return
        if (patchSession?.video != v) patchSession = PatchSession(v)
        patchMessage = null
        patchEditorOpen = true
    }

    /** Close: a mark not frozen yet is dropped (its saved positions too). */
    fun closePatchEditor() {
        patchEditorOpen = false
        val s = patchSession
        patchSession = null
        s?.frame?.let { if (!it.isRecycled) runCatching { it.recycle() } }
        s?.preview?.let { if (!it.isRecycled) runCatching { it.recycle() } }
        s?.positions?.forEach { deleteView(it) }
        s?.previewView?.let { deleteView(it) }
        patchMessage = null
    }

    private fun releaseIdleBitmaps() {
        if (patchEditorOpen) return
        val s = patchSession ?: return
        val frame = s.frame
        val preview = s.preview
        s.frame = null
        s.preview = null
        frame?.let { if (!it.isRecycled) runCatching { it.recycle() } }
        preview?.let { if (!it.isRecycled) runCatching { it.recycle() } }
    }

    private fun deleteView(v: PatchView) { runCatching { v.frameFile.parentFile?.deleteRecursively() } }

    /** Save the painted position (frame JPEG + mask PNG of the same size). */
    private fun saveView(frame: android.graphics.Bitmap, strokes: List<PaintStroke>, timeMs: Long, polygon: List<androidx.compose.ui.geometry.Offset> = emptyList()): PatchView {
        val id = "v" + System.currentTimeMillis().toString(36) + (0..999).random()
        val dir = File(patchDir(), id).apply { mkdirs() }
        val f = File(dir, "frame.jpg")
        val m = File(dir, "mask.png")
        PatchFrames.save(frame, f, png = false)
        PatchFrames.save(PatchFrames.maskBitmap(frame.width, frame.height, strokes, polygon), m, png = true)
        return PatchView(id, f, m, null, timeMs, frame.width, frame.height)
    }

    /** The current position as a saved view: the previewed one if the painting has not changed since, else a new one. */
    private fun currentView(s: PatchSession, frame: android.graphics.Bitmap): PatchView =
        s.previewView ?: saveView(frame, s.strokes.toList(), s.frameMs, s.bellyPts)

    /** Ask the Space for this frame with the painted mark removed (the same fill the job makes on this frame). */
    fun previewPatch(s: PatchSession, frame: android.graphics.Bitmap) {
        if (patchBusy) return
        val view = saveView(frame, s.strokes.toList(), s.frameMs, s.bellyPts)
        patchBusy = true
        patchMessage = "Erasing on ${spaceLabel}\u2026 (about 5\u201315 s; the first time also loads the model)"
        viewModelScope.launch(guard + Dispatchers.IO) {
            try {
                val st = settings()
                val res = hf.patchPreview(st, view.frameFile, view.maskFile)
                val info = res.info
                if (info != null && !info.optBoolean("ok", false)) {
                    throw IllegalStateException(info.optString("error").ifBlank { "the Space could not erase it" })
                }
                val path = res.path ?: throw IllegalStateException("the Space returned no picture")
                val out = File(view.frameFile.parentFile, "preview.jpg").also { hf.downloadOutput(st, path, it) }
                val bmp = PatchFrames.decode(out)
                withContext(Dispatchers.Main) {
                    s.previewView?.let { if (s.positions.none { p -> p.id == it.id }) deleteView(it) }
                    s.previewView = view.copy(previewFile = out)
                    s.preview = bmp
                    s.showPreview = bmp != null
                }
                patchMessage = "Erased" + (info?.let { " (${it.optString("inpainter", "")}, ${it.optInt("ms") / 1000.0} s)" } ?: "") +
                    ". Before / After to check. Then Freeze, or + Position to paint the same mark where the person has moved."
            } catch (e: Throwable) {
                deleteView(view)
                val d = e.message ?: e.javaClass.simpleName
                patchMessage = if (d.contains("phoenix_patch_preview") || d.contains("404"))
                    "This Space has no Patch Removal yet (it needs Phoenix v11.2.96 or later). You can still Freeze; " +
                        "the mark is only removed by Spaces on v11.2.96 or later."
                else "Preview failed: $d"
            } finally {
                patchBusy = false
            }
        }
    }

    /** The four corners of the band, from the preview JSON. Empty if the Space did not send them. */
    private fun bandCorners(info: org.json.JSONObject?): List<androidx.compose.ui.geometry.Offset> {
        val arr = info?.optJSONArray("band") ?: return emptyList()
        if (arr.length() < 3) return emptyList()
        return (0 until arr.length()).mapNotNull { i ->
            val p = arr.optJSONArray(i) ?: return@mapNotNull null
            androidx.compose.ui.geometry.Offset(p.optDouble(0).toFloat(), p.optDouble(1).toFloat())
        }
    }

    /** A finger moved or resized the band. Store that as the shift, length and breadth the job already uses. */
    fun applyBellyBox(s: PatchSession) {
        s.bellyEdited = true
        val now = s.bellyPts
        val base = s.bellyBase
        if (now.size < 4 || base.size < 4) return
        fun mid(a: androidx.compose.ui.geometry.Offset, b: androidx.compose.ui.geometry.Offset) =
            androidx.compose.ui.geometry.Offset((a.x + b.x) / 2f, (a.y + b.y) / 2f)
        fun len(a: androidx.compose.ui.geometry.Offset, b: androidx.compose.ui.geometry.Offset) =
            kotlin.math.hypot((a.x - b.x).toDouble(), (a.y - b.y).toDouble()).toFloat().coerceAtLeast(1f)
        val h0 = len(mid(base[0], base[1]), mid(base[3], base[2]))
        val w0 = len(mid(base[0], base[3]), mid(base[1], base[2]))
        val h1 = len(mid(now[0], now[1]), mid(now[3], now[2]))
        val w1 = len(mid(now[0], now[3]), mid(now[1], now[2]))
        val c0 = mid(mid(base[0], base[1]), mid(base[3], base[2]))
        val c1 = mid(mid(now[0], now[1]), mid(now[3], now[2]))
        val up = mid(base[0], base[1]) - mid(base[3], base[2])
        val upLen = len(up, androidx.compose.ui.geometry.Offset.Zero)
        val along = ((c1.x - c0.x) * up.x + (c1.y - c0.y) * up.y) / upLen
        val torso = h0 / (0.24f * s.bellyBaseLength.coerceAtLeast(0.5f))
        val shift = (s.bellyBaseShift + along / torso).coerceIn(-0.12f, 0.12f)
        val length = (s.bellyBaseLength * (h1 / h0)).coerceIn(0.5f, 1.5f)
        val width = (s.bellyBaseWidth * (w1 / w0)).coerceIn(0.5f, 1.5f)
        updateOptions { it.copy(bellyShift = shift, bellyLength = length, bellyWidth = width) }
    }

    /** 1.2.31 Belly clean preview: this frame with the band's marks removed and its skin evened (Space v11.2.111+), plus the same
     *  with the band outlined. Uses the length / breadth set in the editor. */
    fun previewBelly(s: PatchSession, frame: android.graphics.Bitmap) {
        if (patchBusy) return
        patchBusy = true
        patchMessage = "Belly clean on ${spaceLabel}\u2026 (about 5\u201320 s; the first time also loads the models)"
        val dir = File(patchDir(), "belly").apply { mkdirs() }
        // 1.2.32: the frame goes up as PNG (lossless). JPEG's colour sub-sampling blurred the mark colour the Space looks for:
        // on the test body the tattoo was 19 % left after a JPEG frame and 1 % after the same frame as PNG.
        val f = File(dir, "frame.png")
        viewModelScope.launch(guard + Dispatchers.IO) {
            try {
                PatchFrames.save(frame, f, png = true)
                val st = settings()
                val body = JSONObject()
                    .put("belly_length", options.bellyLength.toDouble())
                    .put("belly_width", options.bellyWidth.toDouble())
                    .put("belly_shift", options.bellyShift.toDouble())
                if (s.bellyEdited && s.bellyPts.size >= 3) {
                    val pts = org.json.JSONArray()
                    s.bellyPts.forEach { p -> pts.put(org.json.JSONArray().put(p.x.toDouble()).put(p.y.toDouble())) }
                    body.put("belly_pts", pts)
                }
                val js = body.toString()
                val res = hf.bellyPreview(st, f, js)
                val info = res.info
                if (info != null && !info.optBoolean("ok", false)) {
                    throw IllegalStateException(info.optString("error").ifBlank { "the Space could not clean it" })
                }
                val clean = res.clean?.let { p -> File(dir, "clean.jpg").also { hf.downloadOutput(st, p, it) } }
                val band = res.outlined?.let { p -> File(dir, "band.jpg").also { hf.downloadOutput(st, p, it) } }
                val bc = PatchFrames.decode(clean)
                val bb = PatchFrames.decode(band)
                withContext(Dispatchers.Main) {
                    s.bellyClean = bc
                    s.bellyBand = bb
                    s.bellyOutline = false
                    val pts = bandCorners(info)
                    s.bellyPts = pts
                    s.bellyBase = pts
                    s.bellyBaseShift = options.bellyShift
                    s.bellyBaseLength = options.bellyLength
                    s.bellyBaseWidth = options.bellyWidth
                    s.bellyEdited = false
                    s.showBelly = bb != null || bc != null || pts.isNotEmpty()
                    val norm = info?.optJSONArray("norm")
                    if (norm != null && norm.length() >= 3) updateOptions { it.copy(bellyNorm = norm.toString()) }
                }
                patchMessage = when {
                    info == null -> "Belly clean preview ready."
                    !info.optBoolean("body_found", false) ->
                        info.optString("reason").ifBlank {
                            "No body found on this frame. The shoulders and hips must be visible. Try another frame."
                        }
                    else -> {
                        val fence = info.optString("fence")
                        val why = info.optString("reason")
                        val line = if (why.isNotBlank()) why + " The yellow line is the band. Move it, then preview again."
                        else {
                            val px = info.optInt("marks_px", 0)
                            val n = info.optInt("pieces", 0)
                            (if (px > 0) "Removed $n mark(s) ($px px)" else "No dark patch larger than 1 square inch near the centre") +
                                (if (info.optBoolean("navel_left", false)) ", navel left alone" else "") +
                                ". The yellow line is the band."
                        }
                        if (fence.isNotBlank()) line + "\n" + fence else line
                    }
                }
            } catch (e: Throwable) {
                val d = e.message ?: e.javaClass.simpleName
                patchMessage = if (d.contains("phoenix_clean_belly_preview") || d.contains("404"))
                    "This Space has no one-go belly preview yet (it needs Phoenix v11.2.117 or later)."
                else "Belly preview failed: $d"
            } finally {
                patchBusy = false
            }
        }
    }

    /** Keep this painted position as one more view of the same mark, and start painting the next one. */
    fun addPatchPosition(s: PatchSession, frame: android.graphics.Bitmap) {
        if (s.strokes.isEmpty()) return
        val total = patches.sumOf { it.views.size } + s.positions.size + 1
        if (total > PatchFrames.MAX_VIEWS) { patchMessage = "At most ${PatchFrames.MAX_VIEWS} painted positions per video"; return }
        s.positions.add(currentView(s, frame))
        s.strokes.clear(); s.preview = null; s.previewView = null; s.showPreview = false
        patchMessage = "Position ${s.positions.size} kept. Move to a frame where the person has moved or turned and paint the same mark there."
    }

    fun removeLastPosition() {
        val s = patchSession ?: return
        if (s.positions.isEmpty()) return
        deleteView(s.positions.removeAt(s.positions.size - 1))
    }

    /** Keep the mark (all its positions, and the one being painted): it travels with the next job(s) on this video. */
    fun freezePatchMark(s: PatchSession, frame: android.graphics.Bitmap?) {
        if (patches.size >= PatchFrames.MAX_PATCHES) { patchMessage = "At most ${PatchFrames.MAX_PATCHES} marks per video"; return }
        val views = s.positions.toMutableList()
        if (frame != null && s.strokes.isNotEmpty()) views.add(currentView(s, frame))
        if (views.isEmpty()) return
        if (patches.sumOf { it.views.size } + views.size > PatchFrames.MAX_VIEWS) {
            patchMessage = "At most ${PatchFrames.MAX_VIEWS} painted positions per video"; return
        }
        patches = patches + PatchSpec(s.markId, views.sortedBy { it.timeMs })
        s.positions.clear(); s.previewView = null           // (kept: not deleted by closing)
        patchEditorOpen = false
        patchSession = null
        patchMessage = null
        status = "Mark frozen (${views.size} position(s)) \u2014 it will be removed across the video (${patches.size}/${PatchFrames.MAX_PATCHES} marks)"
    }

    fun removePatch(id: String) {
        patches.find { it.id == id }?.views?.forEach { deleteView(it) }
        patches = patches.filterNot { it.id == id }
    }

    private fun clearPatches() {
        patches.forEach { p -> p.views.forEach { deleteView(it) } }
        patches = emptyList()
        if (patchEditorOpen) closePatchEditor()
        patchMessage = null
    }

    /** settings.patches for phoenix_submit_video: one entry per painted position (group = the mark), frame + mask
     *  (base64), and the time IN THE UPLOADED FILE (a local trim starts on a key frame: offsetUs). */
    private fun addPatches(o: JSONObject, offsetUs: Long) {
        val list = patches
        if (list.isEmpty()) return
        val arr = JSONArray()
        list.take(PatchFrames.MAX_PATCHES).forEach { mark ->
            mark.views.forEach { v ->
                if (arr.length() >= PatchFrames.MAX_VIEWS) return@forEach
                runCatching {
                    arr.put(JSONObject()
                        .put("group", mark.id)
                        .put("image_b64", android.util.Base64.encodeToString(v.frameFile.readBytes(), android.util.Base64.NO_WRAP))
                        .put("mask_b64", android.util.Base64.encodeToString(v.maskFile.readBytes(), android.util.Base64.NO_WRAP))
                        .put("t", ((v.timeMs * 1000L - offsetUs).coerceAtLeast(0L)) / 1_000_000.0))
                }
            }
        }
        if (arr.length() > 0) o.put("patches", arr)
    }
    var detectedFaces by mutableStateOf<List<Uri?>>(listOf(null, null, null, null)); private set
    /** 0 = woman, 1 = man. Filled by Detect, then changed if the letter is wrong. */
    var detectedSex by mutableStateOf<List<Int?>>(listOf(null, null, null, null)); private set
    var slotSex by mutableStateOf<List<Int?>>(listOf(null, null, null, null)); private set
    private var slotFromDetect = listOf(-1, -1, -1, -1)
    private var targetRefs = mutableListOf<Uri?>(null, null, null, null)
    var detectingFrame by mutableStateOf(false); private set
    var detectingImage by mutableStateOf(false); private set

    var options by mutableStateOf(PhoenixOptions()); private set
    private var _imageQuality by mutableStateOf("Best")
    val imageQuality: String get() = _imageQuality
    fun updateImageQuality(value: String) { _imageQuality = value }

    var hfTokenSet by mutableStateOf(!secure.getToken().isNullOrBlank()); private set
    var packFiles by mutableStateOf<List<Uri>>(emptyList()); private set
    var packPushing by mutableStateOf(false); private set
    var packStatus by mutableStateOf(""); private set
    /** Spaces whose update is held back until their running job ends (1.2.24). */
    var pendingUpdates by mutableStateOf<List<String>>(emptyList()); private set
    private var pendingLoop: Job? = null
    var selectedSpaceIndex by mutableStateOf(0); private set
    var spaces by mutableStateOf(defaultSpaces()); private set
    val spaceUrl: String get() = spaces[selectedSpaceIndex].url
    val spaceLabel: String get() = spaces[selectedSpaceIndex].label
    var activeJobCount by mutableIntStateOf(0); private set
    var endpoint by mutableStateOf(DEFAULT_ENDPOINT)
    var modelRepo by mutableStateOf("")
    var modelRevision by mutableStateOf("main")
    var discoveredApi by mutableStateOf(""); private set
    var modelReady by mutableStateOf(models.isComplete()); private set
    // One single lock for every history mutation. AppV16's attempt at this
    // used a coroutine Mutex in updateHistory() but a separate, unrelated
    // synchronized(Any()) lock in addHistory/removeHistory/clearHistory/
    // refreshHistory/cleanupHistoryMetadata - two independent primitives
    // provide zero protection against each other, so the exact race it was
    // meant to fix was still fully possible between those two groups. A
    // plain JVM lock works correctly from both suspend and non-suspend call
    // sites (none of these bodies need to suspend while holding it), so one
    // consistent primitive covers every mutation path without that trap.
    private val historyLock = Any()
    var history by mutableStateOf(loadHistory()); private set

    /**
     * A user-chosen SAF tree URI results save into instead of the default
     * Movies/Phoenix or Pictures/Phoenix. Null means "use the default" -
     * this is purely additive, nothing about the existing MediaStore path
     * changes for anyone who never sets one.
     */
    var outputTreeUri by mutableStateOf<Uri?>(
        prefs.getString(OUTPUT_TREE_KEY, null)?.let { runCatching { Uri.parse(it) }.getOrNull() }
    ); private set

    fun setOutputTree(uri: Uri?) {
        outputTreeUri = uri
        prefs.edit().apply {
            if (uri == null) remove(OUTPUT_TREE_KEY) else putString(OUTPUT_TREE_KEY, uri.toString())
        }.apply()
        status = if (uri == null) "Output folder reset to default (Movies/Phoenix)" else "Output folder set — new results will save there"
    }

    /** Human-readable label for whatever's currently configured, for the UI. */
    fun outputFolderLabel(): String {
        val uri = outputTreeUri ?: return "Default (Movies/Phoenix, Pictures/Phoenix)"
        val docUri = runCatching {
            DocumentsContract.buildDocumentUriUsingTree(uri, DocumentsContract.getTreeDocumentId(uri))
        }.getOrNull() ?: return "Custom folder"
        val name = runCatching {
            getApplication<Application>().contentResolver.query(
                docUri, arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME), null, null, null
            )?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
        }.getOrNull()
        return name?.let { "Custom: $it" } ?: "Custom folder"
    }

    /** Why the app closed last time, shown on the next launch (no message is shown by the phone). */
    var lastExitNote by mutableStateOf(""); private set

    fun dismissLastExitNote() { lastExitNote = "" }

    // NOTE: state read or written by init{} must be declared ABOVE it (Kotlin runs initialisers in order).
    /** An error in background work is recorded and shown, never allowed to end the app. */
    private val guard: CoroutineExceptionHandler = Guard.handler(app) { e ->
        // 1.2.37 (from 1.2.35): show the root cause, not the wrapper around it
        var root: Throwable = e
        var depth = 0
        while (root.cause != null && root.cause !== root && depth++ < 6) root = root.cause!!
        val why = (root.message ?: root.javaClass.simpleName).take(140)
        status = "Stopped: $why"
    }

    /** True after repeated crashes: the app opens and shows what happened, but leaves running jobs alone. */
    var safeMode by mutableStateOf(false); private set

    /** Leaves safe mode and reconnects to every running job. */
    fun leaveSafeMode() {
        Guard.clearCrashTimes(getApplication())
        safeMode = false
        lastExitNote = ""
        runCatching { watchNetwork() }
        runCatching { resumeTrackedJobs() }
    }

    private fun reportLastExit() {
        val app = getApplication<Application>()
        val parts = mutableListOf<String>()
        runCatching {
            val f = java.io.File(app.filesDir, "last_crash.txt")
            if (f.isFile) {
                parts += "Error: " + f.readText().trim()
                f.delete()
            }
        }
        if (Build.VERSION.SDK_INT >= 30) {
            runCatching {
                val am = app.getSystemService(ActivityManager::class.java)
                val info = am?.getHistoricalProcessExitReasons(app.packageName, 0, 1)?.firstOrNull()
                if (info != null && info.timestamp > prefs.getLong("last_exit_seen", 0L)) {
                    prefs.edit().putLong("last_exit_seen", info.timestamp).apply()
                    val why = when (info.reason) {
                        ApplicationExitInfo.REASON_CRASH -> "crashed"
                        ApplicationExitInfo.REASON_CRASH_NATIVE -> "crashed (native code)"
                        ApplicationExitInfo.REASON_ANR -> "stopped responding"
                        ApplicationExitInfo.REASON_LOW_MEMORY -> "was closed last time to free memory. This build holds less. The Spaces keep the jobs"
                        ApplicationExitInfo.REASON_EXCESSIVE_RESOURCE_USAGE -> "was closed by Android: too many resources"
                        ApplicationExitInfo.REASON_SIGNALED -> "was killed by the system"
                        ApplicationExitInfo.REASON_INITIALIZATION_FAILURE -> "failed to start"
                        ApplicationExitInfo.REASON_DEPENDENCY_DIED -> "was closed because a system part it needs stopped"
                        ApplicationExitInfo.REASON_PERMISSION_CHANGE -> "was closed after a permission change"
                        ApplicationExitInfo.REASON_OTHER -> "was closed by the system"
                        else -> null
                    }
                    if (why != null) {
                        parts += "Phoenix $why" + (info.description?.takeIf { it.isNotBlank() }?.let { " ($it)" } ?: "") + "."
                    }
                }
            }
        }
        if (Guard.takeRecovered(app)) {
            parts.add(0, if (Guard.inSafeMode(app))
                "Phoenix restarted itself after repeated errors. Safe mode: your running jobs are NOT being watched until you tap Resume jobs. They keep running on the Spaces."
            else
                "Phoenix restarted itself and reconnected to your jobs.")
        } else if (Guard.inSafeMode(app)) {
            parts.add(0, "Phoenix closed several times in a row. Safe mode: running jobs are not being watched until you tap Resume jobs. They keep running on the Spaces.")
        }
        if (parts.isNotEmpty()) lastExitNote = parts.joinToString("\n").take(1300)
    }

    private fun defaultSpaces(): List<SpaceSlot> {
        val gradio = (2..20).map { n ->
            SpaceSlot(
                "SwamitechGradio$n",
                "https://swamivicky-swamitechgradio$n.hf.space"
            )
        }
        val uat = listOf(
            SpaceSlot("SG_UAT2", "https://swamivicky-sg-uat2.hf.space"),
            SpaceSlot("SwamitechUAT2", "https://swamivicky-swamitechuat2.hf.space")
        )
        return (gradio + uat).take(MAX_SPACES)
    }

    private fun spaceKey(slot: SpaceSlot): String {
        var lab = slot.label.trim().lowercase()
            .replace(" ", "").replace("_", "").replace("-", "")
            .removePrefix("swamitech")
        when {
            lab.matches(Regex("gradio([2-9]|1[0-9]|20)")) ->
                lab = "sg" + lab.removePrefix("gradio")
            lab == "uat" || lab == "sguat" || lab == "sguat2" -> lab = "sguat2"
            lab == "uat2" -> lab = "uat2"
        }
        return lab
    }

    private fun normSpaceUrl(url: String): String =
        url.trim().trimEnd('/').lowercase()

    fun selectProcessingSpace(index: Int) {
        selectedSpaceIndex = index.coerceIn(0, MAX_SPACES - 1)
        prefs.edit().putInt(SELECTED_SPACE_KEY, selectedSpaceIndex).apply()
        status = "${spaceLabel} selected"
    }

    /**
     * Edits a Space by index WITHOUT changing which Space is selected for the
     * next job. An earlier version required the caller to select the Space
     * first, so simply typing in another Space's URL field silently rerouted
     * the next job to it.
     */
    fun updateSpaceLabel(index: Int, value: String) {
        if (index !in spaces.indices) return
        spaces = spaces.toMutableList().also { it[index] = it[index].copy(label = value) }
        persistSpaces()
    }

    fun updateSpaceUrl(index: Int, value: String) {
        if (index !in spaces.indices) return
        spaces = spaces.toMutableList().also { it[index] = it[index].copy(url = value) }
        persistSpaces()
    }

    private fun persistSpaces() {
        val arr = JSONArray()
        spaces.forEach { arr.put(JSONObject().put("label", it.label).put("url", it.url)) }
        prefs.edit().putString(SPACES_JSON_KEY, arr.toString()).apply()
    }

    fun setSelectedSpaceLabel(value: String) = updateSpaceLabel(selectedSpaceIndex, value)

    fun setSelectedSpaceUrl(value: String) = updateSpaceUrl(selectedSpaceIndex, value)

    /**
     * Why the primary Swap command is unavailable, or null when it can run.
     * The bottom action bar surfaces this instead of silently doing nothing.
     *
     * FIX: this used to check the global `running` flag, which goes true the
     * instant ANY job is active on ANY Space - so starting a job on Space 1
     * silently blocked starting a second one on Space 2, defeating the whole
     * point of running Spaces concurrently. It should only ever care about
     * how many concurrent jobs are actually active, exactly like the video
     * path below already did correctly.
     */
    val swapBlockReason: String?
        get() {
            if (activeTab == "Image") {
                if (selectedImage == null) return "Select a target image to enable the swap."
                if (listOf(face1, face2, face3, face4).all { it == null })
                    return "Add at least one replacement face."
                if (activeJobCount >= MAX_SPACES) return "All $MAX_SPACES Phoenix jobs are already active. Stop one in History."
                return null
            }
            if (selectedVideo == null) return "Select a target video to enable the swap."
            if (listOf(face1, face2, face3, face4).all { it == null })
                return "Add at least one replacement face."
            if (spaceUrl.isBlank()) return "Configure a URL for ${spaceLabel} first."
            if (activeJobCount >= MAX_SPACES) return "All $MAX_SPACES Phoenix jobs are already active. Stop one in History."
            return null
        }

    fun configuredSpaceNames(): List<String> = spaces.map {
        "${it.label}${if (it.url.isBlank()) " · not configured" else ""}"
    }

    /** What the phone knows: a job it is running or watching on this Space, not finished. (1.2.29: statuses such as
     *  "Cancelled" or "Error" no longer keep a Space busy for ever.) */
    fun isSpaceBusy(url: String): Boolean {
        if (url.isBlank()) return false
        val base = normUrl(url)
        return normUrl(url) in reservedUrls || history.any {
            normUrl(it.spaceUrl) == base && it.status !in TERMINAL_STATUSES && it.kind != "Merged"
        }
    }

    private fun normUrl(u: String) = u.trim().trimEnd('/')

    /** Spaces a split has picked for its parts that have not been started yet: not free for another job. */
    private val reservedUrls = java.util.concurrent.ConcurrentHashMap.newKeySet<String>()

    /**
     * The Spaces that can take a job NOW (1.2.29), confirmed with each Space itself where it answers (v11.2.92+):
     *  - reserved by a split that is still starting its parts, or one of this phone's jobs is live on it -> busy;
     *  - otherwise the Space's own answer (a stale "Processing" in History does not block it);
     *  - no answer -> what the phone knows.
     */
    private suspend fun idleSpaces(): List<SpaceSlot> = withContext(Dispatchers.IO) {
        spaces.filter { it.url.isNotBlank() }.map { slot ->
            async {
                val base = normUrl(slot.url)
                val live = base in reservedUrls || history.any {
                    normUrl(it.spaceUrl) == base && parallelJobs.containsKey(it.id) && it.status !in TERMINAL_STATUSES
                }
                val real = if (live) null else hf.spaceBusy(base)
                slot to !(live || (real ?: isSpaceBusy(base)))
            }
        }.awaitAll().filter { it.second }.map { it.first }
    }


    private fun selectedSettings(): HfSettings = HfSettings(
        spaceUrl.trim().trimEnd('/'), endpoint.trim().ifBlank { DEFAULT_ENDPOINT }, modelRepo, modelRevision
    )

    private fun loadSpaceSettings() {
        val defaults = defaultSpaces()
        val saved = mutableListOf<SpaceSlot>()
        val json = prefs.getString(SPACES_JSON_KEY, null)
        if (json != null) {
            runCatching {
                val arr = JSONArray(json)
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    saved += SpaceSlot(o.optString("label"), o.optString("url"))
                }
            }
        } else {
            val l1 = prefs.getString(SPACE1_LABEL_KEY, null)
            val u1 = prefs.getString(SPACE1_URL_KEY, null)
            if (!l1.isNullOrBlank() || !u1.isNullOrBlank()) {
                saved += SpaceSlot(l1 ?: "SwamitechGradio2", u1 ?: "")
            }
            val l2 = prefs.getString(SPACE2_LABEL_KEY, null)
            val u2 = prefs.getString(SPACE2_URL_KEY, null)
            if (!l2.isNullOrBlank() || !u2.isNullOrBlank()) {
                saved += SpaceSlot(l2 ?: "SwamitechGradio3", u2 ?: "")
            }
        }

        val keptSaved = saved
        val byKey = LinkedHashMap<String, SpaceSlot>()
        for (s in keptSaved) {
            val k = spaceKey(s)
            if (k.isNotBlank()) byKey.putIfAbsent(k, s)
            val u = normSpaceUrl(s.url)
            if (u.isNotBlank()) byKey.putIfAbsent(u, s)
        }

        val ordered = defaults.map { d ->
            val hit = byKey[spaceKey(d)] ?: byKey[normSpaceUrl(d.url)]
            val url = if (hit != null && hit.url.isNotBlank()) hit.url else d.url
            SpaceSlot(d.label, url)
        }.toMutableList()

        val used = ordered.map { normSpaceUrl(it.url) }.filter { it.isNotBlank() }.toMutableSet()
        for (s in keptSaved) {
            val u = normSpaceUrl(s.url)
            if (u.isNotBlank() && u !in used && ordered.size < MAX_SPACES) {
                ordered += s
                used += u
            }
        }
        while (ordered.size < MAX_SPACES) {
            ordered += SpaceSlot("Space ${ordered.size + 1}", "")
        }
        spaces = ordered.take(MAX_SPACES)
        persistSpaces()
        selectedSpaceIndex = prefs.getInt(SELECTED_SPACE_KEY, 0).coerceIn(0, MAX_SPACES - 1)
    }

    fun setTab(tab: String) { activeTab = tab; status = "${tab} workspace ready" }

    fun setMode(mode: AppMode) { appMode = mode; status = if (mode == AppMode.HUGGING_FACE) "Phoenix Cloud mode selected" else "Local mode selected" }

    /** Deletes the cache files backing the currently-shown detection/frame
     *  previews before they're replaced or discarded - otherwise every past
     *  detection's frame and face crops just accumulate on disk forever. */
    private fun clearDisplayedDetectionFiles() {
        safeDelete(detectedFrameUri)
        detectedFaces.forEach { safeDelete(it) }
    }

    fun selectVideo(uri: Uri?) {
        clearDisplayedDetectionFiles()
        if (uri != selectedVideo) { clearPatches(); clearSkinPreview() }
        selectedVideo = uri; resultUri = null; detectedFrameUri = null; detectedFaces = List(4) { null }
        progress = 0f; eta = "ETA —"; status = if (uri == null) "No video selected" else "Video selected"
        // A new video invalidates any previously-uploaded copy sitting on a
        // Space - see uploadVideoOnce() for why this cache exists.
        videoUploadCache.clear()
    }

    fun selectImage(uri: Uri?) {
        clearDisplayedDetectionFiles()
        selectedImage = uri; imageResultUri = null; detectedFaces = List(4) { null }; status = if (uri == null) "No image selected" else "Target image selected"
    }

    fun clearFace(slot: Int) { setFace(slot, null); status = "Replacement face $slot cleared" }

    // ---- saved faces (1.2.23) ----------------------------------------------------------------------
    private val faceLibrary by lazy { FaceLibrary(getApplication()) }
    var savedFaces by mutableStateOf<List<SavedFace>>(emptyList())
        private set

    fun refreshSavedFaces() {
        viewModelScope.launch {
            savedFaces = withContext(Dispatchers.IO) { runCatching { faceLibrary.list() }.getOrDefault(emptyList()) }
        }
    }

    fun faceInSlot(slot: Int): Uri? = when (slot) { 1 -> face1; 2 -> face2; 3 -> face3; 4 -> face4; else -> null }

    /** The saved face a slot is showing, if it came from the library. */
    fun savedFaceFor(uri: Uri?): SavedFace? = if (uri == null) null else savedFaces.firstOrNull { it.uri == uri }

    fun useSavedFace(slot: Int, face: SavedFace) {
        if (slot !in 1..4) return
        setFace(slot, face.uri)
        status = "\"${face.name}\" is replacement face #$slot"
    }

    /** Save the picture in [slot] to the library as [name]; the slot then points at the saved copy. */
    fun saveFaceFromSlot(slot: Int, name: String) {
        val src = faceInSlot(slot) ?: run { status = "Pick a picture for face #$slot first"; return }
        viewModelScope.launch {
            val app = getApplication<Application>()
            val result = withContext(Dispatchers.IO) { runCatching { faceLibrary.add(app.contentResolver, src, name) } }
            result.onSuccess { f ->
                setFace(slot, f.uri)
                savedFaces = withContext(Dispatchers.IO) { runCatching { faceLibrary.list() }.getOrDefault(savedFaces + f) }
                status = "Saved \"${f.name}\" - choose it from the drop-down under any face slot"
            }.onFailure { status = "Could not save the face: ${it.message ?: it.javaClass.simpleName}" }
        }
    }

    fun renameSavedFace(id: String, name: String) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { runCatching { faceLibrary.rename(id, name) } }
            savedFaces = withContext(Dispatchers.IO) { runCatching { faceLibrary.list() }.getOrDefault(savedFaces) }
        }
    }

    fun deleteSavedFace(id: String) {
        val gone = savedFaces.firstOrNull { it.id == id } ?: return
        for (slot in 1..4) if (faceInSlot(slot) == gone.uri) setFace(slot, null)
        viewModelScope.launch {
            withContext(Dispatchers.IO) { runCatching { faceLibrary.delete(id) } }
            savedFaces = withContext(Dispatchers.IO) { runCatching { faceLibrary.list() }.getOrDefault(savedFaces.filter { it.id != id }) }
            status = "Deleted saved face \"${gone.name}\""
        }
    }

    fun selectFace(slot: Int, uri: Uri?) { setFace(slot, uri); status = if (uri == null) "Face $slot cleared" else "Replacement face $slot selected" }

    private fun setFace(slot: Int, uri: Uri?) { when (slot) { 1 -> face1 = uri; 2 -> face2 = uri; 3 -> face3 = uri; 4 -> face4 = uri } }

    fun saveToken(token: String) {
        secure.putToken(token.trim()); hfTokenSet = !secure.getToken().isNullOrBlank()
        status = if (hfTokenSet) "Hugging Face token saved securely" else "Hugging Face token removed"
    }

    fun choosePackFiles(uris: List<Uri>) {
        packFiles = uris.filterNotNull()
        packStatus = if (packFiles.isEmpty()) "No files selected" else "${packFiles.size} files ready to push"
    }

    /**
     * Sends the unzipped Phoenix files (app.py, config.py, and the rest) to
     * every configured Space. Each Space gets one commit and then restarts.
     */
    fun pushPackToAllSpaces() {
        if (packPushing) return
        if (!hfTokenSet) {
            packStatus = "Save a Hugging Face token with write access first"
            return
        }
        val chosen = packFiles
        if (chosen.isEmpty()) {
            packStatus = "Pick the unzipped package files first"
            return
        }
        val targets = spaces.filter { it.url.isNotBlank() }
        if (targets.isEmpty()) {
            packStatus = "No Space URLs are configured"
            return
        }
        packPushing = true
        viewModelScope.launch(guard + Dispatchers.IO) {
            val resolver = getApplication<Application>().contentResolver
            val blobs = mutableListOf<Pair<String, ByteArray>>()
            for (uri in chosen) {
                val name = runCatching {
                    resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                        ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
                }.getOrNull()?.substringAfterLast('/')?.trim().orEmpty()
                if (name.isBlank() || name.contains("..") || name.endsWith(".zip", true) || name.endsWith(".apk", true)) {
                    continue
                }
                val bytes = runCatching { resolver.openInputStream(uri)?.use { it.readBytes() } }.getOrNull()
                    ?: continue
                if (bytes.size > 8 * 1024 * 1024) continue
                blobs += name to bytes
            }
            if (blobs.isEmpty()) {
                withContext(Dispatchers.Main) {
                    packPushing = false
                    packStatus = "Nothing to send. Unzip the pack and pick the files inside, not the zip."
                }
                return@launch
            }
            var ok = 0
            var failed = 0
            var lastError = ""
            var stopped = false
            val waiting = mutableListOf<SpaceSlot>()
            targets.forEachIndexed { index, slot ->
                if (stopped) return@forEachIndexed
                withContext(Dispatchers.Main) {
                    packStatus = "Checking ${slot.label} (${index + 1}/${targets.size})"
                }
                // An update restarts the Space, and a job running there would be lost: hold it back instead.
                if (spaceHasRunningJob(slot)) {
                    waiting += slot
                    return@forEachIndexed
                }
                withContext(Dispatchers.Main) {
                    packStatus = "Updating ${slot.label} (${index + 1}/${targets.size})"
                }
                try {
                    hf.commitSpaceFiles(repoIdOf(slot), blobs)
                    ok++
                } catch (e: Exception) {
                    failed++
                    lastError = e.message?.take(280) ?: "failed"
                    if ((e.message ?: "").contains("HTTP 400")) stopped = true
                }
            }
            if (stopped) waiting.clear()
            runCatching { savePending(blobs, waiting) }
            withContext(Dispatchers.Main) {
                packPushing = false
                pendingUpdates = waiting.map { it.label }
                val held = if (waiting.isEmpty()) "" else
                    " Waiting for ${waiting.size} busy Space(s) (${waiting.joinToString(", ") { it.label }}): each one updates by itself when its job ends, while Phoenix is open or the next time you open it."
                packStatus = when {
                    stopped && ok == 0 -> "Stopped. Nothing was updated. $lastError"
                    stopped -> "Stopped after $ok updated. $lastError"
                    failed == 0 -> "Updated $ok Spaces. Each one restarts on its own.$held"
                    else -> "Updated $ok, failed $failed. $lastError$held"
                }
            }
            if (waiting.isNotEmpty()) startPendingLoop()
        }
    }

    /**
     * Is a job running on [slot]? The Space's own answer when it has one (v11.2.92+). Otherwise what this phone knows:
     * a job it sent there in the last 36 h that is not finished, confirmed with the Space; no answer counts as running.
     */
    private fun spaceHasRunningJob(slot: SpaceSlot): Boolean {
        hf.spaceBusy(slot.url)?.let { return it }
        val base = slot.url.trim().trimEnd('/')
        val since = System.currentTimeMillis() - 36L * 3600_000L
        val finished = setOf("Done", "Failed", "Monitoring stopped", "Replaced", "On server", "Downloading", "Cancelled")
        return history.filter {
            it.spaceUrl.trim().trimEnd('/') == base && !it.remoteJobId.isNullOrBlank() &&
                it.status !in finished && it.createdAt >= since
        }.any { hf.jobRunningOnSpace(base, it.remoteJobId!!) != false }
    }

    private val pendingDir: File get() = File(getApplication<Application>().filesDir, "pending_pack")

    /** Keep the pack and the Spaces still to update on the phone, so the wait survives the app being closed. */
    private fun savePending(blobs: List<Pair<String, ByteArray>>, waiting: List<SpaceSlot>) {
        val dir = pendingDir
        dir.deleteRecursively()
        if (waiting.isEmpty()) return
        val files = File(dir, "files").apply { mkdirs() }
        blobs.forEach { (name, bytes) -> File(files, name.substringAfterLast('/')).writeBytes(bytes) }
        val arr = JSONArray()
        waiting.forEach { arr.put(JSONObject().put("label", it.label).put("url", it.url)) }
        File(dir, "targets.json").writeText(arr.toString())
    }

    private fun loadPending(): Pair<List<Pair<String, ByteArray>>, List<SpaceSlot>>? {
        val t = File(pendingDir, "targets.json")
        val files = File(pendingDir, "files").listFiles()?.filter { it.isFile }.orEmpty()
        if (!t.isFile || files.isEmpty()) return null
        val arr = JSONArray(t.readText())
        val targets = (0 until arr.length()).mapNotNull { i ->
            arr.optJSONObject(i)?.let { SpaceSlot(it.optString("label"), it.optString("url")) }
        }.filter { it.url.isNotBlank() && it.label.isNotBlank() }
        return files.sortedBy { it.name }.map { it.name to it.readBytes() } to targets
    }

    /** Every 2 minutes: update each waiting Space whose job has ended. Gives a Space up after 5 failed commits. */
    private fun startPendingLoop() {
        if (pendingLoop?.isActive == true || safeMode) return
        pendingLoop = viewModelScope.launch(guard + Dispatchers.IO) {
            val failures = mutableMapOf<String, Int>()
            while (true) {
                val pending = runCatching { loadPending() }.getOrNull()
                if (pending == null || pending.second.isEmpty()) {
                    runCatching { pendingDir.deleteRecursively() }
                    withContext(Dispatchers.Main) { pendingUpdates = emptyList() }
                    break
                }
                val (blobs, targets) = pending
                val left = mutableListOf<SpaceSlot>()
                val updated = mutableListOf<String>()
                var lastError = ""
                for (slot in targets) {
                    if (runCatching { spaceHasRunningJob(slot) }.getOrDefault(true)) { left += slot; continue }
                    try {
                        hf.commitSpaceFiles(repoIdOf(slot), blobs)
                        updated += slot.label
                    } catch (e: Exception) {
                        lastError = e.message?.take(200) ?: "failed"
                        val n = (failures[slot.label] ?: 0) + 1
                        failures[slot.label] = n
                        if (n < 5) left += slot
                    }
                }
                runCatching { savePending(blobs, left) }
                withContext(Dispatchers.Main) {
                    pendingUpdates = left.map { it.label }
                    if (updated.isNotEmpty() || lastError.isNotBlank()) {
                        packStatus = buildString {
                            if (updated.isNotEmpty()) append("Updated ${updated.joinToString(", ")} after its job ended. ")
                            if (lastError.isNotBlank()) append("Update failed: $lastError. ")
                            if (left.isNotEmpty()) append("Still waiting: ${left.joinToString(", ") { it.label }}.")
                        }.trim()
                    }
                }
                if (left.isEmpty()) break
                delay(120_000L)
            }
        }
    }

    /** Drop the held-back updates (the busy Spaces keep their current version). */
    fun cancelPendingUpdates() {
        pendingLoop?.cancel()
        pendingLoop = null
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { pendingDir.deleteRecursively() }
            withContext(Dispatchers.Main) {
                pendingUpdates = emptyList()
                packStatus = "Waiting updates cancelled. Those Spaces keep their current version."
            }
        }
    }

    private fun repoIdOf(slot: SpaceSlot): String {
        val host = slot.url.trim()
            .removePrefix("https://")
            .removePrefix("http://")
            .substringBefore('/')
            .lowercase()
        val sub = host.removeSuffix(".hf.space")
        val repo = slot.label.trim().lowercase().replace(' ', '-').replace('_', '-')
        val owner = if (repo.isNotBlank() && sub.endsWith("-$repo")) {
            sub.removeSuffix("-$repo")
        } else {
            sub.substringBefore('-')
        }
        if (owner.isBlank() || slot.label.isBlank()) {
            throw IllegalStateException("Cannot read a Space name from ${slot.label}")
        }
        return "$owner/${slot.label.trim()}"
    }

    fun discoverSpace() {
        val url = spaceUrl.trim()
        if (url.isBlank()) { status = "Enter the Hugging Face Space URL"; return }
        viewModelScope.launch(guard + Dispatchers.IO) {
            val settings = HfSettings(url.trim().trimEnd('/'), endpoint.trim().ifBlank { DEFAULT_ENDPOINT }, modelRepo, modelRevision)
            runCatching { hf.discoverSpace(settings) }
                .onSuccess { json -> discoveredApi = json; status = "Space reachable · API route probing enabled" }
                .onFailure { status = "API connection failed: ${it.message ?: it.javaClass.simpleName}" }
        }
    }

    /**
     * Named Gradio routes this client cannot work without. If the Space does not
     * publish one of these, every call to it returns HTTP 404 and the feature
     * fails with a message that says nothing useful on its own.
     */
    val requiredEndpoints: List<String> = listOf(
        "phoenix_submit_video",
        "phoenix_job_status",
        "phoenix_download",
        "phoenix_detect_video_frame",
        "detect_image",
        "swap_image"
    )

    var spaceEndpoints by mutableStateOf<List<String>>(emptyList()); private set
    var spaceSignatures by mutableStateOf<Map<String, String>>(emptyMap()); private set

    /** What this client actually sends, for side-by-side comparison. */
    val clientSignatures: Map<String, String> = mapOf(
        "phoenix_detect_video_frame" to "2 in (video FileData, frame percent)",
        "detect_image" to "1 in (image FileData)",
        "swap_image" to "7 in (target, face1-4, quality, reserved)",
        "phoenix_submit_video" to "6 in (video, face1-4, options JSON)",
        "phoenix_job_status" to "1 in (job id)",
        "phoenix_download" to "1 in (job id)",
        "phoenix_patch_preview" to "2 in (frame FileData, mask FileData)",
        "phoenix_skin_preview" to "2 in (video FileData, settings JSON)",
        "phoenix_clean_belly_preview" to "2 in (frame FileData, settings JSON)"
    )
    var diagnosing by mutableStateOf(false); private set
    var lastError by mutableStateOf<String?>(null); private set

    val missingEndpoints: List<String>
        get() = if (spaceEndpoints.isEmpty()) emptyList()
        else requiredEndpoints.filterNot { spaceEndpoints.contains(it) }

    fun diagnoseSpace() {
        val url = spaceUrl.trim()
        if (url.isBlank()) { status = "Enter the Hugging Face Space URL first"; return }
        if (diagnosing) return
        diagnosing = true
        status = "Reading the API description from ${spaceLabel}…"
        viewModelScope.launch(guard + Dispatchers.IO) {
            try {
                val found = hf.listEndpoints(settings())
                spaceEndpoints = found
                spaceSignatures = runCatching { hf.endpointSignatures(settings()) }.getOrDefault(emptyMap())
                val missing = requiredEndpoints.filterNot { found.contains(it) }
                status = when {
                    found.isEmpty() ->
                        "${spaceLabel} answered but published no named API routes. The Space app needs api_name= on its functions."
                    missing.isEmpty() ->
                        "${spaceLabel} exposes all ${requiredEndpoints.size} required routes."
                    else ->
                        "${spaceLabel} is missing ${missing.size} required route(s): ${missing.joinToString(", ")}"
                }
                lastError = null
            } catch (e: Throwable) {
                spaceEndpoints = emptyList()
                spaceSignatures = emptyMap()
                lastError = e.message ?: e.javaClass.simpleName
                status = "Diagnosis failed: ${lastError}"
            } finally {
                diagnosing = false
            }
        }
    }

    fun clearError() { lastError = null }

    fun updateFrame(value: Int) { framePercent = value.coerceIn(0, 100) }
    fun updateOptions(transform: (PhoenixOptions) -> PhoenixOptions) { options = transform(options) }
    fun resetOptions() { options = PhoenixOptions(); _imageQuality = "Best"; status = "Controls reset to recommended defaults" }

    fun detectFrame() {
        val uri = selectedVideo ?: run { status = "Select a target video first"; return }
        if (detectingFrame) return
        detectingFrame = true; lastError = null; status = "Uploading frame source and detecting faces…"
        viewModelScope.launch(guard + Dispatchers.IO) {
            try {
                val settings = settings()
                status = "Waking $spaceLabel…"
                hf.wakeSpace(settings) { msg -> status = "$spaceLabel · $msg" }
                val alreadyCached = videoUploadCache.containsKey(
                    videoCacheKey(settings, uri, options.trimStart, options.trimEnd)
                )
                status = if (alreadyCached) "Detecting faces (video already on ${spaceLabel})…" else "Uploading video and detecting faces…"
                val videoPath = uploadVideoOnce(settings, uri).path
                val detection = hf.detectVideoFrameFaces(settings, videoPath, framePercent)

                // Each crop is downloaded independently and kept at its own
                // index (2 detected faces on a 4-slot form stay in slots 1-2,
                // never shifted by a missing/null crop elsewhere).
                val annotated = detection.annotatedPath?.let { downloadToCache(settings, it, "frame") }
                val faces = detection.facePaths.mapIndexed { i, path ->
                    path?.let { runCatching { downloadToCache(settings, it, "detected_${i + 1}") }.getOrNull() }
                }

                detectedFrameUri?.let { safeDelete(it) }
                detectedFaces.forEach { safeDelete(it) }
                detectedFrameUri = annotated?.let(Uri::fromFile)
                detectedFaces = (faces.map { it?.let(Uri::fromFile) } + List(4 - faces.size) { null }).take(4)
                detectedSex = parseSex(detection.message)

                val count = detectedFaces.count { it != null }
                status = detection.message?.let { "$it (frame $framePercent%)" }
                    ?: if (count > 0) "Detected $count face(s) at $framePercent%"
                    else "Frame returned, but no faces were detected. Try a frame where the face is clearly visible."
            } catch (e: Throwable) {
                val detail = e.message ?: e.javaClass.simpleName
                lastError = when {
                    // A download 404 means the route ran and returned a real
                    // result - it is not missing. Reporting it as "route
                    // missing" here was actively wrong, not just unhelpful.
                    detail.contains("Output download failed") ->
                        "phoenix_detect_video_frame ran and returned a result, but downloading the returned file from " +
                            "${spaceLabel} failed ($detail). If this repeats after updating the app, the Space's /file= " +
                            "route may be rejecting the path it returned."
                    detail.contains("404") && (detail.contains("Queue request failed") || detail.contains("Polling failed")) ->
                        "The Space did not answer on phoenix_detect_video_frame (HTTP 404). " +
                            "That named route is missing from ${spaceLabel}. Run Diagnose Space to see what it does publish."
                    else -> detail
                }
                status = "Frame detection failed: $detail"
            }
            finally { detectingFrame = false }
        }
    }


    fun detectImage() {
        val uri = selectedImage ?: run { status = "Select a target image first"; return }
        if (detectingImage) return
        detectingImage = true; lastError = null; status = "Uploading target image and detecting faces…"
        viewModelScope.launch(guard + Dispatchers.IO) {
            try {
                val settings = settings()
                val file = LocalFileBridge.copyToCache(getApplication(), uri, "phoenix_target_image")
                val paths = hf.detectImage(settings, file)
                safeDelete(file)
                val faces = paths.drop(3).take(4).mapIndexed { i, p ->
                    p?.let { runCatching { downloadToCache(settings, it, "image_detected_${i + 1}") }.getOrNull() }
                }
                detectedFaces.forEach { safeDelete(it) }
                detectedFaces = (faces.map { it?.let(Uri::fromFile) } + List(4 - faces.size) { null }).take(4)
                status = paths.getOrNull(1) ?: "Detected ${detectedFaces.count { it != null }} face(s)"
            } catch (e: Throwable) {
                val detail = e.message ?: e.javaClass.simpleName
                lastError = when {
                    detail.contains("Output download failed") ->
                        "detect_image ran and returned a result, but downloading the returned file from " +
                            "${spaceLabel} failed ($detail)."
                    detail.contains("404") && (detail.contains("Queue request failed") || detail.contains("Polling failed")) ->
                        "The Space did not answer on detect_image (HTTP 404). That named route is missing from ${spaceLabel}."
                    else -> detail
                }
                status = "Image detection failed: $detail"
            }
            finally { detectingImage = false }
        }
    }

    fun captureDetectedFace(slot: Int) {
        detectedFaces.getOrNull(slot - 1)?.let { setFace(slot, it); status = "Detected face captured into replacement slot #$slot" }
            ?: run { status = "No detected face in slot #$slot" }
    }

    /**
     * Send detected face [detectedIndex] (0-based, as shown in the Detected
     * faces strip) into replacement slot [slot] (1-based).
     *
     * Unlike [captureDetectedFace], the source index and the destination slot
     * are independent. That is what makes multi-frame capture possible: scrub
     * to a frame where only person A is visible, send the single detected face
     * to slot #1; scrub to a different frame showing person B, and send that
     * frame's single detected face to slot #2. Neither frame has to contain
     * both people at once.
     */
    fun captureDetectedFaceTo(detectedIndex: Int, slot: Int) {
        if (slot !in 1..4) { status = "Invalid replacement slot #$slot"; return }
        val uri = detectedFaces.getOrNull(detectedIndex)
        if (uri == null) { status = "No detected face at position #${detectedIndex + 1}"; return }

        // Take an independent copy rather than aliasing the detected-crop Uri.
        // detectFrame() safeDelete()s every entry in detectedFaces before it
        // repopulates them, so a slot pointing straight at a detected crop
        // would silently go dangling the next time the user scrubs and
        // re-detects - which is precisely the multi-frame flow this exists to
        // support. Owning a private copy makes the slot survive re-detection.
        val copied = copyToSlotFile(uri, slot)
        if (copied == null) { status = "Could not copy detected face into slot #$slot"; return }
        val refCopy = runCatching {
            val dest = File(getApplication<Application>().cacheDir, "phoenix_tref${slot}_${System.currentTimeMillis()}")
            copied.copyTo(dest, overwrite = true)
            dest
        }.getOrNull()
        if (refCopy != null) {
            targetRefs[slot - 1]?.takeIf { it.scheme == "file" }?.path?.let { runCatching { File(it).delete() } }
            targetRefs[slot - 1] = Uri.fromFile(refCopy)
        }
        val already = when (slot) { 1 -> face1; 2 -> face2; 3 -> face3; else -> face4 }
        if (already == null) setFace(slot, Uri.fromFile(copied))
        val sex = detectedSex.getOrNull(detectedIndex)
        slotSex = slotSex.toMutableList().also { it[slot - 1] = sex }
        slotFromDetect = slotFromDetect.toMutableList().also { it[slot - 1] = detectedIndex }
        val letter = if (sex == 0) "F" else if (sex == 1) "M" else "?"
        status = "Identity for slot #$slot locked from this frame ($letter). Replacement photo stays in the slot."
    }

    /** The letter under a detected face. Tap again if the detector chose the wrong one. */
    fun flipDetectedSex(index: Int) {
        val cur = detectedSex.getOrNull(index) ?: return
        val next = if (cur == 0) 1 else 0
        detectedSex = detectedSex.toMutableList().also { it[index] = next }
        slotSex = slotSex.mapIndexed { i, g -> if (slotFromDetect.getOrNull(i) == index) next else g }
        status = "Face #${index + 1} set to ${if (next == 0) "F" else "M"}. Send it to that person's slot so the job keeps it."
    }

    private fun parseSex(message: String?): List<Int?> {
        val raw = Regex("sex=([MFmf?,\\-]+)").find(message ?: "")?.groupValues?.getOrNull(1) ?: return listOf(null, null, null, null)
        if (raw == "-") return listOf(null, null, null, null)
        val parts = raw.split(",")
        return (0..3).map { i ->
            when (parts.getOrNull(i)?.uppercase()) {
                "F" -> 0
                "M" -> 1
                else -> null
            }
        }
    }

    /** Copies a file:// crop into a slot-owned cache file. Returns null on failure. */
    private fun copyToSlotFile(src: Uri, slot: Int): File? {
        val srcPath = src.takeIf { it.scheme == "file" }?.path ?: return null
        val srcFile = File(srcPath)
        if (!srcFile.exists()) return null
        return runCatching {
            val dest = File(
                getApplication<Application>().cacheDir,
                "phoenix_slot${slot}_${System.currentTimeMillis()}"
            )
            srcFile.copyTo(dest, overwrite = true)
            dest
        }.getOrNull()
    }

    fun installModels() {
        viewModelScope.launch(guard + Dispatchers.IO) {
            status = "Downloading verified model pack…"
            runCatching { models.installFromHf(HfSettings(spaceUrl, endpoint, modelRepo, modelRevision)) { name, done, total -> progress = if (total > 0) done.toFloat() / total else 0f; status = "Downloading $name · ${(progress * 100).toInt()}%" } }
                .onSuccess { modelReady = models.isComplete(); progress = 1f; status = "Model pack installed and hash-verified" }
                .onFailure { status = "Model install failed: ${it.message ?: it.javaClass.simpleName}" }
        }
    }

    fun startProcessing() {
        if (appMode == AppMode.LOCAL) {
            if (running) { status = "A local job is already running"; return }
            startLocal(selectedVideo)
        } else if (activeTab == "Image") {
            startImage()
        } else {
            if (parallelJobs.size >= MAX_SPACES) {
                status = "All $MAX_SPACES Phoenix jobs are already being monitored. Use History to track them."
                return
            }
            val uri = selectedVideo ?: run { status = "Select a target video first"; return }
            val parts = options.splitParts.substringBefore(" ").toIntOrNull()?.takeIf { it in 2..10 } ?: 1
            status = "Looking for idle Spaces…"
            viewModelScope.launch(guard + Dispatchers.IO) {
                try {
                    val idle = idleSpaces()
                    if (idle.isEmpty()) {
                        status = "Every Space is busy. Wait for one to finish, or stop a job in History."
                        return@launch
                    }
                    if (parts == 1) {
                        startOnIdleSpace(uri, idle)
                    } else {
                        startSplitFarm(uri, parts, idle)
                    }
                } catch (e: kotlinx.coroutines.CancellationException) {
                    throw e
                } catch (e: Throwable) {
                    status = "Could not start: ${e.message ?: e.javaClass.simpleName}"
                }
            }
        }
    }

    private fun startLocal(uri: Uri?) {
        if (uri == null) { status = "Select a target video first"; return }
        if (!modelReady) { status = "Install the verified local model pack first"; return }
        running = true
        processingJob = viewModelScope.launch(guard + Dispatchers.Default) {
            runCatching { local.initialize() }
                .onSuccess { info ->
                    status = "$info · ${local.engineStatus()}"
                    if (!local.processingReady()) {
                        status = "Local face engine is not available in this release. No video was modified."
                    }
                }
                .onFailure { status = "Local model initialization failed: ${it.message ?: it.javaClass.simpleName}" }
            running = false
        }
    }

    private fun settings() = selectedSettings()

    private fun startImage() {
        val uri = selectedImage ?: run { status = "Select a target image first"; return }
        val faces = listOf(face1, face2, face3, face4)
        if (faces.all { it == null }) { status = "Select or capture at least one replacement face"; return }
        running = true; progress = 0f; imageResultUri = null; status = "Preparing image upload…"
        processingJob = viewModelScope.launch(guard + Dispatchers.IO) {
            try {
                val s = settings(); hf.discoverSpace(s)
                val target = LocalFileBridge.copyToCache(getApplication(), uri, "phoenix_image")
                val sourceFiles = faces.mapIndexed { i, f -> f?.let { LocalFileBridge.copyToCache(getApplication(), it, "phoenix_image_face_${i + 1}") } }
                progress = .15f; status = "Processing image…"
                val path = uploadGate(s).withPermit { hf.swapImage(s, target, sourceFiles, imageQuality) } ?: throw IllegalStateException("Phoenix returned no image")
                safeDelete(target)
                sourceFiles.forEach { safeDelete(it) }
                val output = downloadToCache(s, path, "phoenix_image_result")
                val published = publishImageResult(output, "Phoenix_Image_${System.currentTimeMillis()}.jpg")
                safeDelete(output)
                imageResultUri = published; progress = 1f; eta = "Done"; status = "Complete — image saved to Pictures/Phoenix"
                addHistory(HistoryItem("IMG-${System.currentTimeMillis()}", "Image", "Phoenix image result", published.toString(), "Done", System.currentTimeMillis(), spaceLabel, s.spaceUrl))
            } catch (e: Throwable) {
                lastError = e.message ?: e.javaClass.simpleName
                status = "Image processing failed: ${lastError}"
            }
            finally { running = false }
        }
    }

    /**
     * Long-running cloud jobs must not depend on the Activity remaining in the
     * foreground. A lightweight foreground service keeps this process alive
     * while the ViewModel polls the remote job and downloads the final file.
     * The server-side render itself continues independently on Hugging Face.
     */
    /**
     * The keep-alive foreground service is deliberately NOT started any more.
     * On this phone, starting it when the app went to the background made the
     * app vanish with no message, again and again (1.2.19). The render runs on
     * the Space, not in the app, so a job is not lost when the app is closed:
     * opening the app again reconnects to every tracked job (resumeTrackedJobs),
     * and the Space's own page lists finished jobs as well.
     * stopBackgroundGuardIfIdle() below still stops a service left over from an
     * older install.
     */
    private fun startBackgroundGuard() {
        // intentionally empty
    }

    private fun stopBackgroundGuardIfIdle() {
        if (parallelJobs.isEmpty() && activeTransfers.get() == 0) {
            runCatching {
                getApplication<Application>().stopService(
                    Intent(getApplication<Application>(), PhoenixKeepAliveService::class.java)
                )
            }
        }
    }

    fun splitFaceModeAt(index: Int): String = when (index) {
        0 -> options.splitFaceMode1
        1 -> options.splitFaceMode2
        2 -> options.splitFaceMode3
        3 -> options.splitFaceMode4
        4 -> options.splitFaceMode5
        5 -> options.splitFaceMode6
        6 -> options.splitFaceMode7
        7 -> options.splitFaceMode8
        8 -> options.splitFaceMode9
        9 -> options.splitFaceMode10
        else -> options.faceMode
    }

    fun setSplitFaceMode(index: Int, value: String) {
        updateOptions { o ->
            when (index) {
                0 -> o.copy(splitFaceMode1 = value)
                1 -> o.copy(splitFaceMode2 = value)
                2 -> o.copy(splitFaceMode3 = value)
                3 -> o.copy(splitFaceMode4 = value)
                4 -> o.copy(splitFaceMode5 = value)
                5 -> o.copy(splitFaceMode6 = value)
                6 -> o.copy(splitFaceMode7 = value)
                7 -> o.copy(splitFaceMode8 = value)
                8 -> o.copy(splitFaceMode9 = value)
                9 -> o.copy(splitFaceMode10 = value)
                else -> o
            }
        }
    }

    private fun splitFaceMode(index: Int): String = splitFaceModeAt(index)

    /** One job on the selected Space if it is idle, else on the first idle one (1.2.29: a second job no longer goes to a
     *  Space that is already working on a part of the first). */
    private fun startOnIdleSpace(uri: Uri, idle: List<SpaceSlot>) {
        val sel = normUrl(spaceUrl)
        val slot = idle.firstOrNull { normUrl(it.url) == sel } ?: idle.first()
        if (normUrl(slot.url) != sel) status = "$spaceLabel is busy - using ${slot.label}"
        startRemote(
            uri,
            space = HfSettings(normUrl(slot.url), endpoint.trim().ifBlank { DEFAULT_ENDPOINT }, modelRepo, modelRevision),
            label = slot.label
        )
    }

    private fun startSplitFarm(uri: Uri, wanted: Int, idle: List<SpaceSlot>) {
        var parts = wanted
        if (idle.size < parts) {
            // 1.2.29: split as far as there are idle Spaces instead of refusing
            if (idle.size < 2) { startOnIdleSpace(uri, idle); return }
            parts = idle.size
            status = "Only ${idle.size} Spaces are idle - splitting into $parts parts instead of $wanted."
        }
        val faces = listOf(face1, face2, face3, face4)
        if (faces.all { it == null }) { status = "Select or capture at least one replacement face"; return }
        val free = idle.take(parts)
        free.forEach { reservedUrls.add(normUrl(it.url)) }       // held for this split until each part has started
        val groupId = "SPLIT-${UUID.randomUUID().toString().take(8)}"
        val winStart = options.trimStart.coerceIn(0, 99)
        val winEnd = options.trimEnd.coerceIn(winStart + 1, 100)
        val span = winEnd - winStart
        setFarm("Split", 1)
        viewModelScope.launch(guard + Dispatchers.IO) {
          try {
            val app = getApplication<Application>()
            val totalUs = VideoTrimmer.durationUs(app, uri) ?: 0L
            for (i in 0 until parts) {
                val startPct = winStart + span * i / parts
                val endPct = if (i == parts - 1) winEnd else winStart + span * (i + 1) / parts
                if (endPct <= startPct) continue
                var partUri = uri
                var sendStart = startPct
                var sendEnd = endPct
                var partSecs = options.durationSec
                if (totalUs > 0L) {
                    val startUs = totalUs * startPct / 100L
                    val endUs = totalUs * endPct / 100L
                    partSecs = (((endUs - startUs) / 1_000_000L).toInt() + 3).coerceIn(10, 360)
                    setFarm("Split ${i + 1}/$parts", ((i) * 18 / parts).coerceAtLeast(2))
                    val dest = File(app.cacheDir, "phoenix_part_${groupId}_$i.mp4")
                    val cut = VideoTrimmer.trim(app, uri, startUs, endUs, dest)
                    if (cut != null && cut.file.exists() && cut.durationUs > 0L) {
                        partUri = Uri.fromFile(cut.file)
                        sendStart = ((cut.residualStartUs * 100.0) / cut.durationUs).toInt().coerceIn(0, 5)
                        sendEnd = 100
                        partSecs = ((cut.durationUs / 1_000_000L).toInt() + 3).coerceIn(10, 360)
                    }
                }
                val slot = free[i]
                val mode = if (options.splitSharedSettings) options.faceMode else splitFaceMode(i)
                setFarm("Upload ${i + 1}/$parts → ${slot.label}", 18 + (i * 20 / parts))
                startRemote(
                    partUri,
                    space = HfSettings(slot.url.trim().trimEnd('/'), endpoint.trim().ifBlank { DEFAULT_ENDPOINT }, modelRepo, modelRevision),
                    label = slot.label,
                    trimStart = sendStart,
                    trimEnd = sendEnd,
                    faceMode = mode,
                    groupId = groupId,
                    partIndex = i,
                    partCount = parts,
                    durationSec = partSecs,
                    origUri = uri.toString(),
                    origStartPct = startPct,
                    origEndPct = endPct
                )
                reservedUrls.remove(normUrl(slot.url))           // this part is now a live job: its Space counts as busy by itself
            }
          } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
          } catch (e: Throwable) {
            status = "Split stopped before upload: ${e.message ?: e.javaClass.simpleName}"
          } finally {
            free.forEach { reservedUrls.remove(normUrl(it.url)) }
          }
        }
    }

    fun mergeableGroupId(): String? {
        val groups = history.mapNotNull { it.groupId }.distinct()
        return groups.firstOrNull { gid ->
            val parts = history.filter { it.groupId == gid }
            val n = parts.maxOfOrNull { it.partCount } ?: 0
            n >= 2 && parts.count { it.status == "Done" && !it.uri.isNullOrBlank() } >= n &&
                history.none { it.groupId == gid && it.kind == "Merged" && it.status == "Done" }
        }
    }

    fun mergeSplitGroup(groupId: String? = mergeableGroupId()) {
        val gid = groupId ?: run { status = "No completed split group to merge"; return }
        val parts = history.filter { it.groupId == gid && it.kind == "Video" }
            .sortedBy { it.partIndex }
        val n = parts.maxOfOrNull { it.partCount } ?: 0
        val ready = parts.filter { it.status == "Done" && !it.uri.isNullOrBlank() }
        if (n < 2 || ready.size < n) {
            status = "Merge waits for all $n parts. ${ready.size} ready."
            return
        }
        viewModelScope.launch(guard + Dispatchers.IO) {
            try {
                setFarm("Merge", 90)
                val dest = File(getApplication<Application>().cacheDir, "phoenix_merge_${System.currentTimeMillis()}.mp4")
                val ok = VideoConcat.concat(getApplication(), ready.map { Uri.parse(it.uri) }, dest) { done, total ->
                    val pct = 90 + ((done * 9) / total.coerceAtLeast(1))
                    setFarm("Merge $done/$total", pct)
                }
                if (!ok) {
                    setFarm("Merge failed", farmPercent)
                    status = "Merge failed — parts may differ in codec. Save parts from History and join in an editor."
                    return@launch
                }
                val published = publishResult(dest, "Phoenix_merged_${gid}.mp4")
                safeDelete(dest)
                resultUri = published
                addHistory(
                    HistoryItem(
                        "MERGE-${System.currentTimeMillis()}", "Merged", "Phoenix_merged_${gid}.mp4",
                        published.toString(), "Done", System.currentTimeMillis(),
                        "Merged", "", null, 1f, "Done", gid, 0, n
                    )
                )
                setFarm("Merge done", 100)
                status = "Merged $n parts → Movies/Phoenix"
                toast("Merged video saved to Movies/Phoenix")
            } catch (e: Throwable) {
                status = "Merge failed: ${e.message ?: e.javaClass.simpleName}"
            }
        }
    }

    private fun startRemote(
        uri: Uri,
        space: HfSettings = selectedSettings(),
        label: String = spaceLabel,
        trimStart: Int = options.trimStart,
        trimEnd: Int = options.trimEnd,
        faceMode: String = options.faceMode,
        groupId: String? = null,
        partIndex: Int = 0,
        partCount: Int = 1,
        durationSec: Int = options.durationSec,
        origUri: String? = null,
        origStartPct: Int = -1,
        origEndPct: Int = -1
    ) {
        val targetSpace = space
        if (targetSpace.spaceUrl.isBlank()) { status = "Configure the selected Phoenix Space first"; return }
        if (parallelJobs.size >= MAX_SPACES) { status = "All $MAX_SPACES Phoenix jobs are already active"; return }
        val faces = listOf(face1, face2, face3, face4)
        if (faces.all { it == null }) { status = "Select or capture at least one replacement face"; return }
        val localId = "JOB-${UUID.randomUUID()}"
        val created = System.currentTimeMillis()
        latestJobLocalId = localId
        val partTag = if (partCount > 1) " · part ${partIndex + 1}/$partCount ${trimStart}-${trimEnd}%" else ""
        val sourcePath = if (uri.scheme == "file") uri.path else null
        addHistory(HistoryItem(localId, "Video", "Phoenix job — $label$partTag", null, "Starting", created, label, targetSpace.spaceUrl, null, 0f, "ETA —", groupId, partIndex, partCount, sourcePath,
            origUri = origUri, origStartPct = origStartPct, origEndPct = origEndPct))
        val controlJob = Job()
        parallelJobs[localId] = controlJob
        val job = viewModelScope.launch(guard + controlJob + Dispatchers.IO) {
            try {
            var wakeTries = 0
            var stallTries = 0
            while (true) {
            try {
                val cur = history.find { it.id == localId }?.status
                if (cur.isNullOrBlank() || cur == "Starting") {
                    updateHistory(localId, status = "Connecting", progress = .01f, eta = "Checking Space…")
                }
                updateHistory(localId, status = "Waking Space", progress = .01f, eta = "Waking $label…")
                status = "Waking $label…"
                hf.wakeSpace(targetSpace) { msg ->
                    updateHistory(localId, status = "Waking Space", eta = msg)
                    status = "$label · $msg"
                }
                hf.discoverSpace(targetSpace)
                val alreadyCached = videoUploadCache.containsKey(videoCacheKey(targetSpace, uri, trimStart, trimEnd))
                // 1.2.59: a part waiting for an upload slot says so, with its place in the queue (it used to read
                // "Uploading video 2 %" the whole time, which looked stuck)
                if (!alreadyCached) {
                    uploadQueue.add(localId)
                    updateHistory(localId, status = "Waiting to upload", progress = .02f)
                    refreshUploadQueue()
                }
                val videoUpload = try { videoUploadSlots.withPermit {
                    if (uploadQueue.remove(localId)) refreshUploadQueue()
                    updateHistory(localId, status = if (alreadyCached) "Reusing upload" else "Uploading video", progress = .02f,
                        eta = if (alreadyCached) "Video already on Space…" else if (stallTries > 0) "Resuming the upload…" else "Starting the upload…")
                    uploadVideoOnce(targetSpace, uri, trimStart, trimEnd) { written, total ->
                    if (total > 0) {
                        val pct = (written.toFloat() / total).coerceIn(0f, 1f)
                        val doneMb = "%.1f".format(written / 1_048_576.0)
                        val totalMb = "%.1f".format(total / 1_048_576.0)
                        val jobPct = (pct * 100).toInt()
                        updateHistory(localId, progress = pct * 0.35f, eta = "Upload $jobPct% · $doneMb / $totalMb MB", detail = "Upload $jobPct% · $doneMb / $totalMb MB")
                        if (partCount > 1) {
                            val base = 18 + (partIndex * 30 / partCount)
                            setFarm("Upload ${partIndex + 1}/$partCount", base + (jobPct * 30 / partCount / 100))
                        } else {
                            setFarm("Upload", (jobPct * 40 / 100).coerceAtLeast(1))
                        }
                    }
                    }
                } } finally {
                    if (uploadQueue.remove(localId)) refreshUploadQueue()
                }
                // 1.2.57: the part clip is KEPT until this part is done (updateHistory deletes it then). It used to be
                // deleted right after the upload, so a part the Space lost later could not be redone.
                updateHistory(localId, status = "Uploading faces", progress = .04f, eta = "Uploading…")
                // Face uploads are independent. Upload up to three at once; the
                // per-Space semaphore prevents this from overwhelming a Space.
                val uploaded = arrayOfNulls<String>(4)
                val faceJobs = faces.mapIndexedNotNull { i, faceUri ->
                    faceUri?.let { uriFace ->
                        async(Dispatchers.IO) {
                            val mimeFace = getApplication<Application>().contentResolver.getType(uriFace) ?: "image/jpeg"
                            uploaded[i] = uploadGate(targetSpace).withPermit {
                                hf.uploadUri(
                                    targetSpace, getApplication<Application>().contentResolver, uriFace,
                                    "phoenix_face_${localId}_${i + 1}.jpg", mimeFace
                                )
                            }
                        }
                    }
                }
                faceJobs.awaitAll()
                val uploadedRefs = arrayOfNulls<String>(4)
                val refJobs = targetRefs.mapIndexedNotNull { i, refUri ->
                    refUri?.let { uriRef ->
                        async(Dispatchers.IO) {
                            val mimeRef = getApplication<Application>().contentResolver.getType(uriRef) ?: "image/jpeg"
                            uploadedRefs[i] = uploadGate(targetSpace).withPermit {
                                hf.uploadUri(
                                    targetSpace, getApplication<Application>().contentResolver, uriRef,
                                    "phoenix_tref_${localId}_${i + 1}.jpg", mimeRef
                                )
                            }
                        }
                    }
                }
                refJobs.awaitAll()
                updateHistory(localId, status = "Uploading faces", progress = .10f, eta = "Ready to submit")
                // phoenix_submit_video's 6th input is a Textbox (confirmed via
                // Diagnose Space), not a JSON-object-typed input. Putting the
                // JSONObject in directly meant Gradio received an object where
                // it expected a string and stringified it with Python's str(),
                // which produces single-quoted {'key': 'value'} text - exactly
                // what made the server's json.loads() fail with "Expecting
                // property name enclosed in double quotes". Send the actual
                // JSON-encoded string instead.
                val data = JSONArray().put(fileData(videoUpload.path)).put(uploaded[0]?.let(::fileData) ?: JSONObject.NULL)
                    .put(uploaded[1]?.let(::fileData) ?: JSONObject.NULL).put(uploaded[2]?.let(::fileData) ?: JSONObject.NULL)
                    .put(uploaded[3]?.let(::fileData) ?: JSONObject.NULL)
                    .put(optionsJson(videoUpload.trimStartPct, videoUpload.trimEndPct, uploadedRefs, faceMode, durationSec, partIndex, partCount)
                        .also { addPatches(it, videoUpload.offsetUs) }.toString())
                updateHistory(localId, status = "Submitting", progress = .08f, eta = "Queueing…")
                val submitEndpoint = targetSpace.endpoint.ifBlank { DEFAULT_ENDPOINT }
                val submit = hf.callAndWait(targetSpace, submitEndpoint, data, 240_000L)
                val response = submit.optJSONObject(0) ?: throw IllegalStateException("Phoenix returned invalid submit response")
                if (!response.optBoolean("ok", false)) throw IllegalStateException(response.optJSONObject("error")?.optString("message") ?: "Phoenix rejected the job")
                val jobId = response.optString("job_id").takeIf { it.isNotBlank() } ?: throw IllegalStateException("Phoenix returned no job ID")
                updateHistory(localId, name = "Phoenix ${jobId}", status = "Queued", remoteJobId = jobId, progress = .08f, eta = "Queued")
                pollPhoenixJob(targetSpace, jobId, localId)
                break
            } catch (e: kotlinx.coroutines.CancellationException) {
                updateHistory(localId, status = "Monitoring stopped", eta = "Stopped")
                throw e
            } catch (e: Throwable) {
                val existing = history.find { it.id == localId }
                val remoteId = existing?.remoteJobId
                if (!remoteId.isNullOrBlank()) {
                    if (hasInternet()) {
                        updateHistory(localId, eta = "Still watching")
                    } else {
                        updateHistory(localId, eta = "No network — will update when back")
                        status = "No network. Job $remoteId stays ${existing?.status ?: "in progress"}. It will update when the signal returns."
                    }
                    pollPhoenixJob(targetSpace, remoteId, localId)
                    break
                } else if (isUploadStall(e) && stallTries < VIDEO_STALL_TRIES) {
                    // 1.2.59: the Space stopped taking the video. Step out of the upload slot (the other parts go on), wait a
                    // little and try again: the upload resumes at the last byte the Space holds.
                    stallTries++
                    updateHistory(localId, status = "Waiting to upload", eta = "Upload stalled - trying again ($stallTries of $VIDEO_STALL_TRIES)")
                    status = "$spaceLabel stopped taking the video. Trying again ($stallTries of $VIDEO_STALL_TRIES); the other parts go on."
                    if (!hasInternet()) waitForNetwork() else pauseOrWake(20_000L)
                    continue
                } else if (isUploadStall(e)) {
                    lastError = "the upload to $spaceLabel stalled $VIDEO_STALL_TRIES times"
                    updateHistory(localId, status = "Failed", eta = "Upload stalled $VIDEO_STALL_TRIES times - check this Space, then tap Redo part",
                        errorName = "upload stalled")
                    status = "Part on $spaceLabel failed: ${e.message ?: "upload stalled"}. Check the Space, then tap Redo part."
                    break
                } else if (isOffline(e) || !hasInternet()) {
                    val kept = existing?.status?.takeIf { it.isNotBlank() && it != "Failed" } ?: "Uploading video"
                    updateHistory(localId, status = kept, eta = "No network — stays here until the signal is back")
                    status = "No network. This part stays at $kept and continues when the signal returns."
                    waitForNetwork()
                    continue
                } else {
                    val why = e.message ?: e.javaClass.simpleName
                    val waking = why.contains("timed out", ignoreCase = true) ||
                        why.contains("HTTP 502") || why.contains("HTTP 503") || why.contains("HTTP 504") ||
                        why.contains("Queue request failed")
                    if (waking && wakeTries < 3) {
                        wakeTries++
                        updateHistory(localId, status = "Connecting", eta = "Space is waking — try $wakeTries of 3")
                        status = "$spaceLabel is still waking. This part will try again."
                        Thread.sleep(12_000L)
                        continue
                    }
                    lastError = why
                    updateHistory(localId, status = "Failed", eta = "—", errorName = lastError)
                    status = "Job failed on $spaceLabel: ${lastError}"
                    break
                }
            }
            }
        } finally {
            parallelJobs.remove(localId)
            syncRunning()
        }
        }
        syncRunning()
        status = "${spaceLabel}: job started · ${parallelJobs.size}/${MAX_SPACES} active"
    }

    private fun syncRunning() {
        running = parallelJobs.isNotEmpty()
        activeJobCount = parallelJobs.size
        if (!running) stopBackgroundGuardIfIdle()
    }

    fun cancelJob(localId: String) {
        parallelJobs[localId]?.cancel()
        updateHistory(localId, status = "Monitoring stopped", eta = "Stopped")
        status = "Stopped monitoring ${history.find { it.id == localId }?.name ?: "job"}. Remote processing may continue on the Space."
    }

    fun cancelProcessing() {
        latestJobLocalId?.let { cancelJob(it) } ?: run { status = "No active Phoenix job" }
    }

    private suspend fun pollPhoenixJob(s: HfSettings, jobId: String, localId: String) {
        var lastProgress = .08f
        var consecutiveFailures = 0
        var notFound = 0
        var backoffMs = 2500L
        // A poll checking on an already-running job is not the job itself - the
        // remote job keeps processing regardless of whether THIS check-in
        // succeeded. Network loss must NEVER mark the job Failed: the Space
        // keeps the result for 3 hours for a later download.
        while (true) {
            pauseOrWake(backoffMs)
            val r = try {
                val result = hf.callAndWait(s, "phoenix_job_status", JSONArray().put(jobId), 30_000L, allowResubmitOnDeadSession = true)
                consecutiveFailures = 0
                backoffMs = 2500L
                result.optJSONObject(0) ?: throw IllegalStateException("Invalid Phoenix status response")
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Throwable) {
                consecutiveFailures++
                backoffMs = minOf(20_000L, 2_000L * (1L shl minOf(consecutiveFailures, 3)))
                if (hasInternet()) {
                    updateHistory(localId, eta = "Still watching — signal blipped")
                    pauseOrWake(backoffMs.coerceAtMost(4_000L))
                } else {
                    updateHistory(localId, eta = "No network — will update when back")
                    status = "No network. The job stays as it is and will update when the signal returns."
                    waitForNetwork()
                }
                continue
            }
            if (!r.optBoolean("ok", false)) {
                val code = r.optJSONObject("error")?.optString("code").orEmpty()
                val why = r.optJSONObject("error")?.optString("message").orEmpty()
                if (code == "not_found") {
                    notFound++
                    // 1.2.57: the Space answers, but has no such job - after a restart that kept nothing. Waiting
                    // forever helped nobody: after about 3 minutes the card says so and points at Redo part.
                    if (notFound >= 12) {
                        val part = history.find { it.id == localId }?.let { it.partCount > 1 } == true
                        updateHistory(
                            localId,
                            status = "Lost",
                            eta = if (part) "The Space restarted and lost job $jobId. Tap Redo part."
                            else "The Space restarted and lost job $jobId. Send the video again."
                        )
                        status = "Job $jobId is no longer on the Space (it restarted). " +
                            if (part) "Tap Redo part on its card." else "Send the video again."
                        return
                    }
                    updateHistory(
                        localId,
                        status = "On server",
                        eta = "Job $jobId not visible now — still checking ($notFound of 12)"
                    )
                    status = "Job $jobId was not returned. Still checking. It is not failed."
                    delay(15_000L)
                    continue
                }
                notFound = 0
                consecutiveFailures++
                backoffMs = minOf(60_000L, 2500L * (1L shl minOf(consecutiveFailures, 5)))
                updateHistory(
                    localId,
                    eta = "Still checking job $jobId" + if (why.isBlank()) "" else " · ${why.take(80)}"
                )
                status = "Space did not answer for job $jobId. Still watching. ${why}"
                continue
            }
            val state = r.optString("status", "processing")
            val p = r.optInt("progress", -1)
            if (p >= 0) lastProgress = (p.coerceIn(0, 100) / 100f).coerceAtLeast(.08f)
            val etaSeconds = r.optLong("eta_seconds", -1L)
            val etaText = if (etaSeconds >= 0) "ETA ${etaSeconds}s" else "Server processing…"
            val message = r.optString("message", state)
            val frames = frameNote(r, message)
            val detail = if (frames.isBlank()) message else "$message · $frames"
            updateHistory(localId, status = state.replaceFirstChar { it.uppercase() }, progress = lastProgress, eta = etaText, detail = detail)
            status = "${history.find { it.id == localId }?.spaceLabel ?: "Phoenix"}: $message"
            when (state.lowercase()) {
                "done" -> {
                    if (!r.optBoolean("download_ready", false)) throw IllegalStateException("Phoenix completed but no result is ready")
                    val itemNow = history.find { it.id == localId }
                    val resultName = partSaveName(jobId, itemNow?.partIndex ?: 0, itemNow?.partCount ?: 1)
                    val claimed = synchronized(saveLock) {
                        if (alreadySaved(jobId) || jobId in savingJobIds) {
                            false
                        } else {
                            savingJobIds.add(jobId)
                            true
                        }
                    }
                    if (!claimed) {
                        repeat(30) {
                            existingVideoUri(resultName)?.let { resultUri = it; return@repeat }
                            delay(400)
                        }
                        val already = history.find { it.id == localId }?.uri
                        existingVideoUri(resultName)?.let { resultUri = it }
                        updateHistory(localId, name = resultName, uri = already ?: resultUri?.toString(), status = "Done", progress = 1f, eta = "Done")
                        persistHistoryNow()
                        status = "Complete — already saved"
                        return
                    }
                    try {
                    val already = history.find { it.id == localId }?.uri
                    if (!already.isNullOrBlank() || alreadySaved(jobId)) {
                        existingVideoUri(resultName)?.let { resultUri = it }
                        markSaved(jobId)
                        updateHistory(localId, name = resultName, uri = already ?: resultUri?.toString(), status = "Done", progress = 1f, eta = "Done")
                        persistHistoryNow()
                        status = "Complete — already saved"
                        return
                    }
                    existingVideoUri(resultName)?.let { existing ->
                        resultUri = existing
                        markSaved(jobId)
                        updateHistory(localId, name = resultName, uri = existing.toString(), status = "Done", progress = 1f, eta = "Done")
                        persistHistoryNow()
                        status = "Complete — ${history.find { it.id == localId }?.spaceLabel ?: "Phoenix Space"} result saved"
                        return
                    }
                    updateHistory(localId, status = "Downloading", progress = .96f, eta = "Downloading…")

                    // The render itself is already finished server-side at this
                    // point - only the final file fetch remains. A transient
                    // network interruption here ("Software caused connection
                    // abort" is Android suspending a backgrounded app's network
                    // mid-transfer during a long job) should not throw away a
                    // fully completed render just because the last download
                    // attempt hit a blip. Retry this last step, the same way
                    // the status poll above already tolerates one.
                    var lastDownloadError: Throwable? = null
                    var published: Uri? = null
                    var lastProgressPush = 0L
                    for (attempt in 1..12) {
                        try {
                            val download = hf.callAndWait(s, "phoenix_download", JSONArray().put(jobId), 60_000L)
                            val path = extractPath(download) ?: throw IllegalStateException("Phoenix download returned no file")
                            // Real byte-level progress instead of a fixed 96% for
                            // the whole transfer - a large rendered video (easily
                            // 50-300MB) could otherwise sit motionless on screen
                            // for many minutes, indistinguishable from being stuck.
                            val output = downloadToCache(s, path, "phoenix_$jobId") { downloaded, total ->
                                val now = System.currentTimeMillis()
                                if (now - lastProgressPush < 400L && (total <= 0 || downloaded < total)) return@downloadToCache
                                lastProgressPush = now
                                val doneMb = "%.1f".format(downloaded / 1_048_576.0)
                                if (total > 0) {
                                    val pct = (downloaded.toFloat() / total).coerceIn(0f, 1f)
                                    val totalMb = "%.1f".format(total / 1_048_576.0)
                                    updateHistory(localId, progress = 0.96f + pct * 0.03f, eta = "$doneMb / $totalMb MB")
                                    status = "Downloading result — $doneMb of $totalMb MB (${(pct * 100).toInt()}%)"
                                } else {
                                    updateHistory(localId, eta = "$doneMb MB…")
                                    status = "Downloading result — $doneMb MB so far"
                                }
                            }
                            published = publishResult(output, resultName)
                            safeDelete(output)
                            markSaved(jobId)
                            break
                        } catch (e: kotlinx.coroutines.CancellationException) {
                            throw e
                        } catch (e: Throwable) {
                            lastDownloadError = e
                            status = "Render is on the Space — waiting to download (${attempt}/12)…"
                            updateHistory(localId, eta = "No network — download continues when back")
                            delay(4000L * attempt)
                        }
                    }
                    val finalUri = published
                    if (finalUri == null) {
                        lastError = null
                        updateHistory(
                            localId,
                            eta = "Finished on the Space — download continues when the signal is back"
                        )
                        status = "Finished on the Space. Phone was offline. Job $jobId is kept 3 hours — tap Retry download."
                        delay(10_000L)
                        continue
                    }
                    resultUri = finalUri
                    markSaved(jobId)
                    updateHistory(localId, name = resultName, uri = finalUri.toString(), status = "Done", progress = 1f, eta = "Done")
                    persistHistoryNow()
                    status = "Complete — ${history.find { it.id == localId }?.spaceLabel ?: "Phoenix Space"} result saved"
                    val item = history.find { it.id == localId }
                    if (options.autoMergeSplits && item?.groupId != null && mergeableGroupId() == item.groupId) {
                        mergeSplitGroup(item.groupId)
                    }
                    return
                    } finally {
                        synchronized(saveLock) { savingJobIds.remove(jobId) }
                    }
                }
                "error", "failed" -> {
                    val why = r.optString("message").ifBlank { "Phoenix job $state" }
                    lastError = why
                    updateHistory(localId, status = "Failed", eta = why.take(140))
                    status = "Job $jobId failed on the Space: $why"
                    return
                }
                "cancelled" -> {
                    updateHistory(localId, status = "Monitoring stopped", eta = "Cancelled on the Space")
                    status = "Job $jobId was cancelled."
                    return
                }
            }
        }
    }

    private fun updateHistory(
        id: String,
        name: String? = null,
        uri: String? = null,
        status: String? = null,
        remoteJobId: String? = null,
        progress: Float? = null,
        eta: String? = null,
        errorName: String? = null,
        detail: String? = null
    ) {
        synchronized(historyLock) {
            val current = history.find { it.id == id } ?: return
            if (status == "Done") {
                current.sourcePath?.let { File(it) }?.takeIf { it.name.startsWith("phoenix_part_") }?.let { runCatching { it.delete() } }
            }
            val finalName = if (errorName != null) "${current.name} · $errorName" else name ?: current.name
            history = history.map { if (it.id == id) it.copy(
                name = finalName,
                uri = uri ?: it.uri,
                status = status ?: it.status,
                remoteJobId = remoteJobId ?: it.remoteJobId,
                progress = progress ?: it.progress,
                eta = eta ?: it.eta,
                detail = detail ?: it.detail
            ) else it }
            persistHistory()
        }
    }

    private var networkCallback: ConnectivityManager.NetworkCallback? = null

    private fun isOffline(e: Throwable): Boolean {
        var t: Throwable? = e
        while (t != null) {
            if (t is java.io.IOException) return true
            val m = t.message?.lowercase().orEmpty()
            if ("cannot resolve" in m || "could not reach" in m || "unable to resolve" in m ||
                "failed to connect" in m || "timeout" in m || "timed out" in m ||
                "connection abort" in m || "connection reset" in m || "network is unreachable" in m ||
                "stream was reset" in m || "software caused connection abort" in m
            ) return true
            t = t.cause
        }
        return false
    }

    private val wake = MutableSharedFlow<Unit>(extraBufferCapacity = 1)

    /** Called when Phoenix comes back to the screen. Restarts a watcher that
     *  died in the background, and wakes one that is sitting in a wait. */
    fun onAppForeground() {
        wake.tryEmit(Unit)
        refreshSavedFaces()
        if (!safeMode) runCatching { resumeTrackedJobs() }
        if (!safeMode && pendingUpdates.isNotEmpty()) startPendingLoop()
        // The keep-alive service is only for when Phoenix is not on screen.
        // Leaving it up while the app is open is what made Android close Phoenix
        // after a while.
        stopBackgroundGuardIfIdle()
        if (activeTransfers.get() == 0) {
            runCatching {
                getApplication<Application>().stopService(
                    Intent(getApplication<Application>(), PhoenixKeepAliveService::class.java)
                )
            }
        }
    }

    fun onAppBackground() {
        if (parallelJobs.isNotEmpty()) startBackgroundGuard()
    }

    private fun hasInternet(): Boolean {
        return try {
            val cm = getApplication<Application>().getSystemService(ConnectivityManager::class.java) ?: return true
            val network = cm.activeNetwork ?: return false
            val caps = cm.getNetworkCapabilities(network) ?: return false
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        } catch (e: Throwable) {
            // 1.2.37 (from 1.2.35): inside Secure Folder (a secondary user) Android throws a SecurityException from
            // ConnectivityService when this process may not read the network state. That must not abort a job: assume it is up.
            true
        }
    }

    private suspend fun pauseOrWake(ms: Long) {
        withTimeoutOrNull(ms) { wake.first() }
    }

    /** Pause until the phone has a network again, the app is opened, or 15 seconds. */
    private suspend fun waitForNetwork() {
        if (hasInternet()) {
            pauseOrWake(600)
            return
        }
        val cm = getApplication<Application>().getSystemService(ConnectivityManager::class.java)
        if (cm == null) {
            pauseOrWake(2_000)
            return
        }
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                runCatching { wake.tryEmit(Unit) }
            }
        }
        val req = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()
        runCatching { cm.registerNetworkCallback(req, cb) }
        try {
            withTimeoutOrNull(15_000L) { wake.first() }
        } finally {
            runCatching { cm.unregisterNetworkCallback(cb) }
        }
    }

    private fun watchNetwork() {
        val cm = getApplication<Application>().getSystemService(ConnectivityManager::class.java) ?: return
        if (networkCallback != null) return
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                runCatching { resumeTrackedJobs() }
            }
        }
        val req = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()
        runCatching { cm.registerNetworkCallback(req, cb) }
        networkCallback = cb
    }

    override fun onCleared() {
        val cm = getApplication<Application>().getSystemService(ConnectivityManager::class.java)
        networkCallback?.let { cb -> runCatching { cm?.unregisterNetworkCallback(cb) } }
        networkCallback = null
        super.onCleared()
    }

    private fun resumeTrackedJobs() {
        // 1.2.59: a card whose video never reached its Space (no job id) and that is not finished belonged to the app run
        // that ended; nothing is sending it any more. It used to stay at "Uploading video 2 %" for ever.
        history.filter {
            it.kind == "Video" && it.remoteJobId.isNullOrBlank() && it.status !in TERMINAL_STATUSES &&
                it.status != "Lost" && !parallelJobs.containsKey(it.id)
        }.forEach {
            updateHistory(it.id, status = "Interrupted",
                eta = if (it.partCount > 1) "The app closed before this part was sent - tap Redo part"
                else "The app closed before this video was sent - start it again")
        }
        val resumable = history.filter {
            it.kind == "Video" &&
                !it.remoteJobId.isNullOrBlank() &&
                it.status != "Done" &&
                it.status != "Monitoring stopped"
        }.take(MAX_SPACES)
        resumable.forEach { resumeOne(it) }
        syncRunning()
    }

    // trimStartPct/trimEndPct are what the SERVER should still trim. When the
    // clip was cut locally these are the tiny sync-frame residue (often 0 /
    // 100); when it wasn't, they're the user's original selection and the
    // server trims exactly as it always did.
    /** Phoenix_<real job id>-1.mp4 so a split sorts by the part number. */
    private fun partSaveName(jobId: String, partIndex: Int, partCount: Int): String {
        return if (partCount > 1) "Phoenix_${jobId}-${partIndex + 1}.mp4" else "Phoenix_${jobId}.mp4"
    }

    private fun optionsJson(
        trimStartPct: Int = options.trimStart,
        trimEndPct: Int = options.trimEnd,
        targetRefPaths: Array<String?> = arrayOfNulls(4),
        faceModeOverride: String? = null,
        durationSecOverride: Int? = null,
        partIndex: Int = 0,
        partCount: Int = 1
    ) = JSONObject().apply {
        put("secs", durationSecOverride ?: options.durationSec); put("fps", options.fps); put("res", options.resolution); put("quality", options.quality)
        put("enhancer", options.enhancer); put("swap_n", options.swapEvery); put("det_n", options.detectEvery); put("det_int", options.detectInterval)
        put("password", options.password); put("trim_start", trimStartPct); put("trim_end", trimEndPct)
        // The Face mode Dropdown is a separate control from which face tiles
        // are actually filled - attach 2 replacement faces without touching
        // it, and it silently stays on its default "1 face (fastest)". The
        // server then only ever attempts a single-face swap regardless of
        // how many faces were uploaded, which is what caused one replacement
        // face to get pasted onto everyone in frame. Only override when the
        // current selection would understate reality; an intentional "All
        // detected faces" choice (or a correct "2 faces" one) is left alone.
        val filledFaces = listOf(face1, face2, face3, face4).count { it != null }
        val chosen = faceModeOverride ?: options.faceMode
        val effectiveFaceMode = if (filledFaces >= 2 && chosen.startsWith("1")) {
            if (filledFaces == 2) "2 faces" else "All detected faces"
        } else chosen
        put("face_mode", effectiveFaceMode)
        put("enhance_scope", options.enhanceScope); put("device_mode", options.deviceMode)
        put("primary_slot", options.primarySlot); put("smooth_motion", options.smoothMotion)
        val sexes = org.json.JSONArray()
        slotSex.forEach { g -> if (g == null) sexes.put(org.json.JSONObject.NULL) else sexes.put(g) }
        put("person_gender", sexes)
        if (partCount > 1) {
            put("part_index", partIndex + 1)
            put("part_count", partCount)
        }
        val refs = JSONArray()
        targetRefPaths.forEach { p -> if (p.isNullOrBlank()) refs.put(JSONObject.NULL) else refs.put(p) }
        put("target_refs", refs)
        // 1.2.51: skin tone per replacement slot (Space v11.2.205+; an older Space ignores it)
        if (options.skinTone.any { kotlin.math.abs(it) >= 0.005f }) {
            put("skin_tone", JSONArray(options.skinTone.map { it.toDouble() }))
        }
    }

    private fun fileData(path: String) = JSONObject().put("path", path).put("meta", JSONObject().put("_type", "gradio.FileData"))
    private fun extractPath(data: JSONArray): String? {
        fun walk(v: Any?): String? = when (v) {
            is String -> v.takeIf { it.contains("/") || it.startsWith("http://") || it.startsWith("https://") }
            is JSONObject -> v.optString("path").takeIf { it.isNotBlank() }
            is JSONArray -> (0 until v.length()).asSequence().map { walk(v.opt(it)) }.firstOrNull { it != null }
            else -> null
        }
        return walk(data)
    }

    private fun downloadToCache(
        s: HfSettings,
        path: String,
        prefix: String,
        onProgress: ((Long, Long) -> Unit)? = null
    ): File = File(getApplication<Application>().cacheDir, "${prefix}_${System.currentTimeMillis()}")
        .also { hf.downloadOutput(s, path, it, onProgress) }

    /**
     * Every uploaded source file and every downloaded intermediate/result file
     * was landing in the app's cache directory with nothing ever deleting it -
     * meaning every video and face ever processed accumulated on-device
     * indefinitely, well past the point any of it was still needed. Source
     * uploads are safe to delete the moment the upload call returns (nothing
     * references the local copy after that); result downloads are safe to
     * delete the moment they've been copied into MediaStore.
     */
    private fun safeDelete(file: File?) {
        if (file == null) return
        runCatching { file.delete() }
    }

    private fun safeDelete(uri: Uri?) {
        val path = uri?.takeIf { it.scheme == "file" }?.path ?: return
        safeDelete(File(path))
    }

    /** Manual, on-demand sweep for anything from before this cleanup existed,
     *  or any edge case the per-job cleanup didn't catch. Never touches
     *  MediaStore results (Movies/Phoenix, Pictures/Phoenix) - only this
     *  app's own private cache directory. */
    fun clearLocalCache() {
        val dir = getApplication<Application>().cacheDir
        val files = dir.listFiles()?.filter { it.name.startsWith("phoenix_") || it.name.startsWith("frame_") || it.name.startsWith("detected_") || it.name.startsWith("image_detected_") } ?: emptyList()
        var freedBytes = 0L
        files.forEach { freedBytes += it.length(); safeDelete(it) }
        detectedFrameUri = null
        detectedFaces = List(4) { null }
        val freedMb = freedBytes / 1_048_576.0
        status = if (files.isEmpty()) "No cached files to clear" else "Cleared %.1f MB of cached files".format(freedMb)
    }

    private fun alreadySaved(jobId: String): Boolean {
        if (jobId.isBlank()) return false
        return prefs.getStringSet(SAVED_JOBS_KEY, emptySet())?.contains(jobId) == true
    }

    private fun markSaved(jobId: String) {
        if (jobId.isBlank()) return
        val next = (prefs.getStringSet(SAVED_JOBS_KEY, emptySet()) ?: emptySet()).toMutableSet()
        next.add(jobId)
        prefs.edit().putStringSet(SAVED_JOBS_KEY, next).commit()
    }

    private fun existingVideoUri(name: String): Uri? {
        val resolver = getApplication<Application>().contentResolver
        val q = resolver.query(
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
            arrayOf(MediaStore.Video.Media._ID),
            "${MediaStore.Video.Media.DISPLAY_NAME}=?",
            arrayOf(name),
            "${MediaStore.Video.Media.DATE_ADDED} DESC"
        ) ?: return null
        q.use { c ->
            if (!c.moveToFirst()) return null
            val id = c.getLong(0)
            return android.content.ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id)
        }
    }

    private fun persistHistoryNow() {
        persistHistory(commit = true)
    }

    private fun publishResult(source: File, name: String): Uri {
        synchronized(saveLock) {
        existingVideoUri(name)?.let { return it }
        outputTreeUri?.let { tree ->
            val custom = runCatching { writeToCustomTree(tree, source, name, "video/mp4") }.getOrNull()
            if (custom != null) return custom
            // Falls through to the default MediaStore path below - a
            // revoked permission or a folder the user deleted must not
            // fail an already-fully-rendered job.
        }
        val resolver = getApplication<Application>().contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, name); put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/Phoenix"); if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: throw IllegalStateException("Could not create output media")
        // insert() above already created a real, persisted file entry - if
        // anything below fails, that entry is now an orphan unless we remove
        // it ourselves. Left behind, a retried publishResult() call creates a
        // second entry alongside it: two files in the gallery for one job.
        try {
            resolver.openOutputStream(uri)?.use { source.inputStream().use { input -> input.copyTo(it) } } ?: throw IllegalStateException("Could not write output")
            if (Build.VERSION.SDK_INT >= 29) resolver.update(uri, ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }, null, null)
        } catch (e: Throwable) {
            runCatching { resolver.delete(uri, null, null) }
            throw e
        }
        return uri
        }
    }

    private fun publishImageResult(source: File, name: String): Uri {
        outputTreeUri?.let { tree ->
            val custom = runCatching { writeToCustomTree(tree, source, name, "image/jpeg") }.getOrNull()
            if (custom != null) return custom
        }
        val resolver = getApplication<Application>().contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name); put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Phoenix"); if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: throw IllegalStateException("Could not create output image")
        resolver.openOutputStream(uri)?.use { source.inputStream().use { input -> input.copyTo(it) } } ?: throw IllegalStateException("Could not write output image")
        if (Build.VERSION.SDK_INT >= 29) resolver.update(uri, ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }, null, null)
        return uri
    }

    /**
     * Writes [source] into the user-chosen SAF tree, returning the new
     * document's URI, or null if the tree is no longer usable (permission
     * revoked, folder deleted, etc.) so the caller falls back to the
     * default MediaStore location instead of failing the job outright.
     */
    private fun writeToCustomTree(tree: Uri, source: File, name: String, mime: String): Uri? {
        val app = getApplication<Application>()
        val hasPermission = app.contentResolver.persistedUriPermissions.any {
            it.uri == tree && it.isWritePermission
        }
        if (!hasPermission) return null
        val parentDoc = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
        val newDocUri = DocumentsContract.createDocument(app.contentResolver, parentDoc, mime, name) ?: return null
        // createDocument() above already created a real, persisted file - if
        // the copy fails, that document is now an orphan unless removed here.
        try {
            app.contentResolver.openOutputStream(newDocUri)?.use { out ->
                source.inputStream().use { input -> input.copyTo(out) }
            } ?: throw IllegalStateException("Could not open output stream")
        } catch (e: Throwable) {
            runCatching { DocumentsContract.deleteDocument(app.contentResolver, newDocUri) }
            return null
        }
        return newDocUri
    }

    fun removeHistory(id: String) { history.find { it.id == id }?.uri?.let { runCatching { getApplication<Application>().contentResolver.delete(Uri.parse(it), null, null) } }; synchronized(historyLock) { history = history.filterNot { it.id == id }; persistHistory() } }
    /**
     * Copies an already-completed job's video (saved in Movies/Phoenix at job
     * completion) into the public Downloads/Phoenix folder, so it shows up in
     * the Downloads app like any other download - distinct from just being
     * able to view it in place.
     */
    /**
     * Toast for a fire-and-forget confirmation the user might otherwise miss.
     * A status-bar text change alone isn't enough for something like a
     * background download finishing - it's easy to be scrolled past the
     * header, or not looking at it at that exact moment, and a silently
     * updated string gives no cue that anything happened at all.
     */
    private suspend fun toast(message: String) = withContext(Dispatchers.Main) {
        Toast.makeText(getApplication(), message, Toast.LENGTH_LONG).show()
    }

    fun downloadToDownloads(item: HistoryItem) {
        val sourceUriString = item.uri
        if (sourceUriString.isNullOrBlank()) { status = "No saved file for this job"; return }
        if (Build.VERSION.SDK_INT < 29) {
            status = "Saving to Downloads needs Android 10+. Your video is already in Movies/Phoenix."
            Toast.makeText(getApplication(), "Can't save to Downloads on this Android version — already in Movies/Phoenix", Toast.LENGTH_LONG).show()
            return
        }
        viewModelScope.launch(guard + Dispatchers.IO) {
            try {
                val resolver = getApplication<Application>().contentResolver
                val sourceUri = Uri.parse(sourceUriString)
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, item.name)
                    put(MediaStore.Downloads.MIME_TYPE, "video/mp4")
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Phoenix")
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
                val destUri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("Could not create a download entry")
                resolver.openInputStream(sourceUri)?.use { input ->
                    resolver.openOutputStream(destUri)?.use { output -> input.copyTo(output) }
                        ?: throw IllegalStateException("Could not write the download")
                } ?: throw IllegalStateException("Could not read the saved video")
                resolver.update(destUri, ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }, null, null)
                status = "Saved to Downloads/Phoenix — ${item.name}"
                toast("Downloaded to Downloads/Phoenix: ${item.name}")
            } catch (e: Throwable) {
                val detail = e.message ?: e.javaClass.simpleName
                status = "Download failed: $detail"
                toast("Download failed: $detail")
            }
        }
    }

    fun clearHistory() { history.forEach { it.uri?.let { u -> runCatching { getApplication<Application>().contentResolver.delete(Uri.parse(u), null, null) } } }; synchronized(historyLock) { history = emptyList(); persistHistory() }; status = "History cleared" }
    fun refreshHistory() {
        synchronized(historyLock) { history = loadHistory() }
        cleanupHistoryMetadata()
        status = "History refreshed. Resume keeps the Space job. Redo part runs only that piece again."
    }

    fun retryJob(localId: String) {
        val item = history.find { it.id == localId } ?: return
        val remoteId = item.remoteJobId
        if (remoteId.isNullOrBlank()) {
            status = "This part never reached the Space. Use Redo part."
            return
        }
        if (parallelJobs.containsKey(localId)) {
            status = "Already watching ${item.name}"
            return
        }
        status = "Watching job $remoteId again. The card stays as it is until the Space answers."
        resumeOne(item)
    }

    fun redoSplitPart(localId: String) {
        val item = history.find { it.id == localId } ?: return
        if (item.partCount < 2 || item.groupId.isNullOrBlank()) {
            status = "Redo part is only for one piece of a split."
            return
        }
        if (listOf(face1, face2, face3, face4).all { it == null }) {
            status = "Put the same replacement faces in the slots, then tap Redo part."
            updateHistory(localId, eta = "Put the same replacement faces in the slots, then tap Redo part")
            return
        }
        val file = resolvePartFile(item)
        // 1.2.57: no clip left (older versions deleted it after the upload): cut this part again - from the original
        // video it remembers, or else from the video now selected in step 01 with the trim it had for the split
        val orig = item.origUri?.takeIf { item.origStartPct >= 0 && item.origEndPct > item.origStartPct }
        val from: Triple<Uri, Int, Int>? = when {
            file != null -> null
            orig != null -> Triple(Uri.parse(orig), item.origStartPct, item.origEndPct)
            selectedVideo != null -> {
                val winStart = options.trimStart.coerceIn(0, 99)
                val winEnd = options.trimEnd.coerceIn(winStart + 1, 100)
                val span = winEnd - winStart
                val a = winStart + span * item.partIndex / item.partCount
                val b = if (item.partIndex == item.partCount - 1) winEnd else winStart + span * (item.partIndex + 1) / item.partCount
                Triple(selectedVideo!!, a, b)
            }
            else -> null
        }
        if (file == null && from == null) {
            status = "Select the original video in step 01 (same trim as the split), then tap Redo part."
            updateHistory(localId, eta = "Select the original video in step 01, then tap Redo part")
            return
        }
        parallelJobs.remove(localId)?.cancel()
        syncRunning()
        updateHistory(localId, status = "Replaced", eta = "Running this part again")
        val space = HfSettings(
            item.spaceUrl.trim().trimEnd('/'),
            endpoint.trim().ifBlank { DEFAULT_ENDPOINT },
            modelRepo,
            modelRevision
        )
        val n = item.partIndex + 1
        status = if (file != null) "Part $n of ${item.partCount} starting again."
        else "Cutting part $n of ${item.partCount} again (${from!!.second}-${from.third} % of the video)…"
        viewModelScope.launch(guard + Dispatchers.IO) {
            var clip = file
            var secs = 360
            var skipPct = 0
            if (clip == null && from != null) {
                val app = getApplication<Application>()
                val totalUs = VideoTrimmer.durationUs(app, from.first) ?: 0L
                if (totalUs > 0L) {
                    val dest = File(app.cacheDir, "phoenix_part_${item.groupId}_${item.partIndex}.mp4")
                    val cut = VideoTrimmer.trim(app, from.first, totalUs * from.second / 100L, totalUs * from.third / 100L, dest)
                    if (cut != null && cut.file.exists() && cut.durationUs > 0L) {
                        clip = cut.file
                        secs = ((cut.durationUs / 1_000_000L).toInt() + 3).coerceIn(10, 360)
                        // as the split does it: skip the frames before the cut point (the clip starts on a key frame)
                        skipPct = ((cut.residualStartUs * 100.0) / cut.durationUs).toInt().coerceIn(0, 5)
                    }
                }
            }
            if (clip == null) {
                updateHistory(localId, status = "Lost", eta = "Could not cut the part again. Select the original video in step 01, then tap Redo part")
                status = "Could not cut part $n again from the video. Select the original video in step 01, then tap Redo part."
                return@launch
            }
            startRemote(
                Uri.fromFile(clip),
                space = space,
                label = item.spaceLabel,
                trimStart = skipPct,
                trimEnd = 100,
                groupId = item.groupId,
                partIndex = item.partIndex,
                partCount = item.partCount,
                durationSec = secs,
                origUri = from?.first?.toString() ?: item.origUri,
                origStartPct = from?.second ?: item.origStartPct,
                origEndPct = from?.third ?: item.origEndPct
            )
            status = "Part $n of ${item.partCount} started again. Parts that already finished are kept."
        }
    }

    private fun resolvePartFile(item: HistoryItem): File? {
        val named = item.sourcePath?.let { File(it) }?.takeIf { it.isFile && it.length() > 0L }
        if (named != null) return named
        val gid = item.groupId ?: return null
        val guess = File(getApplication<Application>().cacheDir, "phoenix_part_${gid}_${item.partIndex}.mp4")
        return guess.takeIf { it.isFile && it.length() > 0L }
    }

    private fun resumeOne(item: HistoryItem) {
        if (parallelJobs.containsKey(item.id)) return
        if (parallelJobs.size >= MAX_SPACES) return
        val remoteId = item.remoteJobId ?: return
        if (alreadySaved(remoteId) || !item.uri.isNullOrBlank()) {
            updateHistory(item.id, status = "Done", progress = 1f, eta = "Done")
            return
        }
        val url = item.spaceUrl.trim().trimEnd('/')
        if (url.isBlank()) return
        val settings = HfSettings(url, endpoint.trim().ifBlank { DEFAULT_ENDPOINT }, modelRepo, modelRevision)
        val controlJob = Job()
        parallelJobs[item.id] = controlJob
        viewModelScope.launch(guard + controlJob + Dispatchers.IO) {
            try {
                while (true) {
                    try {
                        pollPhoenixJob(settings, remoteId, item.id)
                        break
                    } catch (e: kotlinx.coroutines.CancellationException) {
                        updateHistory(item.id, status = "Monitoring stopped", eta = "Stopped")
                        throw e
                    } catch (e: Throwable) {
                        if (hasInternet()) {
                            updateHistory(item.id, eta = "Still watching — signal blipped")
                            pauseOrWake(3_000L)
                        } else {
                            updateHistory(item.id, eta = "No network — will update when back")
                            waitForNetwork()
                        }
                    }
                }
            } finally {
                parallelJobs.remove(item.id)
                syncRunning()
            }
        }
        syncRunning()
    }

    private fun addHistory(item: HistoryItem) { synchronized(historyLock) { history = (listOf(item) + history).take(50); persistHistory() } }
    private fun frameNote(r: JSONObject, message: String): String {
        val now = sequenceOf("frame", "frames_done", "frame_index", "processed_frames")
            .map { r.optInt(it, -1) }.firstOrNull { it >= 0 }
        val total = sequenceOf("total_frames", "frames", "frame_count", "nframes")
            .map { r.optInt(it, -1) }.firstOrNull { it > 0 }
        if (now != null && total != null) return "Frames $now/$total"
        val match = Regex("""(\d+)\s*/\s*(\d+)""").find(message) ?: return ""
        return "Frames ${match.groupValues[1]}/${match.groupValues[2]}"
    }

    private fun persistHistory(commit: Boolean = false) {
        val arr = JSONArray(); history.forEach { h -> arr.put(JSONObject().put("id", h.id).put("kind", h.kind).put("name", h.name).put("uri", h.uri ?: JSONObject.NULL).put("status", h.status).put("createdAt", h.createdAt).put("spaceLabel", h.spaceLabel).put("spaceUrl", h.spaceUrl).put("remoteJobId", h.remoteJobId ?: JSONObject.NULL).put("progress", h.progress).put("eta", h.eta).put("groupId", h.groupId ?: JSONObject.NULL).put("partIndex", h.partIndex).put("partCount", h.partCount).put("sourcePath", h.sourcePath ?: JSONObject.NULL).put("detail", h.detail)
            .put("origUri", h.origUri ?: JSONObject.NULL).put("origStartPct", h.origStartPct).put("origEndPct", h.origEndPct)) }
        val ed = prefs.edit().putString(HISTORY_KEY, arr.toString())
        if (commit) ed.commit() else ed.apply()
    }
    private fun loadHistory(): List<HistoryItem> = GuardLogic.loadList(
        runCatching { prefs.getString(HISTORY_KEY, "[]") }.getOrNull(),
        parseAll = { text ->
            val arr = JSONArray(text)
            (0 until arr.length()).map { i -> runCatching { historyFrom(arr.getJSONObject(i)) }.getOrNull() }
        },
        backup = { text -> prefs.edit().putString("items_unreadable_backup", text).commit() }
    )

    private fun historyFrom(o: JSONObject): HistoryItem = HistoryItem(
        o.optString("id"), o.optString("kind"), o.optString("name"), o.optString("uri").takeIf { it.isNotBlank() && it != "null" },
        o.optString("status"), o.optLong("createdAt"), o.optString("spaceLabel", "Space 1"), o.optString("spaceUrl", ""),
        o.optString("remoteJobId").takeIf { it.isNotBlank() && it != "null" }, o.optDouble("progress", 0.0).toFloat(), o.optString("eta", "ETA —"),
        o.optString("groupId").takeIf { it.isNotBlank() && it != "null" }, o.optInt("partIndex", 0), o.optInt("partCount", 1),
        o.optString("sourcePath").takeIf { it.isNotBlank() && it != "null" },
        o.optString("detail", ""),
        o.optString("origUri").takeIf { it.isNotBlank() && it != "null" },
        o.optInt("origStartPct", -1),
        o.optInt("origEndPct", -1)
    )
    private fun cleanupHistoryMetadata() { synchronized(historyLock) { history = history.filter { it.uri == null || runCatching { getApplication<Application>().contentResolver.openAssetFileDescriptor(Uri.parse(it.uri), "r") != null }.getOrDefault(false) }; persistHistory() } }

    // Kept at the END of the class on purpose: Kotlin runs property initialisers and init{} blocks in the
    // order they are written, and the job watchers started here use properties declared far above
    // (wake, networkCallback, clientSignatures, ...). Placed earlier, they could read them before they exist.
    init {
        PhoenixApplication.onLowMemory = { releaseIdleBitmaps() }
        runCatching { reportLastExit() }
        runCatching { loadSpaceSettings() }
        if (runCatching { Guard.inSafeMode(app) }.getOrDefault(false)) {
            safeMode = true
        } else {
            runCatching { watchNetwork() }
            runCatching { resumeTrackedJobs() }
            runCatching { resumePendingUpdates() }
        }
    }

    private fun resumePendingUpdates() {
        viewModelScope.launch(Dispatchers.IO) {
            val p = runCatching { loadPending() }.getOrNull() ?: return@launch
            withContext(Dispatchers.Main) { pendingUpdates = p.second.map { it.label } }
            if (p.second.isNotEmpty()) startPendingLoop()
        }
    }
}
